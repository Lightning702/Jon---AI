from __future__ import annotations

import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AUSSEN = {"MEMORY.md", "website/jon.zip", "website/jon-erweiterung.zip"}


def git(*args: str) -> str:
    return subprocess.run(
        ["git", *args], cwd=str(ROOT), capture_output=True, text=True, check=True,
        encoding="utf-8", errors="replace",
    ).stdout


def dateien() -> list[str]:
    git("add", "-A")
    return [z for z in git("ls-files").splitlines() if z.strip()]


def schreiben(ziel: Path, eintraege: list[tuple[str, str]], praefix: str) -> int:
    if ziel.exists():
        ziel.unlink()
    with zipfile.ZipFile(ziel, "w", zipfile.ZIP_DEFLATED) as z:
        info = zipfile.ZipInfo(praefix + "/")
        info.external_attr = (0o755 << 16) | 0x10
        z.writestr(info, "")
        for rel, quelle in eintraege:
            pfad = ROOT / quelle
            if not pfad.is_file():
                continue
            name = f"{praefix}/{rel}"
            if rel.endswith(".sh"):
                text = pfad.read_text(encoding="utf-8").replace("\r\n", "\n")
                eintrag = zipfile.ZipInfo(name)
                eintrag.external_attr = 0o755 << 16
                eintrag.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(eintrag, text)
            else:
                z.write(pfad, name)
    return len(eintraege) + 1


def main() -> None:
    alle = dateien()
    quellcode = [(p, p) for p in alle if p not in AUSSEN]
    anzahl = schreiben(ROOT / "website" / "jon.zip", quellcode, "Jon")
    groesse = (ROOT / "website" / "jon.zip").stat().st_size
    print(f"jon.zip            : {anzahl} Eintraege, {groesse / 1_048_576:.2f} MB")

    erweiterung = [
        (p[len("extension/"):], p) for p in alle if p.startswith("extension/")
    ]
    anzahl2 = schreiben(
        ROOT / "website" / "jon-erweiterung.zip", erweiterung, "Jon-Erweiterung"
    )
    groesse2 = (ROOT / "website" / "jon-erweiterung.zip").stat().st_size
    print(f"jon-erweiterung.zip: {anzahl2} Eintraege, {groesse2 / 1024:.0f} KB")

    with zipfile.ZipFile(ROOT / "website" / "jon.zip") as z:
        namen = z.namelist()
    for verboten in ("Jon/MEMORY.md", "Jon/website/jon.zip"):
        assert verboten not in namen, verboten
    assert any(n.endswith("scripts/jon_einrichten.py") for n in namen)
    assert any(n.endswith("services/pptx_effekte.py") for n in namen)
    sh = [n for n in namen if n.endswith(".sh")]
    print(f"Shell-Skripte      : {len(sh)} (LF + 0755)")
    print("Pruefung           : MEMORY.md draussen, neue Dateien drin")


main()
