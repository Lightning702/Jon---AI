from __future__ import annotations

import os
import shutil
import sys
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict
from app.core.fehler import leise

FROZEN = getattr(sys, "frozen", False)

if FROZEN:
    ROOT_DIR = Path(sys.executable).resolve().parent
else:
    ROOT_DIR = Path(__file__).resolve().parents[3]
ENV_FILE = ROOT_DIR / ".env"

NVIDIA_JON_MODELL = "nvidia/nemotron-3-ultra-550b-a55b"
NVIDIA_EMIL_MODELL = "meta/muse-glimmer-30b"
ABGESCHALTETE_MODELLE = {
    "openai/gpt-oss-120b": NVIDIA_JON_MODELL,
    "openai/gpt-oss-20b": NVIDIA_EMIL_MODELL,
    "meta/llama-3.1-8b-instruct": NVIDIA_EMIL_MODELL,
    "nvidia/llama-3.1-nemotron-70b-instruct": NVIDIA_JON_MODELL,
}


def lebendes_modell(model: str, provider: str = "nvidia") -> str:
    if provider != "nvidia":
        return model
    return ABGESCHALTETE_MODELLE.get((model or "").strip(), model)


def _writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".jon-write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return True
    except Exception:
        return False


def _hat_daten(pfad: Path) -> bool:
    try:
        return (pfad / "jon.db").stat().st_size > 0
    except OSError:
        return False


def _gemeinsamer_ordner() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base) / "Jon" / "data"
    return Path.home() / ".jon" / "data"


def _resolve_data_dir() -> Path:
    override = os.environ.get("JON_DATA_DIR")
    if override:
        return Path(override)
    gemeinsam = _gemeinsamer_ordner()
    if FROZEN:
        beside = Path(sys.executable).resolve().parent / "data"
        if not _hat_daten(beside) and _hat_daten(gemeinsam):
            return gemeinsam
        if _writable(beside):
            return beside
    return gemeinsam


def web_app_dir() -> Path | None:
    kandidaten = [ROOT_DIR / "frontend" / "dist", ROOT_DIR / "webapp"]
    bundled = getattr(sys, "_MEIPASS", "")
    if bundled:
        kandidaten.append(Path(bundled) / "frontend" / "dist")
        kandidaten.append(Path(bundled) / "webapp")
    for pfad in kandidaten:
        if (pfad / "index.html").is_file():
            return pfad
    return None


DATA_DIR = _resolve_data_dir()
_OLD_DATA_DIR = ROOT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

if _OLD_DATA_DIR.exists() and _OLD_DATA_DIR.resolve() != DATA_DIR.resolve():
    for _item in _OLD_DATA_DIR.iterdir():
        _target = DATA_DIR / _item.name
        if _target.exists():
            continue
        try:
            if _item.is_dir():
                shutil.copytree(_item, _target)
            else:
                shutil.copy2(_item, _target)
        except Exception as _fehler:
            leise(_fehler, "core/config")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_name: str = "Jon"
    app_version: str = "4.63.1"
    host: str = "127.0.0.1"
    port: int = 8756
    cors_origins: str = ""
    jon_lan: bool = False
    jon_token: str = ""

    database_url: str = f"sqlite:///{(DATA_DIR / 'jon.db').as_posix()}"

    default_provider: str = "nvidia"
    default_model: str = ""
    default_jon_model: str = NVIDIA_JON_MODELL
    default_emil_model: str = NVIDIA_EMIL_MODELL

    openai_api_key: str | None = None
    nvidia_api_key: str | None = None
    anthropic_api_key: str | None = None
    google_api_key: str | None = None
    deepseek_api_key: str | None = None
    mistral_api_key: str | None = None
    glm_api_key: str | None = None
    qwen_api_key: str | None = None
    openrouter_api_key: str | None = None
    groq_api_key: str | None = None
    together_api_key: str | None = None
    xai_api_key: str | None = None

    openai_base_url: str = "https://api.openai.com/v1"
    nvidia_base_url: str = "https://integrate.api.nvidia.com/v1"
    deepseek_base_url: str = "https://api.deepseek.com/v1"
    mistral_base_url: str = "https://api.mistral.ai/v1"
    glm_base_url: str = "https://open.bigmodel.cn/api/paas/v4"
    qwen_base_url: str = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
    ollama_base_url: str = "http://localhost:11434/v1"
    lmstudio_base_url: str = "http://localhost:1234/v1"
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    groq_base_url: str = "https://api.groq.com/openai/v1"
    together_base_url: str = "https://api.together.xyz/v1"
    xai_base_url: str = "https://api.x.ai/v1"

    maps_geocoder: str = "nominatim"
    maps_places: str = "overpass"
    maps_router: str = "osrm"
    maps_transit: str = "transitous"
    maps_street: str = "kartaview"
    maps_style_dark: str = "https://tiles.openfreemap.org/styles/positron"
    maps_style_light: str = "https://tiles.openfreemap.org/styles/bright"
    maps_tiles_satellite: str = (
        "https://server.arcgisonline.com/ArcGIS/rest/services/"
        "World_Imagery/MapServer/tile/{z}/{y}/{x}"
    )
    maps_terrain_tiles: str = (
        "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png"
    )
    maps_transit_tiles: str = "https://tileserver.memomaps.de/tilegen/{z}/{x}/{y}.png"
    maps_bike_tiles: str = (
        "https://a.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png"
    )
    maps_traffic_tiles: str = ""
    maps_home_lat: float = 51.1657
    maps_home_lon: float = 10.4515
    maps_home_zoom: float = 5.2
    maps_user_agent: str = "JonDesktop/4.34 (+https://github.com/Lightning702/Jon)"
    nominatim_base_url: str = "https://nominatim.openstreetmap.org"
    overpass_base_url: str = "https://overpass-api.de/api/interpreter"
    osrm_base_url: str = "https://router.project-osrm.org"
    osrm_profiles: str = "auto"
    valhalla_base_url: str = "https://valhalla1.openstreetmap.de"
    transitous_base_url: str = "https://api.transitous.org"
    kartaview_base_url: str = "https://api.openstreetcam.org"
    mapillary_token: str | None = None

    research_sources_per_topic: int = 6
    research_max_subtopics: int = 14
    research_page_chars: int = 14000
    research_default_minutes: int = 45

    request_timeout: float = 90.0
    first_token_timeout: float = 10.0
    jon_premium_url: str = "https://getjon.info/.netlify/functions"
    jon_codes_url: str = "https://felworks.tail661828.ts.net/codes"
    jon_support_url: str = "https://getjon.info/support/"
    models_timeout: float = 6.0
    max_tokens: int = 32768
    context_budget_tokens: int = 24000
    reasoning_effort: str = "low"
    default_temperature: float = 0.7
    default_top_p: float = 0.9

    @property
    def jon_model(self) -> str:
        return lebendes_modell(
            self.default_jon_model.strip()
            or self.default_model.strip()
            or NVIDIA_JON_MODELL,
            self.default_provider,
        )

    @property
    def emil_model(self) -> str:
        return (
            lebendes_modell(self.default_emil_model.strip(), self.default_provider)
            or self.jon_model
        )

    def model_for(self, slot: str) -> str:
        return self.emil_model if slot == "emil" else self.jon_model

    def origins(self) -> list[str]:
        raw = self.cors_origins.strip()
        if raw:
            return [item.strip() for item in raw.split(",") if item.strip()]
        allowed = ["null"]
        for host in ("localhost", "127.0.0.1"):
            allowed.append(f"http://{host}:{self.port}")
            allowed.append(f"http://{host}:5173")
        if self.jon_lan:
            from app.core.auth import lan_address

            allowed.append(f"http://{lan_address()}:{self.port}")
        return allowed


@lru_cache
def get_settings() -> Settings:
    return Settings()
