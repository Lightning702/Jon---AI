from __future__ import annotations

import asyncio
import os
import socket
import subprocess
import time
from contextlib import asynccontextmanager, suppress
from datetime import datetime

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api.multiplayer_routes import MP_TCP_PORT, MP_WS_PORT, create_coop_app
from app.api.multiplayer_routes import router as multiplayer_router
from app.api.inbox_routes import router as inbox_router
from app.api.handy_routes import router as handy_router
from app.api.anmeldung_routes import router as anmeldung_router
from app.api.live_routes import router as live_router
from app.api.verbund_routes import router as verbund_router
from app.api.oekosystem_routes import router as oekosystem_router
from app.api.mediathek_routes import router as mediathek_router
from app.api.zeit_routes import router as zeit_router
from app.api.p2p_routes import create_chat_app
from app.api.p2p_routes import router as p2p_router
from app.api.maps_routes import router as maps_router
from app.api.project_routes import router as project_router
from app.api.phone_routes import router as phone_router
from app.api.research_routes import router as research_router
from app.api.browser_routes import router as browser_router
from app.api.datei_routes import router as datei_router
from app.api.terminal_routes import router as terminal_router
from app.api.lehrer_routes import router as lehrer_router
from app.api.btw_routes import router as btw_router
from app.api.testumgebung_routes import router as testumgebung_router, vorschau_router as testumgebung_vorschau
from app.api.denken_routes import router as denken_router
from app.api.routes import accounts, providers, router
from app.api.studio_routes import router as studio_router
from app.api.mobile_routes import router as mobile_router
from app.api.fitness_routes import router as fitness_router
from app.api.geraet_app_routes import router as geraet_app_router
from app.api.sicherung_routes import router as sicherung_router
from app.api.system_routes import router as system_router
from app.api.harness_routes import router as harness_router
from app.api.premium_routes import router as premium_router
from app.api.beobachten_routes import router as beobachten_router
from app.api.support_routes import router as support_router
from app.api.agenten_routes import router as agenten_router
from app.api.media_routes import router as media_router
from app.core.auth import TokenMiddleware, get_token
from app.core.config import ROOT_DIR, get_settings, web_app_dir
from app.core.logbook import logger as logbook_logger
from app.core.logbook import note_error, note_ok, setup_logging
from app.db.database import init_db

_log = logbook_logger("main")


async def _warm_caches() -> None:
    with suppress(Exception):
        from app.services.tool_index import aufbauen

        await asyncio.to_thread(aufbauen)
    with suppress(Exception):
        await providers()
    with suppress(Exception):
        await accounts()


async def _beobachten_watcher() -> None:
    from app.services.beobachten import TAKT_S, get_beobachten

    await asyncio.sleep(45)
    while True:
        try:
            anzahl = await get_beobachten().runde()
            if anzahl:
                _log.info("STEP beobachten %s geprueft", anzahl)
        except Exception as fehler:
            _log.warning("Beobachten fehlgeschlagen: %s", fehler)
        await asyncio.sleep(TAKT_S)


async def _premium_erneuern() -> None:
    from app.services.premium import get_premium

    await asyncio.sleep(20)
    while True:
        try:
            await asyncio.to_thread(get_premium().felworks_schluessel, True)
        except Exception as fehler:
            _log.info("FelWorks-Gastzugang noch nicht verfuegbar: %s", fehler)
        try:
            if get_premium().braucht_erneuerung():
                await get_premium().erneuern()
                _log.info("STEP premium Lizenz erneuert")
        except Exception as fehler:
            _log.warning("Premium-Lizenz konnte nicht erneuert werden: %s", fehler)
        await asyncio.sleep(6 * 3600)


async def _initiative_watcher() -> None:
    from app.services.initiative_service import get_initiative_service

    while True:
        await asyncio.sleep(600)
        try:
            dienst = get_initiative_service()
            if dienst.faellig():
                ergebnis = await dienst.lauf()
                if ergebnis.get("anzahl"):
                    _log.info("STEP initiative %s Vorschlaege", ergebnis["anzahl"])
        except Exception as fehler:
            _log.warning("Initiative fehlgeschlagen: %s", fehler)


async def _konsolidierung_watcher() -> None:
    from app.services.konsolidierung_service import get_konsolidierung_service
    from app.services.settings_service import get_settings_service

    while True:
        await asyncio.sleep(1200)
        try:
            if not get_settings_service().get().get("konsolidierung_auto", True):
                continue
            if datetime.now().hour < 4:
                continue
            dienst = get_konsolidierung_service()
            if dienst.faellig():
                ergebnis = await dienst.lauf("gestern")
                if ergebnis.get("ok"):
                    _log.info("STEP konsolidierung fertig")
        except Exception as fehler:
            _log.warning("Konsolidierung fehlgeschlagen: %s", fehler)


async def _wahrnehmung_watcher() -> None:
    from app.services.wahrnehmung_service import get_wahrnehmung_service

    while True:
        await asyncio.sleep(45)
        try:
            await asyncio.to_thread(get_wahrnehmung_service().takt)
        except Exception as fehler:
            _log.warning("Wahrnehmung fehlgeschlagen: %s", fehler)


async def _neugier_watcher() -> None:
    from app.services.neugier_service import get_neugier_service
    from app.services.settings_service import get_settings_service

    while True:
        await asyncio.sleep(1500)
        try:
            einstellungen = get_settings_service().get()
            if not einstellungen.get("neugier_auto", False):
                continue
            if datetime.now().hour < 3:
                continue
            dienst = get_neugier_service()
            await asyncio.to_thread(dienst.aus_konflikten)
            await asyncio.to_thread(dienst.aus_weltmodell)
            anzahl = int(einstellungen.get("neugier_pro_lauf", 3) or 3)
            ergebnis = await dienst.lauf(anzahl)
            if ergebnis.get("beantwortet"):
                _log.info("STEP neugier %s Fragen geklaert", ergebnis["beantwortet"])
        except Exception as fehler:
            _log.warning("Neugier fehlgeschlagen: %s", fehler)


async def _fertigkeit_watcher() -> None:
    from app.services.fertigkeit_service import get_fertigkeit_service
    from app.services.settings_service import get_settings_service

    while True:
        await asyncio.sleep(7200)
        try:
            if not get_settings_service().get().get("fertigkeit_auto", False):
                continue
            dienst = get_fertigkeit_service()
            vorschlaege = await asyncio.to_thread(dienst.entdecken)
            neu = 0
            for vorschlag in vorschlaege:
                if vorschlag.get("anzahl", 0) < 5:
                    continue
                if dienst.uebernehmen(vorschlag).get("id"):
                    neu += 1
            if neu:
                _log.info("STEP fertigkeiten %s neu gelernt", neu)
        except Exception as fehler:
            _log.warning("Fertigkeiten fehlgeschlagen: %s", fehler)


async def _aufgaben_watcher() -> None:
    from app.services.aufgaben_service import get_aufgaben_service
    from app.services.settings_service import get_settings_service

    while True:
        await asyncio.sleep(45)
        try:
            if not get_settings_service().get().get("aufgaben_enabled", False):
                continue
            dienst = get_aufgaben_service()
            if dienst.naechste() is None:
                continue
            ergebnis = await dienst.lauf()
            aufgabe = ergebnis.get("aufgabe") or {}
            if aufgabe:
                _log.info(
                    "STEP aufgabe %s -> %s",
                    aufgabe.get("titel", "")[:60],
                    aufgabe.get("zustand", ""),
                )
        except Exception as fehler:
            _log.warning("Aufgabenlauf fehlgeschlagen: %s", fehler)


async def _ausloeser_watcher() -> None:
    from app.services.ausloeser_service import get_ausloeser_service

    await asyncio.sleep(20)
    try:
        start = await asyncio.to_thread(get_ausloeser_service().beim_start)
        if start.get("anzahl"):
            _log.info("STEP ausloeser start %s", start["anzahl"])
    except Exception as fehler:
        _log.warning("Ausloeser beim Start fehlgeschlagen: %s", fehler)
    while True:
        await asyncio.sleep(60)
        try:
            ergebnis = await asyncio.to_thread(get_ausloeser_service().pruefen)
            for eintrag in ergebnis.get("gestartet", []):
                _log.info("STEP ausloeser %s", eintrag.get("titel", "")[:60])
        except Exception as fehler:
            _log.warning("Ausloeser fehlgeschlagen: %s", fehler)


async def _hypothesen_watcher() -> None:
    from app.services.hypothese_service import get_hypothese_service
    from app.services.settings_service import get_settings_service

    while True:
        await asyncio.sleep(2700)
        try:
            if not get_settings_service().get().get("hypothesen_auto", False):
                continue
            ergebnis = await get_hypothese_service().lauf(2)
            if ergebnis.get("neue_vermutungen") or ergebnis.get("geprueft"):
                _log.info("STEP hypothesen %s", ergebnis)
        except Exception as fehler:
            _log.warning("Hypothesenlauf fehlgeschlagen: %s", fehler)


async def _geraet_app_watcher() -> None:
    from app.services.geraet_app_service import get_geraet_app_service

    await asyncio.sleep(120)
    while True:
        try:
            ergebnis = await get_geraet_app_service().von_github_holen()
            if ergebnis.get("neu"):
                _log.info("STEP jon geraet %s bereit", ergebnis.get("version"))
        except Exception as fehler:
            _log.info("Jon-Gerät-Abgleich mit GitHub übersprungen: %s", fehler)
        await asyncio.sleep(6 * 3600)


async def _wochenbericht_watcher() -> None:
    from app.services.handy_service import get_handy_service
    from app.services.settings_service import get_settings_service

    await asyncio.sleep(90)
    while True:
        try:
            dienst = get_handy_service()
            woche = dienst.bericht_faellig()
            if woche and get_settings_service().get().get("handy_wochenbericht", True):
                anzahl = await dienst.berichte_senden(woche)
                _log.info("STEP wochenbericht %s an %s Geraete", woche, anzahl)
        except Exception as fehler:
            _log.info("Wochenbericht übersprungen: %s", fehler)
        await asyncio.sleep(600)


async def _pflege_watcher() -> None:
    from app.services.pflege_service import alles

    while True:
        await asyncio.sleep(1800)
        try:
            bericht = await asyncio.to_thread(alles)
            if bericht["screenshots"]["geloescht"] or bericht["browser_geschlossen"]:
                _log.info("STEP pflege %s", bericht)
        except Exception as fehler:
            _log.warning("Pflegelauf fehlgeschlagen: %s", fehler)


async def _dream_watcher() -> None:
    from app.services.dream_service import get_dream_service
    from app.services.settings_service import get_settings_service
    from app.services.system_service import SystemService

    syssvc = SystemService()
    while True:
        await asyncio.sleep(60)
        try:
            data = get_settings_service().get()
            if not data.get("dream_auto", True):
                continue
            idle_minutes = float(data.get("dream_idle_minutes", 5) or 5)
            idle = await asyncio.to_thread(syssvc.idle_seconds)
            if idle < idle_minutes * 60:
                continue
            dreams = get_dream_service()
            if not any(t["status"] == "pending" for t in dreams.list()):
                continue
            settings = get_settings()
            provider = data.get("provider") or settings.default_provider
            model = data.get("model") or settings.jon_model
            await dreams.run_pending(provider, model)
        except Exception as exc:
            note_error("dream_watcher", exc)
            continue


async def _friend_location_watcher() -> None:
    from app.services.friend_location_service import get_friend_location_service

    service = get_friend_location_service()
    while True:
        await asyncio.sleep(120)
        try:
            if not service.sharing().get("aktiv"):
                continue
            await service.broadcast()
        except Exception as exc:
            note_error("friend_location_watcher", exc)
            continue


async def _clipboard_watcher() -> None:
    from app.services.clipboard_service import get_clipboard_service
    from app.services.settings_service import get_settings_service

    svc = get_clipboard_service()
    while True:
        await asyncio.sleep(2)
        try:
            if not get_settings_service().get().get("clipboard_history", True):
                continue
            await asyncio.to_thread(svc.capture)
        except Exception as exc:
            note_error("clipboard_watcher", exc)
            continue


async def _task_watcher() -> None:
    from app.services.settings_service import get_settings_service
    from app.services.task_service import get_task_service

    while True:
        await asyncio.sleep(30)
        try:
            tasks = get_task_service()
            if not tasks._due():
                continue
            data = get_settings_service().get()
            settings = get_settings()
            provider = data.get("provider") or settings.default_provider
            model = data.get("model") or settings.jon_model
            await tasks.run_due(provider, model)
        except Exception as exc:
            note_error("task_watcher", exc)
            continue


async def _telegram_watcher() -> None:
    from app.services.telegram_service import get_telegram_service

    service = get_telegram_service()
    aufwaermen = asyncio.gather(asyncio.to_thread(service.aufwaermen), service.verbindung_aufwaermen())
    while True:
        try:
            await service.poll_once()
        except Exception as exc:
            note_error("telegram_watcher", exc)
            await asyncio.sleep(10)


async def _group_bots_watcher() -> None:
    from app.services.telegram_group_service import get_group_bots

    bots = get_group_bots()
    while True:
        try:
            await asyncio.gather(*(bot.poll_once() for bot in bots))
        except Exception as exc:
            note_error("group_bots_watcher", exc)
            await asyncio.sleep(10)


async def _morning_watcher() -> None:
    from app.services.telegram_service import get_telegram_service

    service = get_telegram_service()
    while True:
        await asyncio.sleep(60)
        try:
            await service.morning_tick()
        except Exception as exc:
            note_error("morning_watcher", exc)
            continue


async def _phone_watcher() -> None:
    from app.services.phone_service import get_phone_service

    service = get_phone_service()
    try:
        await service.start()
    except Exception as exc:
        note_error("phone_watcher", exc)
        pass
    while True:
        await asyncio.sleep(15)
        try:
            if service.enabled() and not service.status()["running"]:
                await service.start()
            await service.run_due()
        except Exception as exc:
            note_error("phone_watcher", exc)
            continue


async def _companion_watcher() -> None:
    from app.services.cowork_service import get_cowork_service
    from app.services.focus_service import get_focus_service
    from app.services.pomodoro_service import get_pomodoro_service

    focus = get_focus_service()
    cowork = get_cowork_service()
    pomodoro = get_pomodoro_service()
    while True:
        await asyncio.sleep(5)
        try:
            await asyncio.to_thread(focus.tick)
            await asyncio.to_thread(pomodoro.tick)
            await cowork.tick()
        except Exception as exc:
            note_error("companion_watcher", exc)
            continue


async def _routine_timeline_watcher() -> None:
    from app.services.routine_service import get_routine_service
    from app.services.settings_service import get_settings_service
    from app.services.timeline_service import get_timeline_service

    routine = get_routine_service()
    timeline = get_timeline_service()
    while True:
        await asyncio.sleep(30)
        try:
            data = get_settings_service().get()
            if data.get("routine_enabled", True):
                await asyncio.to_thread(routine.tick)
            if data.get("timeline_enabled", False):
                await asyncio.to_thread(timeline.capture)
        except Exception as exc:
            note_error("routine_timeline_watcher", exc)
            continue


async def _file_watcher() -> None:
    from app.services.settings_service import get_settings_service
    from app.services.watcher_service import get_watcher_service

    while True:
        await asyncio.sleep(12)
        try:
            data = get_settings_service().get()
            settings = get_settings()
            provider = data.get("provider") or settings.default_provider
            model = data.get("model") or settings.jon_model
            await get_watcher_service().tick(provider, model)
        except Exception as exc:
            note_error("file_watcher", exc)
            continue


async def _autofile_watcher() -> None:
    from app.services.autofile_service import get_autofile_service

    while True:
        await asyncio.sleep(20)
        try:
            await asyncio.to_thread(get_autofile_service().tick)
        except Exception as exc:
            note_error("autofile_watcher", exc)
            continue


async def _appusage_watcher() -> None:
    from app.services.settings_service import get_settings_service
    from app.services.appusage_service import get_appusage_service

    interval = 15
    while True:
        await asyncio.sleep(interval)
        try:
            if not get_settings_service().get().get("app_usage_enabled", False):
                continue
            await asyncio.to_thread(get_appusage_service().tick, interval)
        except Exception as exc:
            note_error("appusage_watcher", exc)
            continue


async def _chat_server() -> None:
    from app.services.p2p_service import CHAT_PORT

    config = uvicorn.Config(
        create_chat_app(),
        host="0.0.0.0",
        port=CHAT_PORT,
        log_level="warning",
        access_log=False,
    )
    server = uvicorn.Server(config)
    try:
        await server.serve()
    except asyncio.CancelledError:
        raise
    except (SystemExit, Exception) as exc:
        note_error("chat_server", exc)
        _log.info(f"Chat-Port {CHAT_PORT} belegt - P2P-Chat bleibt aus")
        return


async def _multiplayer_server() -> None:
    from app.services.multiplayer_service import get_multiplayer_service

    service = get_multiplayer_service()
    try:
        await service.start()
        await service.serve_stream("0.0.0.0", MP_TCP_PORT)
    except asyncio.CancelledError:
        raise
    except (SystemExit, Exception) as exc:
        note_error("multiplayer_server", exc)
        _log.info(f"Koop-Port {MP_TCP_PORT} belegt - Spiele-Server bleibt aus")
        return


async def _coop_beacon() -> None:
    from app.services.coop_lan_service import DISCOVERY_PORT, get_coop_beacon
    from app.services.multiplayer_service import get_multiplayer_service

    beacon = get_coop_beacon()
    beacon.bind(get_multiplayer_service(), MP_TCP_PORT, MP_WS_PORT)
    try:
        await beacon.serve(MP_TCP_PORT, MP_WS_PORT)
    except asyncio.CancelledError:
        raise
    except (SystemExit, Exception) as exc:
        note_error("coop_beacon", exc)
        _log.info(f"Koop-Suche auf {DISCOVERY_PORT} nicht moeglich")
        return


async def _coop_web_server() -> None:
    config = uvicorn.Config(
        create_coop_app(),
        host="0.0.0.0",
        port=MP_WS_PORT,
        log_level="warning",
        access_log=False,
    )
    server = uvicorn.Server(config)
    try:
        await server.serve()
    except asyncio.CancelledError:
        raise
    except (SystemExit, Exception) as exc:
        note_error("coop_web_server", exc)
        _log.info(f"Koop-Port {MP_WS_PORT} belegt - Browser-Koop nur lokal")
        return


def _parent_alive(pid: int) -> bool:
    if os.name == "nt":
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x00100000, False, pid)
        if not handle:
            return False
        try:
            return kernel32.WaitForSingleObject(handle, 0) != 0
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


async def _parent_watchdog() -> None:
    raw = os.environ.get("JON_PARENT_PID", "").strip()
    if not raw.isdigit():
        return
    pid = int(raw)
    if pid <= 0 or pid == os.getpid():
        return
    while True:
        await asyncio.sleep(2)
        if await asyncio.to_thread(_parent_alive, pid):
            continue
        _log.info("Jon-App beendet - Backend faehrt herunter")
        os._exit(0)


async def _share_beacon() -> None:
    from app.services.ollama_share_service import DISCOVERY_PORT, get_share_service

    try:
        await get_share_service().serve_discovery()
    except asyncio.CancelledError:
        raise
    except (SystemExit, Exception) as exc:
        note_error("share_beacon", exc)
        _log.info(f"Ollama-Freigabe-Suche auf {DISCOVERY_PORT} nicht moeglich")
        return


_tasks: dict[str, asyncio.Task] = {}


EINMALIG = {"warmup", "parent_watchdog"}


def _spawn(name: str, coro) -> asyncio.Task:
    task = asyncio.create_task(coro, name=name)
    _tasks[name] = task
    note_ok(name)
    task.add_done_callback(lambda done: _finished(name, done))
    return task


def _finished(name: str, task: asyncio.Task) -> None:
    if task.cancelled():
        return
    error = task.exception()
    if error is not None:
        note_error(name, error)
    elif name not in EINMALIG:
        _log.warning("Hintergrunddienst %s hat sich beendet", name)


def _stop_all() -> None:
    for task in _tasks.values():
        task.cancel()
    _tasks.clear()


@asynccontextmanager
async def lifespan(app: FastAPI):
    _log.info("STEP init_db")
    init_db()
    _log.info("STEP init_db ok")
    from app.services.trash_service import get_trash_service

    with suppress(Exception):
        get_trash_service().cleanup()
    from app.services.dateiraum_service import get_dateiraum_service

    with suppress(Exception):
        _log.info("STEP dateiraum %s", get_dateiraum_service().sicherstellen())
    from app.services.kern import verdrahten

    with suppress(Exception):
        verdrahten()
    from app.services.auftrag_service import get_auftrag_service

    with suppress(Exception):
        offen = get_auftrag_service().unterbrochene_markieren()
        if offen:
            _log.info("STEP %s unterbrochene Auftraege gefunden", offen)
    from app.services.aufgaben_service import get_aufgaben_service

    with suppress(Exception):
        wieder = get_aufgaben_service().unterbrochene_aufnehmen()
        if wieder:
            _log.info("STEP %s Aufgaben werden fortgesetzt", wieder)
    from app.services.research import get_research_service

    with suppress(Exception):
        get_research_service().boot()
    _spawn("premium", _premium_erneuern())
    _spawn("beobachten", _beobachten_watcher())
    from app.services.p2p_service import get_p2p_service

    p2p = get_p2p_service()
    _log.info("STEP p2p service ok")
    _spawn("warmup", _warm_caches())
    _spawn("dream_watcher", _dream_watcher())
    _spawn("pflege_watcher", _pflege_watcher())
    _spawn("initiative_watcher", _initiative_watcher())
    _spawn("konsolidierung_watcher", _konsolidierung_watcher())
    _spawn("wahrnehmung_watcher", _wahrnehmung_watcher())
    from app.services.mini_jon_agent import get_mini_jon_agent

    _spawn("mini_jon_context", get_mini_jon_agent().monitor())
    _spawn("neugier_watcher", _neugier_watcher())
    _spawn("aufgaben_watcher", _aufgaben_watcher())
    _spawn("ausloeser_watcher", _ausloeser_watcher())
    _spawn("hypothesen_watcher", _hypothesen_watcher())
    _spawn("fertigkeit_watcher", _fertigkeit_watcher())
    _spawn("clipboard_watcher", _clipboard_watcher())
    _spawn("friend_location_watcher", _friend_location_watcher())
    _spawn("task_watcher", _task_watcher())
    _spawn("telegram_watcher", _telegram_watcher())
    _spawn("group_bots_watcher", _group_bots_watcher())
    _spawn("geraet_app_watcher", _geraet_app_watcher())
    _spawn("wochenbericht_watcher", _wochenbericht_watcher())
    _spawn("morning_watcher", _morning_watcher())
    _spawn("companion_watcher", _companion_watcher())
    _spawn("phone_watcher", _phone_watcher())
    _spawn("routine_timeline_watcher", _routine_timeline_watcher())
    _spawn("file_watcher", _file_watcher())
    _spawn("autofile_watcher", _autofile_watcher())
    _spawn("appusage_watcher", _appusage_watcher())
    _spawn("chat_server", _chat_server())
    _spawn("multiplayer_server", _multiplayer_server())
    _spawn("coop_web_server", _coop_web_server())
    _spawn("coop_beacon", _coop_beacon())
    _spawn("share_beacon", _share_beacon())
    _spawn("parent_watchdog", _parent_watchdog())
    _spawn("p2p_announce", p2p.announce_loop())
    _spawn("p2p_listen", p2p.listen_loop())

    try:
        from app.services.quickwrite_service import get_quickwrite_service

        get_quickwrite_service().start_mouse_listener()
    except Exception as exc:
        note_error("quickwrite", exc)

    from app.services.relay_service import get_relay_service

    _log.info("STEP tasks ok")
    _spawn("relay", get_relay_service().start())

    from app.services.handy_relay import get_handy_relay

    _spawn("handy_relay", get_handy_relay().start())
    _spawn("p2p_outbox", p2p.outbox_loop())

    from app.services.live_service import get_live_service

    _spawn("live", get_live_service().schleife())

    from app.services.oekosystem_service import get_oekosystem

    _spawn("oekosystem", get_oekosystem().schleife())

    from app.services.telegram_plan import schleife as telegram_plan_schleife

    _spawn("telegram_plan", telegram_plan_schleife())

    async def _terminal_befehl() -> None:
        from app.services.terminal_service import automatisch

        try:
            ergebnis = await asyncio.to_thread(automatisch)
        except Exception as fehler:
            note_error("terminal_befehl", fehler)
            return
        if ergebnis.get("gemacht"):
            _log.info("STEP terminal befehl jon eingerichtet")

    _spawn("terminal_befehl", _terminal_befehl())
    _log.info("STEP vor yield")
    yield
    from app.services.harness import get_harness_service

    await get_harness_service().close()
    from app.services.harness.vorschau import get_vorschau

    await get_vorschau().close()
    from app.services.agenten_service import get_agenten_service

    await get_agenten_service().close()
    from app.services.media_service import get_media_service

    await get_media_service().close()
    _stop_all()
    with suppress(Exception):
        from app.services.phone_service import get_phone_service

        await get_phone_service().stop()


class WebApp(StaticFiles):
    async def get_response(self, path: str, scope):
        antwort = await super().get_response(path, scope)
        if antwort.headers.get("content-type", "").startswith("text/html"):
            antwort.headers["Cache-Control"] = "no-store"
        return antwort


def create_app() -> FastAPI:
    setup_logging()
    get_token()
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        lifespan=lifespan,
    )
    from app.services.premium import PremiumNoetig

    @app.exception_handler(PremiumNoetig)
    async def premium_noetig(request, exc: PremiumNoetig):
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=402, content={"detail": exc.text, "premium": exc.feature})

    app.add_middleware(TokenMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.origins(),
        allow_origin_regex=r"^(chrome|moz)-extension://[a-zA-Z0-9-]+$",
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(router)
    app.include_router(system_router)
    app.include_router(harness_router)
    app.include_router(premium_router)
    app.include_router(beobachten_router)
    app.include_router(support_router)
    app.include_router(agenten_router)
    app.include_router(media_router)
    app.include_router(p2p_router)
    app.include_router(multiplayer_router)
    app.include_router(phone_router)
    app.include_router(maps_router)
    app.include_router(project_router)
    app.include_router(inbox_router)
    app.include_router(handy_router)
    app.include_router(zeit_router)
    app.include_router(mediathek_router)
    app.include_router(anmeldung_router)
    app.include_router(live_router)
    app.include_router(verbund_router)
    app.include_router(oekosystem_router)
    app.include_router(research_router)
    app.include_router(studio_router)
    app.include_router(mobile_router)
    app.include_router(fitness_router)
    app.include_router(geraet_app_router)
    app.include_router(sicherung_router)
    app.include_router(browser_router)
    app.include_router(denken_router)
    app.include_router(datei_router)
    app.include_router(terminal_router)
    app.include_router(lehrer_router)
    app.include_router(btw_router)
    app.include_router(testumgebung_router)
    app.include_router(testumgebung_vorschau)

    from pathlib import Path

    from fastapi.responses import FileResponse

    game_file = Path(__file__).resolve().parent / "static" / "blockwelt.html"

    @app.get("/blockwelt")
    async def blockwelt():
        return FileResponse(game_file, media_type="text/html")

    katzen_file = Path(__file__).resolve().parent / "static" / "katzenhof.html"

    @app.get("/katzenhof")
    async def katzenhof():
        return FileResponse(katzen_file, media_type="text/html")

    live_file = Path(__file__).resolve().parent / "static" / "live.html"

    @app.get("/live")
    async def live():
        return FileResponse(
            live_file,
            media_type="text/html",
            headers={"Cache-Control": "no-store"},
        )

    private_file = Path(__file__).resolve().parent / "static" / "privat.html"

    @app.get("/privat")
    async def privat():
        return FileResponse(
            private_file,
            media_type="text/html",
            headers={"Cache-Control": "no-store"},
        )

    dist = web_app_dir()
    if dist is not None:
        app.mount("/app", WebApp(directory=str(dist), html=True), name="app")
    else:
        _log.warning("Web-Oberflaeche nicht gefunden - /app bleibt aus")
    return app


app = create_app()


def _port_in_use(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(1.0)
        return probe.connect_ex((host, port)) == 0


def _free_port(host: str, port: int) -> None:
    if not _port_in_use(host, port):
        return
    if os.name == "nt":
        subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                f"Get-NetTCPConnection -LocalPort {port} -State Listen "
                "-ErrorAction SilentlyContinue | "
                "Select-Object -ExpandProperty OwningProcess -Unique | "
                f"Where-Object {{ $_ -ne {os.getpid()} }} | "
                "ForEach-Object { Stop-Process -Id $_ -Force "
                "-ErrorAction SilentlyContinue }",
            ],
            capture_output=True,
            timeout=20,
        )
    else:
        subprocess.run(
            ["sh", "-c", f"lsof -ti tcp:{port} | xargs -r kill -9"],
            capture_output=True,
            timeout=20,
        )
    for _ in range(20):
        if not _port_in_use(host, port):
            return
        time.sleep(0.25)


def main() -> None:
    import sys

    if len(sys.argv) > 1 and sys.argv[1].lower() in ("cli", "terminal", "jon"):
        from app.cli import main as cli_main

        cli_main(sys.argv[2:])
        return
    settings = get_settings()
    from app.core.heimnetz import lan_aktiv

    host = "0.0.0.0" if lan_aktiv() else settings.host
    _free_port(settings.host, settings.port)
    uvicorn.run(
        "app.main:app",
        host=host,
        port=settings.port,
        reload=False,
    )


if __name__ == "__main__":
    main()
