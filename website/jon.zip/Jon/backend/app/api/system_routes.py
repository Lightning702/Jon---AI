from __future__ import annotations

import asyncio
import base64
import mimetypes
import os
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel

from app.core.heimnetz import lan_aktiv
from app.services.system_service import SystemService

router = APIRouter(prefix="/api/system")
_service = SystemService()
_voice = None
_voice_error: str | None = None


def _get_voice():
    global _voice, _voice_error
    if _voice is None and _voice_error is None:
        try:
            from app.services.voice_service import VoiceService

            _voice = VoiceService()
        except Exception as exc:
            _voice_error = str(exc)
    if _voice is None:
        raise HTTPException(
            status_code=501,
            detail=(
                "Spracherkennung nicht verfuegbar: "
                f"{_voice_error}. Installiere: pip install SpeechRecognition audioop-lts"
            ),
        )
    return _voice


class CommandIn(BaseModel):
    command: str


class CommandOut(BaseModel):
    exit_code: int
    stdout: str
    stderr: str


class UrlIn(BaseModel):
    url: str


class ProgramIn(BaseModel):
    path: str
    args: list[str] = []


class NameIn(BaseModel):
    name: str


class PathIn(BaseModel):
    path: str


class MoveIn(BaseModel):
    source: str
    destination: str


class WriteIn(BaseModel):
    path: str
    content: str


@router.post("/powershell", response_model=CommandOut)
async def powershell(payload: CommandIn) -> CommandOut:
    try:
        result = _service.run_powershell(payload.command)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return CommandOut(**result.__dict__)


@router.post("/cmd", response_model=CommandOut)
async def cmd(payload: CommandIn) -> CommandOut:
    try:
        result = _service.run_cmd(payload.command)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return CommandOut(**result.__dict__)


@router.post("/open-url")
async def open_url(payload: UrlIn) -> dict:
    return {"opened": _service.open_url(payload.url)}


@router.post("/start-program")
async def start_program(payload: ProgramIn) -> dict:
    try:
        pid = _service.start_program(payload.path, payload.args)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"pid": pid}


@router.post("/kill-program", response_model=CommandOut)
async def kill_program(payload: NameIn) -> CommandOut:
    result = _service.kill_program(payload.name)
    return CommandOut(**result.__dict__)


@router.post("/explorer")
async def open_explorer(payload: PathIn) -> dict:
    try:
        _service.open_explorer(payload.path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"opened": True}


@router.post("/files/list")
async def list_dir(payload: PathIn) -> list[dict]:
    try:
        return _service.list_dir(payload.path)
    except NotADirectoryError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/files/read")
async def read_file(payload: PathIn) -> dict:
    try:
        return {"content": _service.read_file(payload.path)}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/files/write")
async def write_file(payload: WriteIn) -> dict:
    _service.write_file(payload.path, payload.content)
    return {"written": True}


@router.post("/files/mkdir")
async def make_dir(payload: PathIn) -> dict:
    try:
        created = _service.make_dir(payload.path)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"created": created}


@router.post("/files/read-base64")
async def read_file_base64(payload: PathIn) -> dict:
    target = Path(payload.path).expanduser()
    if not target.is_file():
        raise HTTPException(status_code=404, detail=str(target))
    try:
        data = target.read_bytes()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    if len(data) > 25_000_000:
        raise HTTPException(status_code=413, detail="Datei zu gross")
    mime = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
    return {"data": base64.b64encode(data).decode("ascii"), "mime": mime}


@router.post("/files/move")
async def move_path(payload: MoveIn) -> dict:
    try:
        result = _service.move_path(payload.source, payload.destination)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"moved_to": result}


@router.post("/files/delete")
async def delete_path(payload: PathIn) -> dict:
    try:
        _service.delete_path(payload.path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"deleted": True}


class TtsIn(BaseModel):
    text: str
    voice: str = "de-DE-ConradNeural"
    rate: str = "+8%"
    volume: str = "+45%"
    pitch: str = "+0Hz"


@router.post("/tts")
async def tts(payload: TtsIn):
    from fastapi.responses import Response

    try:
        from app.services.voice_service import synthesize_speech

        audio = await synthesize_speech(
            payload.text,
            payload.voice,
            payload.rate,
            payload.volume,
            payload.pitch,
        )
    except Exception as exc:
        raise HTTPException(status_code=501, detail=str(exc))
    if not audio:
        raise HTTPException(status_code=400, detail="kein Text")
    return Response(content=audio, media_type="audio/mpeg")


@router.get("/health-check")
async def health_check() -> dict:
    return await asyncio.to_thread(_service.health_check)


@router.post("/transcribe")
async def transcribe(request: Request) -> dict:
    data = await request.body()
    if not data:
        raise HTTPException(status_code=400, detail="keine Audiodaten")
    voice = _get_voice()
    try:
        text = await asyncio.to_thread(voice.transcribe_wav, data)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    return {"text": text}


@router.post("/vscode")
async def open_vscode(payload: PathIn) -> dict:
    try:
        pid = _service.open_in_vscode(payload.path)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"pid": pid}


@router.post("/pick-folder")
async def pick_folder() -> dict:
    try:
        path = await asyncio.to_thread(_service.choose_folder)
    except Exception as exc:
        raise HTTPException(status_code=501, detail=str(exc))
    return {"path": path}


@router.get("/idle")
async def idle() -> dict:
    return {"seconds": _service.idle_seconds()}


class UninstallIn(BaseModel):
    bestaetigung: str
    programm_entfernen: bool = True


class AutostartIn(BaseModel):
    enabled: bool


@router.get("/autostart")
async def autostart_status() -> dict:
    return {"enabled": _service.autostart_status()}


@router.post("/autostart")
async def set_autostart(payload: AutostartIn) -> dict:
    try:
        enabled = await asyncio.to_thread(_service.set_autostart, payload.enabled)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"enabled": enabled}


@router.post("/path-info")
async def path_info(payload: PathIn) -> dict:
    target = Path(payload.path).expanduser()
    return {
        "exists": target.exists(),
        "is_dir": target.is_dir(),
        "parent": str(target.parent),
    }


@router.get("/whoami")
async def whoami() -> dict:
    from app.core.config import get_settings

    return {"pid": os.getpid(), "version": get_settings().app_version}


async def _exit_soon(delay: float) -> None:
    await asyncio.sleep(delay)
    print("Jon-App hat das Herunterfahren angefordert", flush=True)
    os._exit(0)


@router.get("/uninstall/plan")
async def uninstall_plan() -> dict:
    from app.services.uninstall_service import plan

    return await asyncio.to_thread(plan)


@router.post("/uninstall")
async def uninstall(payload: UninstallIn) -> dict:
    from app.services.uninstall_service import ausfuehren

    try:
        ergebnis = await asyncio.to_thread(
            ausfuehren, payload.bestaetigung, payload.programm_entfernen
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    asyncio.create_task(_exit_soon(1.2))
    return ergebnis


@router.post("/shutdown")
async def shutdown() -> dict:
    from app.core.logbook import since_boot

    if since_boot() < 15:
        return {"stopping": False, "grund": "gerade erst gestartet", "pid": os.getpid()}
    asyncio.create_task(_exit_soon(0.35))
    return {"stopping": True, "pid": os.getpid()}


@router.get("/telegram")
async def telegram_stand() -> dict:
    from app.services.telegram_service import get_telegram_service

    return await get_telegram_service().diagnose()


class Meldung(BaseModel):
    text: str


@router.post("/telegram/melden")
async def telegram_melden(daten: Meldung) -> dict:
    from app.services.beobachten import _telegram

    text = daten.text.strip()[:3500]
    if not text:
        raise HTTPException(status_code=400, detail="Die Meldung ist leer.")
    try:
        return {"gesendet": await _telegram(text)}
    except Exception as fehler:
        raise HTTPException(status_code=502, detail=f"Telegram nicht erreichbar: {fehler}")


@router.get("/diagnostics")
async def diagnostics() -> dict:
    from app.core.auth import lan_address, rejected
    from app.core.config import DATA_DIR, get_settings
    from app.core.fehler import bericht as stiller_bericht
    from app.core.logbook import LOG_FILE, recent, since_boot, snapshot

    settings = get_settings()
    dienste = snapshot()
    return {
        "version": settings.app_version,
        "laufzeit": round(since_boot(), 1),
        "port": settings.port,
        "lan": lan_aktiv(),
        "adresse": lan_address() if lan_aktiv() else "127.0.0.1",
        "datenverzeichnis": str(DATA_DIR),
        "protokolldatei": str(LOG_FILE),
        "dienste": dienste,
        "fehlerhaft": [d["dienst"] for d in dienste if d.get("fehler")],
        "abgewiesen": rejected()["anzahl"],
        "stille_fehler": stiller_bericht(20),
        "meldungen": recent(200),
    }


@router.get("/log")
async def log_export() -> Response:
    from app.core.logbook import export_text

    text = await asyncio.to_thread(export_text)
    return Response(
        content=text,
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="jon-protokoll.txt"'},
    )


@router.get("/pairing")
async def pairing() -> dict:
    from app.core.auth import get_token, lan_address, pair_url
    from app.core.config import get_settings

    from app.core.config import ENV_FILE, web_app_dir

    settings = get_settings()
    return {
        "token": get_token(),
        "lan": lan_aktiv(),
        "adresse": lan_address(),
        "port": settings.port,
        "url": pair_url(settings.port, lan_aktiv()),
        "oberflaeche": web_app_dir() is not None,
        "env_datei": str(ENV_FILE),
    }


@router.post("/pairing/reset")
async def pairing_reset() -> dict:
    from app.core.auth import reset_token
    from app.core.config import get_settings

    settings = get_settings()
    token = await asyncio.to_thread(reset_token)
    from app.core.auth import pair_url

    return {"token": token, "url": pair_url(settings.port, lan_aktiv())}


@router.get("/terminal")
async def terminal_stand() -> dict:
    from app.services.terminal_service import stand

    return await asyncio.to_thread(stand)


@router.post("/terminal")
async def terminal_einrichten() -> dict:
    from app.services.terminal_service import einrichten

    ergebnis = await asyncio.to_thread(einrichten)
    if ergebnis.get("error"):
        raise HTTPException(status_code=500, detail=ergebnis["error"])
    return ergebnis


@router.delete("/terminal")
async def terminal_entfernen() -> dict:
    from app.services.terminal_service import entfernen

    ergebnis = await asyncio.to_thread(entfernen)
    if ergebnis.get("error"):
        raise HTTPException(status_code=500, detail=ergebnis["error"])
    return ergebnis
