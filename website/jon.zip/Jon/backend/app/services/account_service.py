from __future__ import annotations

import json
import threading

from app.core.config import DATA_DIR
from app.core.store import atomic_write_text
from app.core.fehler import leise

ACCOUNTS_FILE = DATA_DIR / "accounts.json"

SUPPORTED = {
    "openai": {
        "label": "OpenAI",
        "env_var": "OPENAI_API_KEY",
        "auth": "api_key",
        "docs": "https://platform.openai.com/api-keys",
    },
    "anthropic": {
        "label": "Anthropic (Claude)",
        "env_var": "ANTHROPIC_API_KEY",
        "auth": "api_key",
        "docs": "https://console.anthropic.com/settings/keys",
    },
    "nvidia": {
        "label": "NVIDIA NIM",
        "env_var": "NVIDIA_API_KEY",
        "auth": "api_key",
        "docs": "https://build.nvidia.com",
    },
    "gemini": {
        "label": "Google Gemini",
        "env_var": "GOOGLE_API_KEY",
        "auth": "api_key",
        "docs": "https://aistudio.google.com/apikey",
    },
    "deepseek": {
        "label": "DeepSeek",
        "env_var": "DEEPSEEK_API_KEY",
        "auth": "api_key",
        "docs": "https://platform.deepseek.com",
    },
    "mistral": {
        "label": "Mistral",
        "env_var": "MISTRAL_API_KEY",
        "auth": "api_key",
        "docs": "https://console.mistral.ai",
    },
    "glm": {
        "label": "Zhipu GLM",
        "env_var": "GLM_API_KEY",
        "auth": "api_key",
        "docs": "https://open.bigmodel.cn",
    },
    "qwen": {
        "label": "Alibaba Qwen",
        "env_var": "QWEN_API_KEY",
        "auth": "api_key",
        "docs": "https://dashscope.console.aliyun.com",
    },
    "openrouter": {
        "label": "OpenRouter",
        "env_var": "OPENROUTER_API_KEY",
        "auth": "api_key",
        "docs": "https://openrouter.ai/keys",
    },
    "groq": {
        "label": "Groq",
        "env_var": "GROQ_API_KEY",
        "auth": "api_key",
        "docs": "https://console.groq.com/keys",
    },
    "together": {
        "label": "Together AI",
        "env_var": "TOGETHER_API_KEY",
        "auth": "api_key",
        "docs": "https://api.together.xyz/settings/api-keys",
    },
    "xai": {
        "label": "xAI (Grok)",
        "env_var": "XAI_API_KEY",
        "auth": "api_key",
        "docs": "https://console.x.ai",
    },
    "ollama": {
        "label": "Ollama (lokal)",
        "env_var": "OLLAMA_BASE_URL",
        "auth": "local",
        "docs": "https://ollama.com/download",
    },
    "lmstudio": {
        "label": "LM Studio (lokal)",
        "env_var": "LMSTUDIO_BASE_URL",
        "auth": "local",
        "docs": "https://lmstudio.ai",
    },
}

LOCAL_PROVIDERS = {"ollama", "lmstudio"}

UNAVAILABLE = "Über die offizielle API nicht verfügbar"


class AccountService:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._data: dict[str, dict] = self._load()

    def _load(self) -> dict:
        from app.core.krypto import ist_verschluesselt, text_lesen

        if not ACCOUNTS_FILE.exists():
            return {}
        try:
            daten = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
        if not isinstance(daten, dict):
            return {}
        klartext = False
        for anbieter, eintrag in daten.items():
            if not isinstance(eintrag, dict) or not eintrag.get("api_key"):
                continue
            if not ist_verschluesselt(eintrag["api_key"]):
                klartext = True
            eintrag["api_key"] = text_lesen(eintrag["api_key"], f"api-key:{anbieter}")
        if klartext:
            self._data = daten
            self._save()
        return daten

    def _save(self) -> None:
        from app.core.krypto import text_verschluesseln

        try:
            ablage = {}
            for anbieter, eintrag in self._data.items():
                kopie = dict(eintrag) if isinstance(eintrag, dict) else eintrag
                if isinstance(kopie, dict) and kopie.get("api_key"):
                    kopie["api_key"] = text_verschluesseln(
                        str(kopie["api_key"]), f"api-key:{anbieter}"
                    )
                ablage[anbieter] = kopie
            atomic_write_text(ACCOUNTS_FILE,
                json.dumps(ablage, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception as _fehler:
            leise(_fehler, "services/account_service")

    def runtime_key(self, provider: str) -> str | None:
        entry = self._data.get(provider)
        if entry and entry.get("api_key"):
            return str(entry["api_key"]).strip() or None
        return None

    def default_model(self, provider: str) -> str | None:
        entry = self._data.get(provider)
        if entry and entry.get("default_model"):
            return entry["default_model"]
        return None

    def connect(self, provider: str, api_key: str, default_model: str | None = None) -> dict:
        if provider not in SUPPORTED:
            raise ValueError("Nicht unterstützter Anbieter")
        with self._lock:
            entry = self._data.setdefault(provider, {})
            entry["api_key"] = api_key.strip()
            if default_model:
                entry["default_model"] = default_model
            self._save()
        return {"provider": provider, "connected": True}

    def set_default_model(self, provider: str, model: str) -> dict:
        with self._lock:
            entry = self._data.setdefault(provider, {})
            entry["default_model"] = model
            self._save()
        return {"provider": provider, "default_model": model}

    def disconnect(self, provider: str) -> bool:
        with self._lock:
            existed = provider in self._data
            self._data.pop(provider, None)
            self._save()
            return existed

    def status(
        self, provider: str, env_configured: bool, local_reachable: bool | None = None
    ) -> dict:
        meta = SUPPORTED[provider]
        entry = self._data.get(provider, {})
        is_local = meta["auth"] == "local"
        if is_local:
            connected = bool(local_reachable)
            source = "local" if connected else None
        else:
            connected = bool(entry.get("api_key")) or env_configured
            source = "account" if entry.get("api_key") else ("env" if env_configured else None)
        return {
            "provider": provider,
            "label": meta["label"],
            "auth": meta["auth"],
            "docs": meta["docs"],
            "connected": connected,
            "source": source,
            "default_model": entry.get("default_model"),
            "account_name": "Lokal auf deinem Gerät" if is_local else UNAVAILABLE,
            "avatar_url": None,
            "plan": "Kostenlos (lokal)" if is_local else UNAVAILABLE,
        }


_service: AccountService | None = None


def get_account_service() -> AccountService:
    global _service
    if _service is None:
        _service = AccountService()
    return _service
