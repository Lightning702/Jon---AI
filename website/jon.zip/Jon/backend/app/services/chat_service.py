from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from typing import AsyncIterator

from app.core.config import (
    DATA_DIR,
    NVIDIA_EMIL_MODELL,
    NVIDIA_JON_MODELL,
    get_settings,
    lebendes_modell,
)
from app.core.store import atomic_write_json, read_json
from app.core.logbook import logger as logbook_logger
from app.db.database import session_scope
from app.db.models import Conversation, Message
from app.providers.base import ChatMessage, ChatRequest, StreamChunk
from app.providers.registry import get_registry
from app.schemas import ChatIn
from app.core.fehler import leise
from app.services.approval_service import ToolDeniedError, get_approval_service
from app.services.browser.sitzung import setzen as browser_sitzung
from app.services.budget_service import get_budget_service
from app.services.coding import (
    CODING_PROMPT,
    DESIGN_PROMPT,
    active_file_context,
    mentioned_files_context,
    workspace_summary,
)
from app.services.memory_service import MemoryService
from app.services.persona_service import get_persona_service
from app.services.premium import unbegrenzt
from app.services.history import trim_history
from app.services.settings_service import get_settings_service
from app.services.skill_service import SkillService
from app.services.risiko import bewerten as risiko_bewerten
from app.services.risiko import braucht_freigabe
from app.services.tools import GUEST_TOOLS, SAFE_TOOLS, ToolBox, describe_tool
from app.services.verlauf_service import get_verlauf_service
from app.services.systemprompt import EHRLICHKEIT as HONESTY_RULE
from app.services.systemprompt import ENGLISCH
from app.services.systemprompt import bauen as prompt_bauen
from app.services.systemprompt import mit_herkunft
from app.services.usage_service import get_usage_service

_log = logbook_logger("chat")

SYSTEM_PROMPT = prompt_bauen()


WOCHENTAGE = (
    "Montag",
    "Dienstag",
    "Mittwoch",
    "Donnerstag",
    "Freitag",
    "Samstag",
    "Sonntag",
)


DENK_WUENSCHE = ("denk nach", "denk gründlich", "denk gruendlich", "überleg", "ueberleg", "genau nachdenken", "schritt für schritt", "schritt fuer schritt", "think", "beweise", "herleit")


DENK_THEMEN = re.compile(
    r"\b(?:cod(?:e|en|ier)|programmier|skript|script|html|css|javascript|typescript|python|php|java\b|c\+\+|sql|"
    r"spiel|game|website|webseite|homepage|app\b|algorithm|debug|fehler(?:suche|meldung)|erkl(?:ae|ä)r|warum|wieso|weshalb|"
    r"wie funktioniert|analysier|vergleich|plane|planung|berechne|rechne|beweis|herleit|optimier|strategie|konzept)",
    re.IGNORECASE,
)


def denken_noetig(text: str, urteil: dict | None, coding: bool) -> bool | None:
    klein = (text or "").lower()
    if any(wunsch in klein for wunsch in DENK_WUENSCHE):
        return True
    if len(klein) >= 12 and DENK_THEMEN.search(klein):
        return True
    if coding:
        return True
    if urteil and urteil.get("stufe") == "gruendlich":
        return True
    return None


def heute_block() -> str:
    from datetime import datetime

    jetzt = datetime.now()
    tag = WOCHENTAGE[jetzt.weekday()]
    return (
        f"HEUTE IST {tag}, der {jetzt.strftime('%d.%m.%Y')}, {jetzt.strftime('%H:%M')} "
        "Uhr. Dein antrainiertes Wissen endet lange davor und ist bei allem veraltet, "
        "was sich aendert. Bei Preisen, Produkten, Modell- und Versionsnamen, Personen "
        "im Amt, News, Terminen, Ergebnissen und Kursen antwortest du NIEMALS aus dem "
        "Gedaechtnis, sondern rufst zuerst web_search auf - auch wenn du glaubst, die "
        "Antwort zu kennen. Nenne nie etwas 'das neueste', ohne vorher gesucht zu "
        "haben. Was die Suche findet, gilt, auch wenn es deinem Wissen widerspricht: "
        "Kennst du ein Produkt oder Ereignis nicht, sag NIE, dass es das nicht gibt, "
        "sondern such danach. Rechne auch Zeitangaben ('naechstes Jahr', 'in drei "
        "Wochen') immer ab dem heutigen Datum. EINE Suche reicht: such einmal, lies "
        "die Treffer und antworte damit. Eine zweite Suche machst du nur, wenn die "
        "erste wirklich nichts Brauchbares hergab, und danach antwortest du mit dem, "
        "was du hast - hoechstens zwei Suchen pro Frage. Reihenweise Nachschlagen "
        "kostet den Nutzer nur Zeit. ZAHLEN ERFINDEST DU NIE: Preise, Betraege, "
        "Datumsangaben, Versionsnummern und technische Werte nennst du nur, wenn sie "
        "so im Suchergebnis stehen - im Titel, im Auszug oder im gelesenen "
        "Seitentext. Steht der Preis nicht drin, sagst du genau das und nennst die "
        "Seite, auf der er zu finden waere. Ein geschaetzter oder ausgedachter Preis "
        "ist schlimmer als keiner."
    )


WEBCAM_WORDS = re.compile(r"web\s*-?\s*cam|kamera", re.I)
WEBCAM_VERBS = re.compile(
    r"sieh|seh|schau|guck|blick|beschreib|zeig|erkenn|look|what.*see", re.I
)


def wants_webcam(text: str) -> bool:
    if not text:
        return False
    return bool(WEBCAM_WORDS.search(text)) and bool(WEBCAM_VERBS.search(text))


TOOL_JSON_FENCE = re.compile(r"^```[a-zA-Z_]*\s*(.*?)\s*```$", re.S)


def parse_text_tool_call(text: str) -> tuple[str, dict] | None:
    t = text.strip()
    m = TOOL_JSON_FENCE.match(t)
    if m:
        t = m.group(1).strip()
    if not (t.startswith("{") and t.endswith("}")):
        return None
    try:
        data = json.loads(t)
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    func = data.get("function") if isinstance(data.get("function"), dict) else {}
    name = (
        data.get("name")
        or data.get("tool")
        or data.get("tool_name")
        or func.get("name")
    )
    if not isinstance(name, str) or not name.strip():
        return None
    args = data.get("arguments", data.get("parameters", func.get("arguments", {})))
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except Exception:
            args = {}
    if isinstance(args, list):
        merged: dict = {}
        for item in args:
            if isinstance(item, dict):
                if "label" in item and set(item.keys()) <= {"label", "value", "note"}:
                    merged[str(item["label"])] = item.get("value", item.get("note", ""))
                else:
                    merged.update(item)
        args = merged
    if not isinstance(args, dict):
        args = {}
    return name.strip(), args


def looks_like_tool_start(text: str) -> bool:
    t = text.lstrip()
    if not t:
        return True
    if t.startswith("{"):
        return True
    if t.startswith("`"):
        if not t.startswith("```"):
            return len(t) < 3
        head = t[3:]
        if "\n" not in head:
            return len(head.strip()) <= 10
        lang, body = head.split("\n", 1)
        if lang.strip().lower() not in ("", "json", "tool", "tool_code", "tool_call"):
            return False
        stripped = body.lstrip()
        return not stripped or stripped.startswith("{")
    return False


FALLBACK_MODELS = {
    "nvidia": NVIDIA_JON_MODELL,
    "openrouter": "meta-llama/llama-3.1-8b-instruct:free",
    "groq": "llama-3.3-70b-versatile",
}

ZWEITER_ERSATZ = {
    "nvidia": NVIDIA_EMIL_MODELL,
}

WECHSEL_RUNDEN = 8

GEDULD_QUELLEN = {
    "telegram": 45.0,
    "telegram-gruppe": 45.0,
}

OLLAMA_UNGEEIGNET = ("embed", "image", ":cloud", "whisper", "tts")

OPENROUTER_FREE_DEFAULTS = (
    "meta-llama/llama-3.3-70b-instruct:free",
    "meta-llama/llama-3.1-8b-instruct:free",
    "deepseek/deepseek-chat-v3-0324:free",
    "google/gemini-2.0-flash-exp:free",
    "qwen/qwen-2.5-72b-instruct:free",
)

ALTERNATIVE_PROVIDERS = (
    "felworks",
    "groq",
    "openrouter",
    "together",
    "nvidia",
    "openai",
    "deepseek",
    "mistral",
    "glm",
    "qwen",
    "xai",
)

SLOW_ROUTE_MEMORY = 900.0
SLOW_ROUTE_FILE = DATA_DIR / "langsame_wege.json"
_slow_routes: dict[tuple[str, str], float] = {}
_slow_loaded = False


def _slow_laden() -> None:
    global _slow_loaded
    if _slow_loaded:
        return
    _slow_loaded = True
    roh = read_json(SLOW_ROUTE_FILE, None)
    if not isinstance(roh, dict):
        return
    jetzt = time.time()
    for schluessel, stempel in roh.items():
        anbieter, _, modell = str(schluessel).partition("|")
        try:
            wert = float(stempel)
        except (TypeError, ValueError):
            continue
        if anbieter and modell and jetzt - wert < SLOW_ROUTE_MEMORY:
            _slow_routes[(anbieter, modell)] = wert


def _slow_sichern() -> None:
    try:
        atomic_write_json(
            SLOW_ROUTE_FILE,
            {f"{a}|{m}": wert for (a, m), wert in _slow_routes.items()},
        )
    except Exception as _fehler:
        leise(_fehler, "services/chat_service")


def mark_slow(provider: str, model: str) -> None:
    _slow_laden()
    _slow_routes[(provider, model)] = time.time()
    _slow_sichern()


def mark_fast(provider: str, model: str) -> None:
    _slow_laden()
    if _slow_routes.pop((provider, model), None) is not None:
        _slow_sichern()


def is_slow(provider: str, model: str) -> bool:
    _slow_laden()
    stamp = _slow_routes.get((provider, model), 0.0)
    return time.time() - stamp < SLOW_ROUTE_MEMORY

TEXT_TOOL_RUNDEN = 12

CARD_TOOLS = {
    "maps": "maps",
    "wo_ist": "maps",
    "geraet_verbinden": "kopplung",
    "karteikarten": "karteikarten",
    "bild_zeigen": "webbild",
    "bild_suche": "webbild",
    "deep_learning": "deep_learning",
    "create_image": "bild",
    "browser_task": "browser",
    "datei_erstellen": "datei",
    "podcast_erstellen": "datei",
    "blender_szene": "datei",
    "blender_render": "datei",
    "blender_export": "datei",
    "dateien_finden": "datei",
    "start_timer": "zeit",
    "start_stopwatch": "zeit",
    "stop_timer": "zeit",
    "list_timers": "zeit",
    "adjust_timer": "zeit",
    "control_timer": "zeit",
    "set_alarm": "zeit",
    "list_alarms": "zeit",
    "delete_alarm": "zeit",
}

OFFEN_ERZWUNGEN = {"bild_zeigen"}

FORCED_PROMPTS = {
    "bild_zeigen": (
        "Der Nutzer will es visualisiert haben (Befehl /visualise). Rufe fuer diese Nachricht "
        "ZUERST bild_zeigen mit einem treffenden englischen Suchbegriff auf (bei mehreren "
        "Dingen anzahl 2 oder 3), dann beantworte die Frage vollstaendig und anschaulich und "
        "beziehe dich auf das Bild. Darfst dafuer auch web_search nutzen."
    ),
    "maps": (
        "Der Nutzer hat Jon Maps ausdruecklich angefordert (Befehl /maps). Du MUSST "
        "fuer diese Nachricht das Tool maps aufrufen, bevor du antwortest - ueberlege "
        "nicht, ob eine Karte passt, sondern nutze sie. Der Ort steht bereits "
        "vollstaendig in der Nachricht: uebernimm ihn genau so, wie er dort steht, "
        "samt Strasse, Hausnummer, Postleitzahl und Ort. Frage NIEMALS zurueck, in "
        "welcher Stadt oder Gegend das liegt, und antworte nicht mit einer allgemeinen "
        "Liste. Stehen Koordinaten in der Nachricht, gib sie als around='breite,laenge' "
        "bzw. query='breite,laenge' an. Fuer 'Was kann ich hier unternehmen' nimmst du "
        "action='umgebung' mit einem passenden Filter (sehenswuerdigkeit, restaurant, "
        "cafe, bar, park, geschaeft) und genau diesem Ort als Mittelpunkt. Schreibe "
        "danach eine kurze Antwort, die die echten Treffer aus dem Ergebnis mit Namen "
        "und Entfernung nennt."
    ),
    "deep_learning": (
        "Der Nutzer hat Jon Deep Learning ausdruecklich angefordert. Rufe fuer diese "
        "Nachricht das Tool deep_learning auf, bevor du antwortest."
    ),
}


def forced_tools(tools: list[dict], name: str) -> list[dict]:
    if not name:
        return tools
    picked = [t for t in tools if t.get("function", {}).get("name") == name]
    return picked or tools


def scoped_tools(tools: list[dict], scope: str) -> list[dict]:
    if scope != "gast":
        return tools
    return [
        tool for tool in tools if tool.get("function", {}).get("name") in GUEST_TOOLS
    ]


def _zeit_karte(_data: dict) -> dict | None:
    from app.services.zeit_service import get_zeit_service

    uhren = get_zeit_service().stand().get("uhren", [])
    if not uhren:
        return None
    return {"kind": "zeit", "data": {"uhren": uhren}}


def _wo_ist_karte(data: dict) -> dict | None:
    if not data.get("ok") or not isinstance(data.get("lat"), (int, float)):
        return None
    person = str(data.get("person") or "Gesucht")
    ort = {
        "id": f"wo-ist-{person}",
        "name": person,
        "label": str(data.get("adresse") or data.get("geraet") or ""),
        "lat": float(data["lat"]),
        "lon": float(data["lon"]),
        "kind": "person",
        "category": str(data.get("typ") or ""),
        "address": {},
        "source": "jon",
        "extra": {"icon": "📱"},
    }
    zusatz = " (zuhause)" if data.get("zuhause") else ""
    return {
        "kind": "maps",
        "data": {
            "aktion": "suche",
            "anfrage": f"Wo ist {person}?",
            "text": f"{person}: {data.get('adresse') or 'Standort'}{zusatz} · {data.get('wann', '')}",
            "treffer": [ort],
            "karte": {"center": {"lat": ort["lat"], "lon": ort["lon"]}, "zoom": 16, "marker": [ort]},
        },
    }


def werkstatt_anhaengen(name, args, event: dict) -> None:
    from app.services.werkstatt import vorschau

    daten = vorschau(name or "", args or {})
    if daten:
        event["werkstatt"] = daten


def werkstatt_fertig(name, result, event: dict) -> None:
    from app.services.werkstatt import ergebnis

    daten = ergebnis(name or "", result)
    if daten:
        event["werkstatt_ergebnis"] = daten


def card_payload(name: str | None, result: str | None) -> dict | None:
    kind = CARD_TOOLS.get(name or "")
    if kind is None or not result:
        return None
    try:
        data = json.loads(result)
    except Exception:
        return None
    if not isinstance(data, dict) or data.get("error"):
        return None
    if kind == "datei":
        dateien = []
        if isinstance(data.get("datei"), dict):
            dateien.append(data["datei"])
        for eintrag in data.get("dateien") or []:
            if isinstance(eintrag, dict) and eintrag.get("path"):
                dateien.append(eintrag)
        if not dateien:
            return None
        gesehen = set()
        eindeutig = []
        for eintrag in dateien:
            pfad = str(eintrag.get("path", ""))
            if pfad and pfad not in gesehen:
                gesehen.add(pfad)
                eindeutig.append(eintrag)
        return {"kind": kind, "data": {"dateien": eindeutig}}
    if kind == "zeit":
        return _zeit_karte(data)
    if name == "wo_ist":
        return _wo_ist_karte(data)
    if kind == "kopplung":
        from app.services.werkzeuge_chatkarten import karte_kopplung

        return karte_kopplung(data)
    if kind == "karteikarten":
        from app.services.werkzeuge_chatkarten import karte_karteikarten

        return karte_karteikarten(data)
    if kind == "webbild":
        from app.services.werkzeuge_chatkarten import karte_webbild

        return karte_webbild(data)
    if kind == "deep_learning":
        task = data.get("task")
        if isinstance(task, dict) and task.get("id"):
            return {"kind": kind, "data": {"id": task["id"], "task": task}}
        active = data.get("aktiv")
        if isinstance(active, list) and active:
            return {"kind": kind, "data": {"id": active[0]["id"], "task": active[0]}}
        if data.get("id"):
            return {"kind": kind, "data": {"id": data["id"], "task": data}}
        return None
    return {"kind": kind, "data": data}


TOOL_PROVIDERS = {
    "nvidia",
    "felworks",
    "openai",
    "deepseek",
    "mistral",
    "glm",
    "qwen",
    "ollama",
    "lmstudio",
    "openrouter",
    "groq",
    "together",
    "xai",
}



async def openrouter_free_model(registry, model: str) -> str:
    if model.endswith(":free"):
        return model
    try:
        models = await registry.get("openrouter").list_models()
    except Exception:
        models = []
    candidate = f"{model}:free"
    if candidate in models:
        return candidate
    for name in OPENROUTER_FREE_DEFAULTS:
        if name in models:
            return name
    return OPENROUTER_FREE_DEFAULTS[0]


async def route_providers(registry, primary: str, model: str) -> list[str]:
    usable = [primary]
    if not get_settings_service().get().get("auto_failover", True):
        return usable
    for name in ALTERNATIVE_PROVIDERS:
        if name in usable:
            continue
        try:
            provider = registry.get(name)
        except Exception:
            continue
        if not provider.available():
            continue
        try:
            models = await provider.list_models()
        except Exception:
            continue
        if name == "openrouter":
            if (
                (model.endswith(":free") and model in models)
                or f"{model}:free" in models
                or any(m in models for m in OPENROUTER_FREE_DEFAULTS)
            ):
                usable.append(name)
        elif model in models:
            usable.append(name)
    healthy = [name for name in usable if not is_slow(name, model)]
    stalled = [name for name in usable if is_slow(name, model)]
    return healthy + stalled


async def attempt_plan_for(
    registry, primary: str, names: list[str], model: str
) -> list[tuple[str, str]]:
    attempts: list[tuple[str, str]] = []
    for name in names:
        if name == "openrouter" and name != primary:
            attempts.append((name, await openrouter_free_model(registry, model)))
        else:
            attempts.append((name, model))
    fallback = FALLBACK_MODELS.get(primary, "")
    if fallback == model:
        fallback = ZWEITER_ERSATZ.get(primary, "")
    if primary == "openrouter" and fallback:
        fallback = await openrouter_free_model(registry, fallback)
    if fallback and fallback != model and (primary, model) in attempts:
        attempts.insert(attempts.index((primary, model)) + 1, (primary, fallback))
    zweiter = ZWEITER_ERSATZ.get(primary, "")
    if zweiter and unbegrenzt() and (primary, zweiter) not in attempts and zweiter != model:
        attempts.append((primary, zweiter))
    healthy = [a for a in attempts if not is_slow(a[0], a[1])]
    stalled = [a for a in attempts if is_slow(a[0], a[1])]
    return healthy + stalled


def grundmodell(provider: str, slot: str = "emil") -> str:
    if provider == "ollama":
        from app.services.ollama_service import get_ollama_service

        return get_ollama_service().selected_model()
    try:
        from app.services.account_service import get_account_service

        eigenes = get_account_service().default_model(provider)
    except Exception:
        eigenes = None
    if eigenes:
        return lebendes_modell(eigenes, provider)
    settings = get_settings()
    if provider == settings.default_provider:
        return settings.model_for(slot)
    return ""


def ollama_geeignet(model: str) -> bool:
    name = model.lower()
    return bool(name) and not any(marke in name for marke in OLLAMA_UNGEEIGNET)


async def ollama_ersatz(registry, primary: str) -> tuple[str, str] | None:
    if primary == "ollama":
        return None
    if not get_settings_service().get().get("auto_failover", True):
        return None
    try:
        provider = registry.get("ollama")
    except Exception:
        return None
    if not provider.available():
        return None
    try:
        models = await provider.list_models()
    except Exception:
        return None
    if not models:
        return None
    try:
        from app.services.ollama_service import get_ollama_service

        gewaehlt = get_ollama_service().selected_model()
    except Exception:
        gewaehlt = ""
    if gewaehlt and gewaehlt in models and ollama_geeignet(gewaehlt):
        return "ollama", gewaehlt
    for model in models:
        if ollama_geeignet(model):
            return "ollama", model
    return None


def mit_ollama_ersatz(
    attempts: list[tuple[str, str]], ersatz: tuple[str, str] | None
) -> list[tuple[str, str]]:
    if ersatz is None or ersatz in attempts:
        return attempts
    if is_slow(*ersatz):
        return [*attempts, ersatz]
    stelle = next(
        (i for i, (name, model) in enumerate(attempts) if is_slow(name, model)),
        len(attempts),
    )
    return [*attempts[:stelle], ersatz, *attempts[stelle:]]


def material_aus_verlauf(nachrichten: list, grenze: int = 60_000) -> str:
    teile: list[str] = []
    rest = grenze
    for nachricht in reversed(nachrichten[-12:]):
        inhalt = str(getattr(nachricht, "content", "") or "").strip()
        if not inhalt or getattr(nachricht, "role", "") not in {"user", "assistant"}:
            continue
        kopf = "Nutzer" if nachricht.role == "user" else "Jon"
        stueck = inhalt[: max(rest, 0)] if teile else inhalt[:grenze]
        if not stueck:
            break
        teile.append(f"{kopf}:\n{stueck}")
        rest -= len(stueck)
        if rest <= 400:
            break
    return "\n\n".join(reversed(teile))


class ChatService:
    def __init__(self) -> None:
        self._settings = get_settings()
        self._registry = get_registry()
        self._memory = MemoryService()
        self._skills = SkillService()
        self._toolbox = ToolBox(memory=self._memory, skills=self._skills)
        self._usage = get_usage_service()

    @staticmethod
    def _denkbloecke(user_text: str, budget: int = 0) -> list[str]:
        try:
            from app.services.aufmerksamkeit_service import (
                BUDGET,
                get_aufmerksamkeit_service,
            )

            return get_aufmerksamkeit_service().bloecke(user_text, budget or BUDGET)
        except Exception as fehler:
            leise(fehler, "services/chat_service")
        bloecke: list[str] = []
        for lader in (
            ("app.services.ziel_service", "get_ziel_service", False),
            ("app.services.weltmodell_service", "get_weltmodell_service", True),
            ("app.services.notizblock_service", "get_notizblock_service", False),
            ("app.services.handlungsraum_service", "get_handlungsraum_service", False),
        ):
            modul, holer, mit_text = lader
            try:
                dienst = getattr(__import__(modul, fromlist=[holer]), holer)()
                bloecke.append(
                    dienst.prompt_block(user_text) if mit_text else dienst.prompt_block()
                )
            except Exception as fehler:
                leise(fehler, "services/chat_service")
        return [b for b in bloecke if b]

    @staticmethod
    def _denkaufwand(user_text: str, mit_werkzeugen: bool) -> dict:
        if not user_text.strip():
            return {}
        try:
            from app.services.metakognition_service import get_metakognition_service
            from app.services.settings_service import get_settings_service

            if not get_settings_service().get().get("metakognition_enabled", True):
                return {}
            return get_metakognition_service().einschaetzen(user_text, mit_werkzeugen)
        except Exception as fehler:
            leise(fehler, "services/chat_service")
            return {}

    def _system_prompt(
        self,
        coding: bool = False,
        workspace: str | None = None,
        persona: str = "papa",
        active_file: str | None = None,
        user_text: str = "",
        denkbudget: int = 0,
    ) -> str:
        if coding:
            from pathlib import Path

            parts = [CODING_PROMPT, DESIGN_PROMPT]
            if workspace:
                parts.append(workspace_summary(Path(workspace)))
                try:
                    from app.services.project_service import context_block

                    project = context_block(workspace)
                    if project:
                        parts.append(project)
                except Exception as _fehler:
                    leise(_fehler, "services/chat_service")
            active = active_file_context(workspace, active_file)
            if active:
                parts.append(active)
            mentioned = mentioned_files_context(workspace, user_text, active_file)
            if mentioned:
                parts.append(mentioned)
        else:
            settings_service = get_settings_service()
            custom, mode = settings_service.custom_prompt()
            if custom.strip() and mode == "replace":
                base = custom.strip()
            elif custom.strip():
                base = f"{SYSTEM_PROMPT}\n\n{custom.strip()}"
            else:
                base = SYSTEM_PROMPT
            if settings_service.personality():
                parts = [
                    get_persona_service().persona_block(variant=persona),
                    base,
                ]
            else:
                parts = [base]

            lang = settings_service.get().get("language", "de")
            if lang == "en":
                parts.append(ENGLISCH)
        from app.services.learning_support import guidance

        learning = guidance(user_text)
        if learning:
            parts.append(learning)
        if persona == "junior":
            from app.services.harness.messages import selection
            from app.services.mini_jon_agent import get_mini_jon_agent

            selected_root = selection("minijon")
            if selected_root:
                parts.append("GEWÄHLTES MINIJON-PROJEKT: " + selected_root + ". Für Coding-Aufträge harness_task verwenden. Auftrag starten, Fortschritt abfragen, nicht nur Tipps geben.")
            screen_context = get_mini_jon_agent().screen_context()
            if screen_context:
                parts.append(screen_context)
        parts.append(heute_block())
        catalog = self._skills.catalog()
        if catalog:
            parts.append(catalog)
        from app.services.daily_memory import get_daily_memory

        daily = get_daily_memory().prompt_block()
        if daily:
            parts.append(daily)
        block = self._memory.prompt_block(text=user_text)
        if block:
            parts.append(block)
        for zusatz in self._denkbloecke(user_text, denkbudget):
            parts.append(zusatz)
        try:
            from app.services.knowledge_service import get_knowledge_service

            knowledge = get_knowledge_service().prompt_block()
            if knowledge:
                parts.append(knowledge)
        except Exception as _fehler:
            leise(_fehler, "services/chat_service")
        try:
            from app.services.p2p_service import get_p2p_service

            username = get_p2p_service().identity()["name"]
            if username:
                parts.append(f"Der Nutzer heisst {username}. Sprich ihn so an.")
        except Exception as _fehler:
            leise(_fehler, "services/chat_service")
        return mit_herkunft("\n\n".join(parts))

    async def openrouter_free(self, model: str) -> str:
        return await openrouter_free_model(self._registry, model)

    async def route(self, primary: str, model: str) -> list[str]:
        return await route_providers(self._registry, primary, model)

    async def attempt_plan(
        self, primary: str, names: list[str], model: str
    ) -> list[tuple[str, str]]:
        return await attempt_plan_for(self._registry, primary, names, model)

    async def _stream_route(
        self, attempts: list[tuple[str, str]], request: ChatRequest, executor, state: dict
    ):
        runden = WECHSEL_RUNDEN if unbegrenzt() and attempts else 1
        for runde in range(runden):
            state["echt"] = False
            try:
                async for chunk in self._stream_einmal(attempts, request, executor, state):
                    yield chunk
                return
            except Exception as fehler:
                from app.services.harness.modell import voruebergehend

                if state.get("echt") or runde == runden - 1 or not voruebergehend(fehler):
                    raise
            pause = min(30.0, 3.0 * (runde + 1))
            yield StreamChunk(
                kind="content",
                delta=(
                    f"🔁 Gerade antwortet keines der Modelle. Ich wechsle weiter zwischen "
                    f"{', '.join(dict.fromkeys(m for _, m in attempts))} hin und her "
                    f"(Runde {runde + 2} von {runden}) …\n\n"
                ),
            )
            await asyncio.sleep(pause)

    async def _stream_einmal(
        self, attempts: list[tuple[str, str]], request: ChatRequest, executor, state: dict
    ):
        for index, (name, model) in enumerate(attempts):
            provider = self._registry.get(name)
            request.model = model
            started = False
            executed = False

            async def tracked_executor(*args, **kwargs):
                nonlocal executed
                executed = True
                return await executor(*args, **kwargs)
            try:
                async for chunk in provider.stream(request, tracked_executor if executor else None):
                    if not started:
                        started = True
                        state["provider"] = name
                        state["echt"] = True
                        mark_fast(name, model)
                    yield chunk
                return
            except Exception:
                if started or executed:
                    state["echt"] = True
                    raise
                mark_slow(name, model)
                if index + 1 < len(attempts):
                    next_name, next_model = attempts[index + 1]
                    if next_name == name:
                        delta = (
                            f"⚡ {model} ist auf {name} gerade überlastet — ich "
                            f"nehme {next_model}. Deine Modellwahl bleibt "
                            "unverändert.\n\n"
                        )
                    else:
                        delta = (
                            f"⚡ {name} ist gerade überlastet — ich nehme "
                            f"{next_model} über {next_name}.\n\n"
                        )
                    yield StreamChunk(kind="content", delta=delta)
                    continue
                fallback = FALLBACK_MODELS.get(name, "")
                if name == "openrouter":
                    fallback = await self.openrouter_free(
                        fallback or OPENROUTER_FREE_DEFAULTS[0]
                    )
                if (
                    not fallback
                    or fallback == model
                    or (name, fallback) in attempts
                ):
                    raise
                request.model = fallback
                yield StreamChunk(
                    kind="content",
                    delta=(
                        f"⚠️ {model} antwortet gerade nicht — ich beantworte das "
                        f"hier mit {fallback}. Deine Modellwahl bleibt unverändert.\n\n"
                    ),
                )
                async for chunk in provider.stream(request, tracked_executor if executor else None):
                    state["provider"] = name
                    state["echt"] = True
                    yield chunk
                return

    def slot_for(self, payload: ChatIn) -> str:
        if payload.slot:
            return payload.slot
        return "emil" if payload.persona == "junior" else "jon"

    @staticmethod
    def _share_route(provider: str, model: str) -> tuple[str, str]:
        from app.services.ollama_share_service import REMOTE_PREFIX, get_share_service

        if not provider.startswith(REMOTE_PREFIX):
            return provider, model
        code = provider[len(REMOTE_PREFIX):]
        entry = get_share_service().remote(code) or {}
        shared = str(entry.get("model") or "")
        if not shared:
            models = entry.get("models") or []
            shared = str(models[0]) if models else model
        return "ollama", f"{REMOTE_PREFIX}{code.upper()}/{shared}"

    def resolve(self, payload: ChatIn) -> tuple[str, str]:
        settings_service = get_settings_service()
        saved_provider, saved_model = settings_service.selection()
        slot = self.slot_for(payload)
        if slot == "emil":
            pet_provider, pet_model = settings_service.pet_selection()
            eigener = (
                pet_provider or saved_provider or self._settings.default_provider
            )
            provider = payload.provider or eigener
            model = (
                payload.model
                or (pet_model if provider == eigener else "")
                or grundmodell(provider)
                or self._settings.emil_model
            )
        else:
            eigener = saved_provider or self._settings.default_provider
            provider = payload.provider or eigener
            model = (
                payload.model
                or (saved_model if provider == eigener else "")
                or grundmodell(provider, "jon")
                or self._settings.jon_model
            )
        provider, model = self._share_route(provider, lebendes_modell(model, provider))
        provider, model = self._ersatz_ohne_schluessel(provider, model)
        if slot != "emil":
            from app.services.aufgaben_modelle import fuer_chat

            provider, model = fuer_chat("code" if payload.mode == "coding" else "text", provider, model)
        from app.services.offline import lokal_erzwingen

        return lokal_erzwingen(provider, model)

    def _ersatz_ohne_schluessel(self, provider: str, model: str) -> tuple[str, str]:
        try:
            if self._registry.get(provider).available():
                return provider, model
        except Exception as fehler:
            leise(fehler, "services/chat_service")
        try:
            felworks = self._registry.get("felworks")
            if felworks.available():
                modelle = list(getattr(felworks, "_default_models", []) or [])
                return "felworks", model if model in modelle else (modelle[0] if modelle else model)
        except Exception as fehler:
            leise(fehler, "services/chat_service")
        return provider, model

    def _ensure_conversation(self, payload: ChatIn, provider: str, model: str) -> str:
        with session_scope() as session:
            conv: Conversation | None = None
            if payload.conversation_id:
                conv = session.get(Conversation, payload.conversation_id)
            if conv is None:
                first_user = next(
                    (m.content for m in payload.messages if m.role == "user"), ""
                )
                title = (first_user.strip()[:60] or "Neue Unterhaltung")
                conv = Conversation(title=title, provider=provider, model=model)
                session.add(conv)
                session.flush()
            conv.provider = provider
            conv.model = model
            gespeichert = list(conv.messages)
            position = max((em.position for em in gespeichert), default=-1) + 1
            letzte = gespeichert[-1] if gespeichert else None
            for idx, m in enumerate(payload.messages):
                if idx == len(payload.messages) - 1 and m.role == "user":
                    exists = letzte is not None and letzte.role == "user" and letzte.content == m.content
                else:
                    exists = any(
                        em.role == m.role and em.content == m.content
                        for em in gespeichert
                    )
                if not exists:
                    session.add(
                        Message(
                            conversation_id=conv.id,
                            role=m.role,
                            content=m.content,
                            position=position,
                        )
                    )
                    position += 1
            return conv.id

    async def _schnell_wechseln(self, wechsel: tuple[str, bool], payload, conversation_id):
        from app.services.fenster_wechsel import wechseln

        ziel, tab = wechsel
        args = {"ziel": ziel, "tab": tab}
        yield {"type": "tool", "name": "wechseln", "status": "running", "args": args, "summary": describe_tool("wechseln", args)}
        try:
            ergebnis = await asyncio.to_thread(wechseln, ziel, True, tab)
        except Exception as fehler:
            ergebnis = {"error": str(fehler)}
        ok = bool(ergebnis.get("ok"))
        yield {"type": "tool", "name": "wechseln", "status": "done", "ok": ok}
        if ok:
            ort = ergebnis.get("tab") or ergebnis.get("fenster") or ziel
            answer = f"Erledigt, ich habe zum {'Tab' if ergebnis.get('tab') else 'Fenster'} „{ort}“ gewechselt."
        else:
            offen = ", ".join(f"„{t}“" for t in (ergebnis.get("offen") or [])[:6])
            answer = f"Ich finde kein Fenster und keinen Tab mit „{ziel}“." + (f" Offen sind gerade: {offen}." if offen else "")
        yield {"type": "content", "delta": answer}
        if payload.persist and conversation_id:
            self._store_answer(conversation_id, answer, None)
        yield {"type": "done", "conversation_id": conversation_id}

    def _store_answer(
        self,
        conversation_id: str,
        content: str,
        reasoning: str | None,
        karten: list[dict] | None = None,
    ) -> None:
        with session_scope() as session:
            conv = session.get(Conversation, conversation_id)
            if conv is None:
                return
            position = max((em.position for em in conv.messages), default=-1) + 1
            session.add(
                Message(
                    conversation_id=conversation_id,
                    role="assistant",
                    content=content,
                    reasoning=reasoning or None,
                    karten=json.dumps(karten, ensure_ascii=False) if karten else None,
                    position=position,
                )
            )

    def _defaults_for(self, provider: str) -> dict:
        if provider != "ollama":
            return {}
        from app.services.ollama_service import get_ollama_service

        config = get_ollama_service().config()
        seed = int(config["seed"])
        return {
            "temperature": float(config["temperature"]),
            "top_p": float(config["top_p"]),
            "max_tokens": int(config["max_tokens"]),
            "seed": seed if seed >= 0 else None,
        }

    def _kinder_alter(self, payload: ChatIn) -> int:
        from app.core.kinderschutz import alter_pruefen
        from app.services.geraete_funktionen import HANDY_KONTEXT

        geraet = HANDY_KONTEXT.get()
        if geraet:
            try:
                from app.services.handy_service import get_handy_service

                vom_geraet = get_handy_service().kinder_alter(geraet)
            except Exception as exc:
                leise(exc, "services/chat_service")
                vom_geraet = 0
            if vom_geraet:
                return vom_geraet
        return alter_pruefen(payload.kinder)

    async def stream(self, payload: ChatIn) -> AsyncIterator[dict]:
        from app.core.kinderschutz import KINDER_ALTER

        alter = self._kinder_alter(payload)
        marke = KINDER_ALTER.set(alter)
        try:
            async for teil in self._stream(payload):
                yield teil
        finally:
            try:
                KINDER_ALTER.reset(marke)
            except ValueError:
                pass

    async def _ziel_stream(self, payload: ChatIn, ziel_text: str) -> AsyncIterator[dict]:
        from app.services.ziel_modus import STOPP, ende_text, get_ziel_modus

        modus = get_ziel_modus()
        quelle = "app"
        provider_name, model_name = self.resolve(payload)
        conversation_id = payload.conversation_id
        if payload.persist:
            conversation_id = self._ensure_conversation(payload, provider_name, model_name)
        yield {"type": "meta", "provider": provider_name, "model": model_name, "conversation_id": conversation_id}
        laufend = modus.laufend(quelle)
        wort = ziel_text.casefold()
        if wort in STOPP or (not ziel_text and laufend is None):
            if laufend is not None:
                await modus.stoppen(laufend["id"])
                text = f"Angehalten: {laufend['ziel']}. Was schon fertig ist, bleibt erhalten."
            else:
                text = "So geht's: /goal und dein Ziel, z. B. /goal Erstelle eine Präsentation über Datensicherung mit Bildern und Quellen. Jon arbeitet dann selbstständig in mehreren Runden, prüft sich nach jeder Runde streng und hört erst auf, wenn das Ziel erreicht ist. /goal stopp hält an."
            if payload.persist and conversation_id:
                self._store_answer(conversation_id, text, None)
            yield {"type": "content", "delta": text}
            yield {"type": "done", "conversation_id": conversation_id}
            return
        if wort == "weiter" and laufend is None:
            frueher = next((z for z in modus.liste(quelle) if z["status"] in ("angehalten", "fehler", "abgebrochen")), None)
            if frueher is not None:
                ziel_text = frueher["ziel"]
        if laufend is None:
            try:
                laufend = modus.starten(ziel_text, quelle, payload.workspace or "" if payload.mode == "coding" else "")
            except ValueError as fehler:
                yield {"type": "content", "delta": str(fehler)}
                yield {"type": "done", "conversation_id": conversation_id}
                return
            yield {"type": "content", "delta": f"**Ziel:** {laufend['ziel']}\n\nIch arbeite jetzt selbstständig daran, so lange es nötig ist, und prüfe mich nach jeder Runde. Mit /btw kannst du nebenbei fragen, mit /goal stopp halte ich an.\n"}
        else:
            yield {"type": "content", "delta": f"**Ich arbeite gerade an:** {laufend['ziel']}\n"}
        teile: list[str] = []
        ende: dict = {}
        async for ereignis in modus.verfolgen(laufend["id"]):
            art = ereignis.get("art")
            zeile = ""
            if art == "runde":
                zeile = f"\n**Runde {ereignis['runde']}**\n"
            elif art == "schritt":
                typ = ereignis.get("typ")
                if typ == "gedanke" and ereignis.get("text"):
                    yield {"type": "reasoning", "delta": ereignis["text"].strip() + "\n\n"}
                elif typ == "notiz" and ereignis.get("text"):
                    zeile = f"- {ereignis['text']}\n"
                elif typ == "action" and ereignis.get("pfad"):
                    zeile = f"  - gespeichert: `{ereignis['pfad']}`\n"
                elif typ == "action_error" and ereignis.get("text"):
                    zeile = f"  - Problem bei {ereignis.get('tool') or 'einem Schritt'}: {ereignis['text'][:200]} – ich versuche es anders.\n"
                elif typ == "approval_required":
                    zeile = "  - Ich warte auf deine Freigabe im Harness-Fenster.\n"
            elif art == "urteil" and ereignis.get("text"):
                zeile = f"\n*Prüfung: {ereignis['text']}*\n"
            elif art == "ende":
                ende = ereignis
            if zeile:
                teile.append(zeile)
                yield {"type": "content", "delta": zeile}
        schluss = "\n\n" + ende_text({**modus.get(laufend["id"]), **({"runden": ende.get("runden")} if ende else {})})
        teile.append(schluss)
        yield {"type": "content", "delta": schluss}
        if payload.persist and conversation_id:
            self._store_answer(conversation_id, "".join(teile).strip(), None)
        yield {"type": "done", "conversation_id": conversation_id}

    async def _stream(self, payload: ChatIn) -> AsyncIterator[dict]:
        from app.core.kinderschutz import KINDER_ALTER, kinder_prompt, werkzeuge_fuer_kinder

        kinder = KINDER_ALTER.get()
        latest_command = next((m.content for m in reversed(payload.messages) if m.role == "user"), "")
        if payload.mode != "coding":
            from app.services.daily_memory import get_daily_memory

            answer = get_daily_memory().respond(latest_command)
            if answer is not None:
                provider_name, model_name = self.resolve(payload)
                conversation_id = payload.conversation_id
                if payload.persist:
                    conversation_id = self._ensure_conversation(payload, provider_name, model_name)
                    self._store_answer(conversation_id, answer, None)
                yield {"type": "meta", "provider": provider_name, "model": model_name, "conversation_id": conversation_id, "from_memory": True}
                yield {"type": "content", "delta": answer}
                yield {"type": "done"}
                return
        from app.services.ziel_modus import befehl as ziel_befehl

        ziel_text = None if kinder else ziel_befehl(latest_command)
        if ziel_text is not None:
            async for ereignis in self._ziel_stream(payload, ziel_text):
                yield ereignis
            return
        if not kinder and latest_command.strip().startswith(("/hhelp", "/harness", "/hstatus", "/hstop", "/aufgaben", "/projekt", "/erlauben", "/ablehnen", "/diff")):
            from app.services.harness.messages import handle

            result = await handle(latest_command, "app")
            if result is not None:
                yield {"type": "content", "delta": result["text"]}
                if result.get("task_id"):
                    from app.services.harness import get_harness_service
                    from app.services.harness.messages import describe
                    from app.services.harness.service import TERMINAL

                    harness = get_harness_service()
                    task_id = result["task_id"]
                    async for event in harness.stream(task_id):
                        task = harness.get(task_id)
                        if task["status"] in TERMINAL or task.get("pending"):
                            yield {"type": "content", "delta": "\n\n" + describe(task)}
                            break
                        if event["type"] == "action":
                            outcome = event["result"]
                            line = str(outcome.get("error") or outcome.get("path") or event["tool"])
                            yield {"type": "content", "delta": "\n" + line}
                yield {"type": "done"}
                return
        chosen, model = self.resolve(payload)
        slot = self.slot_for(payload)
        defaults = self._defaults_for(chosen)
        temperature = (
            payload.temperature
            if payload.temperature is not None
            else defaults.get("temperature", self._settings.default_temperature)
        )
        top_p = (
            payload.top_p
            if payload.top_p is not None
            else defaults.get("top_p", self._settings.default_top_p)
        )
        max_tokens = (
            payload.max_tokens
            if payload.max_tokens is not None
            else defaults.get("max_tokens")
        )
        seed = payload.seed if payload.seed is not None else defaults.get("seed")
        from app.services.modell_router import ModelRouter

        attempts = await ModelRouter(self._registry).plan(
            chosen, model, anbieter=self.route, planen=self.attempt_plan
        )
        provider_name = attempts[0][0]
        state = {"provider": provider_name}

        if payload.mode != "coding" and get_settings_service().personality():
            get_persona_service().touch()

        conversation_id = payload.conversation_id
        if payload.persist:
            conversation_id = self._ensure_conversation(payload, provider_name, model)

        yield {
            "type": "meta",
            "provider": provider_name,
            "model": model,
            "conversation_id": conversation_id,
        }

        request_messages = [
            ChatMessage(role=m.role, content=m.content) for m in payload.messages
        ]
        latest_user = next(
            (m.content for m in reversed(payload.messages) if m.role == "user"),
            "",
        )
        urteil = self._denkaufwand(latest_user, payload.mode != "coding")
        if urteil:
            yield {"type": "denkaufwand", "urteil": urteil}
        if not any(m.role == "system" for m in request_messages):
            request_messages.insert(
                0,
                ChatMessage(
                    role="system",
                    content=self._system_prompt(
                        coding=payload.mode == "coding",
                        workspace=payload.workspace,
                        persona=payload.persona,
                        active_file=payload.active_file,
                        user_text=latest_user,
                        denkbudget=int(urteil.get("budget", 0)) if urteil else 0,
                    ),
                ),
            )
        if kinder:
            request_messages.insert(1, ChatMessage(role="system", content=kinder_prompt(kinder)))
        if payload.sprache == "en" and get_settings_service().get().get("language", "de") != "en":
            request_messages.insert(1, ChatMessage(role="system", content=ENGLISCH))

        verlauf = get_verlauf_service()
        gespeichert = verlauf.zusammenfassung(conversation_id or "")
        trimmed = trim_history(
            request_messages,
            get_settings().context_budget_tokens,
            lambda role, content: ChatMessage(role=role, content=content),
            zusammenfassung=gespeichert,
        )
        request_messages = trimmed.messages
        if trimmed.dropped or trimmed.shortened:
            _log.info(
                "Verlauf gekuerzt: %s Nachrichten zusammengefasst, %s gestutzt",
                trimmed.dropped,
                trimmed.shortened,
            )
        if trimmed.dropped and conversation_id:
            verlauf.planen(
                conversation_id, trimmed.entfallen or [], trimmed.dropped
            )

        if payload.mode != "coding":
            last_user = latest_user
            if not kinder and wants_webcam(last_user):
                from app.services.webcam_service import get_webcam_service

                yield {
                    "type": "tool",
                    "name": "webcam_look",
                    "status": "running",
                    "args": {},
                    "summary": describe_tool("webcam_look", {}),
                }
                webcam = await get_webcam_service().describe(last_user)
                ok = "beschreibung" in webcam
                yield {
                    "type": "tool",
                    "name": "webcam_look",
                    "status": "done",
                    "ok": ok,
                }
                if ok:
                    answer = "📷 " + str(webcam["beschreibung"]).strip()
                else:
                    answer = (
                        "Ich habe versucht, durch die Webcam zu schauen, "
                        "aber es hat nicht geklappt: "
                        + str(webcam.get("error", "unbekannter Fehler"))
                    )
                yield {"type": "content", "delta": answer}
                if payload.persist and conversation_id:
                    self._store_answer(conversation_id, answer, None)
                yield {"type": "done", "conversation_id": conversation_id}
                return
            from app.services.fenster_wechsel import wunsch as wechsel_wunsch

            wechsel = wechsel_wunsch(last_user) if not kinder else None
            if wechsel:
                async for teil in self._schnell_wechseln(wechsel, payload, conversation_id):
                    yield teil
                return

        from app.services.tools import runde_beginnen

        runde_beginnen(next((m.content for m in reversed(payload.messages) if m.role == "user"), ""))
        browser_sitzung(conversation_id or payload.conversation_id or "standard")
        use_tools = provider_name in TOOL_PROVIDERS
        tool_source = payload.source or ("mini-jon" if slot == "emil" else "app")
        from copy import copy

        toolbox = copy(self._toolbox)
        toolbox._slot = slot
        toolbox._persist = payload.persist
        if payload.mode == "coding" and payload.workspace:
            toolbox = ToolBox(
                memory=self._memory,
                skills=self._skills,
                root=payload.workspace,
                slot=slot,
                persist=payload.persist,
            )
        toolbox._material = material_aus_verlauf(payload.messages)
        tool_context = " ".join(
            m.content for m in payload.messages if m.role == "user"
        )[-1500:]
        coding_mode = payload.mode == "coding"
        forced = str(payload.force_tool or "").strip().lower()
        tools = scoped_tools(
            toolbox.schema(tool_context, coding=coding_mode, umfang=payload.werkzeuge) if use_tools else [],
            payload.tool_scope,
        )
        if kinder:
            tools = werkzeuge_fuer_kinder(tools)
        if forced and use_tools:
            tools = tools if forced in OFFEN_ERZWUNGEN else forced_tools(tools, forced)
            hint = FORCED_PROMPTS.get(forced)
            if hint:
                request_messages.append(ChatMessage(role="system", content=hint))
        request = ChatRequest(
            messages=request_messages,
            model=model,
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            seed=seed,
            tools=tools,
            slot=slot,
            first_token_timeout=GEDULD_QUELLEN.get(payload.source, 0.0),
            denken=denken_noetig(latest_user, urteil, coding_mode),
        )

        budget = get_budget_service()
        erlaubt, budget_hinweis = budget.pruefen()
        if not erlaubt:
            yield {"type": "error", "message": budget_hinweis}
            yield {"type": "done", "conversation_id": conversation_id}
            return
        if budget_hinweis:
            yield {"type": "hinweis", "message": budget_hinweis}

        ask_mode = payload.tool_mode not in ("allow", "alles")
        alles_erlaubt = payload.tool_mode == "alles"
        approvals = get_approval_service()
        pending_approvals: list[str] = []

        def needs_approval(name: str | None, args: dict | None = None) -> bool:
            if not name or alles_erlaubt:
                return False
            try:
                return braucht_freigabe(name, args or {}, ask_mode)
            except Exception:
                return ask_mode and name not in SAFE_TOOLS

        def risiko_von(name: str | None, args: dict | None = None) -> str:
            if not name:
                return "niedrig"
            try:
                return risiko_bewerten(name, args or {}).risiko
            except Exception:
                return "mittel"

        vorab_teams: list[str] = []
        genutzte_teams: list[str] = []

        def team_vorbereiten(name: str | None, args: dict | None, event: dict) -> None:
            if name != "team":
                return
            if genutzte_teams:
                lauf = genutzte_teams.pop(0)
            else:
                lauf = uuid.uuid4().hex
                vorab_teams.append(lauf)
            karte = {"kind": "agenten", "data": {"id": lauf, "aufgabe": str((args or {}).get("aufgabe", ""))[:600]}}
            event["card"] = karte
            event["agent_run_id"] = lauf
            karten.append(karte)

        def mit_lauf(name: str | None, args: dict) -> dict:
            if name != "team":
                return args
            if vorab_teams:
                lauf = vorab_teams.pop(0)
            else:
                lauf = uuid.uuid4().hex
                genutzte_teams.append(lauf)
            return {**args, "_lauf": lauf}

        def harness_karte(result: str | None, event: dict) -> None:
            try:
                daten = json.loads(result or "{}")
            except (TypeError, ValueError):
                return
            if isinstance(daten, dict) and daten.get("task_id"):
                event["harness_task_id"] = daten["task_id"]
                karte = {"kind": "harness", "data": {"id": daten["task_id"]}}
                event["card"] = karte
                karten.append(karte)

        async def gated_executor(name: str, args: dict) -> str:
            args = mit_lauf(name, args)
            if needs_approval(name, args):
                approval_id = (
                    pending_approvals.pop(0) if pending_approvals else None
                )
                approved = (
                    await approvals.wait(approval_id) if approval_id else False
                )
                if not approved:
                    raise ToolDeniedError(
                        "Der Nutzer hat die Ausführung dieses Tools abgelehnt."
                    )
            return await toolbox.execute(name, args, source=tool_source)

        executor = gated_executor if use_tools else None

        reasoning_parts: list[str] = []
        karten: list[dict] = []
        tools_used: list[str] = []
        prompt_tokens = 0
        completion_tokens = 0
        started = time.perf_counter()
        rounds = 0
        content = ""
        while True:
            content_parts: list[str] = []
            held: list[str] = []
            releasing = not use_tools
            try:
                chunk: StreamChunk
                async for chunk in self._stream_route(
                    attempts, request, executor, state
                ):
                    if chunk.kind == "usage":
                        prompt_tokens += chunk.prompt_tokens
                        completion_tokens += chunk.completion_tokens
                        continue
                    if chunk.kind == "reasoning":
                        reasoning_parts.append(chunk.delta)
                        yield {"type": "reasoning", "delta": chunk.delta}
                    elif chunk.kind == "tool":
                        event = {
                            "type": "tool",
                            "name": chunk.name,
                            "status": "running",
                            "args": chunk.args or {},
                            "summary": describe_tool(chunk.name or "", chunk.args or {}),
                        }
                        event["risiko"] = risiko_von(chunk.name, chunk.args or {})
                        if needs_approval(chunk.name, chunk.args or {}):
                            approval_id = approvals.create()
                            pending_approvals.append(approval_id)
                            event["approval_id"] = approval_id
                        team_vorbereiten(chunk.name, chunk.args, event)
                        werkstatt_anhaengen(chunk.name, chunk.args, event)
                        yield event
                    elif chunk.kind == "tool_result":
                        if chunk.ok and chunk.name:
                            tools_used.append(chunk.name)
                        event = {
                            "type": "tool",
                            "name": chunk.name,
                            "status": "done",
                            "ok": chunk.ok,
                        }
                        if chunk.name == "harness_task" and chunk.ok:
                            harness_karte(chunk.result, event)
                        werkstatt_fertig(chunk.name, chunk.result, event)
                        card = card_payload(chunk.name, chunk.result)
                        if card is not None:
                            event["card"] = card
                            karten.append(card)
                        if chunk.name == "oberflaeche" and chunk.ok:
                            try:
                                daten = json.loads(chunk.result or "{}")
                                if daten.get("oeffne"):
                                    event["oeffne"] = daten["oeffne"]
                                if daten.get("steuerung"):
                                    event["steuerung"] = daten["steuerung"]
                            except Exception as fehler:
                                leise(fehler, "services/chat_service")
                        yield event
                    else:
                        if releasing:
                            content_parts.append(chunk.delta)
                            yield {"type": "content", "delta": chunk.delta}
                        else:
                            held.append(chunk.delta)
                            joined = "".join(held)
                            if not looks_like_tool_start(joined):
                                releasing = True
                                held = []
                                content_parts.append(joined)
                                yield {"type": "content", "delta": joined}
            except Exception as exc:
                if not tools_used:
                    yield {"type": "error", "message": str(exc)}
                    return
                erledigt = ", ".join(dict.fromkeys(tools_used))
                nachtrag = (
                    ("\n\n" if content_parts else "")
                    + f"Erledigt: {erledigt}. Danach war das Modell kurz nicht erreichbar "
                    f"({str(exc)[:120]}), deshalb fehlt meine ausführliche Zusammenfassung. "
                    "Die Änderungen sind gespeichert."
                )
                content_parts.append(nachtrag)
                yield {"type": "content", "delta": nachtrag}
                content = "".join(content_parts)
                break

            if held:
                candidate = "".join(held)
                parsed = parse_text_tool_call(candidate)
                if parsed and (rounds < TEXT_TOOL_RUNDEN or unbegrenzt()):
                    name, args = parsed
                    rounds += 1
                    event = {
                        "type": "tool",
                        "name": name,
                        "status": "running",
                        "args": args,
                        "summary": describe_tool(name, args),
                    }
                    approval_id = None
                    event["risiko"] = risiko_von(name, args)
                    if needs_approval(name, args):
                        approval_id = approvals.create()
                        event["approval_id"] = approval_id
                    team_vorbereiten(name, args, event)
                    werkstatt_anhaengen(name, args, event)
                    lauf_args = mit_lauf(name, args)
                    yield event
                    approved = (
                        await approvals.wait(approval_id)
                        if approval_id is not None
                        else True
                    )
                    if approved:
                        try:
                            result = await toolbox.execute(
                                name, lauf_args, source=tool_source
                            )
                        except Exception as exc:
                            result = json.dumps(
                                {"error": str(exc)}, ensure_ascii=False
                            )
                    else:
                        result = json.dumps(
                            {
                                "error": "Der Nutzer hat die Ausführung dieses "
                                "Tools abgelehnt."
                            },
                            ensure_ascii=False,
                        )
                    from app.services.tool_result import succeeded

                    ok = approved and succeeded(result)
                    if ok:
                        tools_used.append(name)
                    done_event = {
                        "type": "tool",
                        "name": name,
                        "status": "done",
                        "ok": ok,
                    }
                    if name == "harness_task" and ok:
                        harness_karte(result, done_event)
                    werkstatt_fertig(name, result, done_event)
                    if name == "oberflaeche" and ok:
                        try:
                            daten = json.loads(result or "{}")
                            if daten.get("oeffne"):
                                done_event["oeffne"] = daten["oeffne"]
                            if daten.get("steuerung"):
                                done_event["steuerung"] = daten["steuerung"]
                        except Exception as fehler:
                            leise(fehler, "services/chat_service")
                    card = card_payload(name, result)
                    if card is not None:
                        done_event["card"] = card
                        karten.append(card)
                    yield done_event
                    request_messages.append(
                        ChatMessage(role="assistant", content=candidate)
                    )
                    request_messages.append(
                        ChatMessage(
                            role="system",
                            content=(
                                f"Das Tool {name} wurde soeben wirklich "
                                f"ausgefuehrt. Ergebnis: {str(result)[:4000]}\n"
                                "Antworte dem Nutzer jetzt auf Deutsch in "
                                "normalem Fliesstext auf Basis dieses "
                                "Ergebnisses. Gib NIEMALS JSON, Code-Bloecke "
                                "mit Tool-Aufrufen oder erneute Tool-Aufrufe "
                                "als Text aus."
                            ),
                        )
                    )
                    request = ChatRequest(
                        messages=request_messages,
                        model=model,
                        temperature=temperature,
                        top_p=top_p,
                        max_tokens=max_tokens,
                        seed=seed,
                        tools=tools,
                        slot=slot,
                    )
                    continue
                content_parts.append(candidate)
                yield {"type": "content", "delta": candidate}
            content = "".join(content_parts)
            break
        if not content.strip() and tools_used:
            content = "Erledigt (" + ", ".join(dict.fromkeys(tools_used)) + ")"
            yield {"type": "content", "delta": content}
        try:
            einstellungen = get_settings_service().get()
            if (
                content.strip()
                and bool(einstellungen.get("kritiker_enabled", False))
                and use_tools
            ):
                from app.services.selbst_service import get_selbst_service

                selbst = get_selbst_service()
                schwelle = float(einstellungen.get("kritiker_schwelle", 0.5) or 0.5)
                if urteil:
                    schwelle = max(schwelle, float(urteil.get("kritiker_schwelle", 0.0)))
                grob = selbst.sicherheit_schaetzen(content)
                if grob < schwelle:
                    kritik = await selbst.kritik(latest_user, content)
                    if not kritik.get("passt", True) or kritik.get("probleme"):
                        yield {
                            "type": "hinweis",
                            "message": "Selbstpruefung (Sicherheit "
                            + str(kritik.get("sicherheit", grob))
                            + "): "
                            + "; ".join(kritik.get("probleme", []))[:400],
                        }
        except Exception as fehler:
            leise(fehler, "services/chat_service")
        try:
            if (
                content.strip()
                and latest_user.strip()
                and get_settings_service().get().get("neugier_enabled", True)
            ):
                from app.services.neugier_service import get_neugier_service

                get_neugier_service().aus_antwort(latest_user, content)
        except Exception as fehler:
            leise(fehler, "services/chat_service")

        reasoning = "".join(reasoning_parts)
        if payload.persist and conversation_id and content:
            self._store_answer(conversation_id, content, reasoning, karten)
        try:
            from app.services.ereignis_service import get_ereignis_service
            from app.services.weltmodell_service import get_weltmodell_service

            get_ereignis_service().notieren(
                "chat",
                latest_user[:140] or "Gespraech",
                content[:400],
                quelle=tool_source,
                bedeutung=0.3,
                gespraech=conversation_id or "",
            )
            if latest_user:
                get_weltmodell_service().erkennen(latest_user)
        except Exception as fehler:
            leise(fehler, "services/chat_service")

        if prompt_tokens or completion_tokens:
            budget.buchen(
                state["provider"], prompt_tokens + completion_tokens, request.model
            )
        if content or prompt_tokens or completion_tokens:
            self._usage.record(
                state["provider"],
                request.model,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                latency=time.perf_counter() - started,
            )

        yield {"type": "done", "conversation_id": conversation_id}
