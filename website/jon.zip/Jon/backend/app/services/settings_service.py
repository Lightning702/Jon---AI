from __future__ import annotations

import json
import threading

from app.core.config import DATA_DIR
from app.core.store import atomic_write_text
from app.core.fehler import leise

SETTINGS_FILE = DATA_DIR / "user_settings.json"

DEFAULTS = {
    "custom_prompt": "",
    "prompt_mode": "append",
    "tool_mode": "ask",
    "personality": True,
    "auto_failover": True,
    "provider": "",
    "model": "",
    "terminal_provider": "",
    "terminal_model": "",
    "theme": "dark",
    "pet_accent": "#d4af37",
    "pet_face": "#0a0a0e",
    "pet_cheeks": False,
    "pet_scale": 1.0,
    "pet_eyes": "round",
    "dream_auto": True,
    "dream_idle_minutes": 5,
    "vision_model": "",
    "briefing_city": "",
    "maps_home_lat": 0.0,
    "maps_home_lon": 0.0,
    "maps_home_label": "",
    "maps_home_source": "",
    "clipboard_history": True,
    "handy_ordner": "",
    "webcam_enabled": False,
    "mail_imap_host": "",
    "mail_imap_user": "",
    "mail_imap_password": "",
    "mail_smtp_host": "",
    "mail_smtp_port": 587,
    "calendar_ics_url": "",
    "telegram_bot_token": "",
    "telegram_chat_id": "",
    "telegram_provider": "",
    "telegram_model": "",
    "mini_jon_bot_token": "",
    "pet_provider": "",
    "pet_model": "",
    "ha_url": "",
    "ha_token": "",
    "natural_voice": True,
    "spotify_client_id": "",
    "spotify_client_secret": "",
    "p2p_user_id": "",
    "p2p_username": "",
    "p2p_avatar": "🙂",
    "p2p_enabled": True,
    "relay_enabled": False,
    "relay_broker": "broker.hivemq.com",
    "relay_port": 1883,
    "cowork_enabled": False,
    "cowork_context": "",
    "cowork_app": "auto",
    "quickwrite_enabled": True,
    "timeline_enabled": False,
    "routine_enabled": True,
    "telegram_morning": False,
    "telegram_morning_time": "07:30",
    "pet_roam": False,
    "pet_companion": "none",
    "wake_sensitivity": "mittel",
    "pet_wellness": True,
    "pet_3d": False,
    "autofile_enabled": False,
    "app_usage_enabled": False,
    "language": "de",
    "microphone_device": "default",
    "microphone_name": "",
    "phone_enabled": False,
    "phone_sip_user": "",
    "phone_sip_password": "",
    "phone_sip_realm": "jon",
    "phone_sip_port": 5060,
    "phone_bind_host": "0.0.0.0",
    "phone_advertise_host": "",
    "phone_caller_name": "Jon",
    "phone_voice": "",
    "phone_timezone": "Europe/Vienna",
    "phone_keep_transcript": False,
    "phone_max_seconds": 600,
    "phone_accept_incoming": True,
    "phone_greeting": "",
    "browser_agent": True,
    "browser_sichtbar": True,
    "browser_persistent": True,
    "browser_speicher": "festplatte",
    "browser_motor": "privat",
    "web_browser": "jon",
    "browser_plan_modus": "auto",
    "browser_dry_run": False,
    "browser_max_schritte": 25,
    "browser_suchmaschine": "brave",
    "initiative_enabled": False,
    "initiative_stunde": 7,
    "wahrnehmung_enabled": False,
    "konsolidierung_auto": True,
    "kritiker_enabled": False,
    "kritiker_schwelle": 0.5,
    "erwartung_enabled": True,
    "metakognition_enabled": True,
    "neugier_enabled": True,
    "neugier_auto": False,
    "neugier_pro_lauf": 3,
    "fertigkeit_auto": False,
    "planer_enabled": True,
    "aufgaben_enabled": True,
    "aufgaben_budget": 20,
    "vorwaerts_enabled": True,
    "hypothesen_auto": False,
    "jon_ordner": "",
    "freigegebene_ordner": [],
    "blender_pfad": "",
    "downloads_sortieren": True,
    "datenschutz_regel": "warnen",
    "budget_tokens_tag": 0,
    "budget_euro_monat": 0.0,
    "budget_warnung": 0.8,
    "semantik_modell": "",
}


class SettingsService:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._data = self._load()

    def _load(self) -> dict:
        from app.core.datenschema import pruefen, wandeln

        data = dict(DEFAULTS)
        roh = wandeln(
            SETTINGS_FILE,
            "user_settings",
            {
                1: lambda d: d if isinstance(d, dict) else {},
                2: lambda d: {k: v for k, v in d.items() if v is not None},
            },
            standard={},
        )
        if isinstance(roh, dict):
            data = pruefen(roh, data)
        return data

    def _save(self) -> None:
        try:
            atomic_write_text(SETTINGS_FILE,
                json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception as _fehler:
            leise(_fehler, "services/settings_service")

    def get(self) -> dict:
        with self._lock:
            return dict(self._data)

    def update(self, values: dict) -> dict:
        with self._lock:
            for key in DEFAULTS:
                if key in values and values[key] is not None:
                    self._data[key] = values[key]
            self._save()
            return dict(self._data)

    def custom_prompt(self) -> tuple[str, str]:
        with self._lock:
            return self._data.get("custom_prompt", ""), self._data.get(
                "prompt_mode", "append"
            )

    def personality(self) -> bool:
        with self._lock:
            return bool(self._data.get("personality", True))

    def selection(self) -> tuple[str, str]:
        with self._lock:
            return self._data.get("provider", ""), self._data.get("model", "")

    def terminal_selection(self) -> tuple[str, str]:
        with self._lock:
            return (
                self._data.get("terminal_provider", ""),
                self._data.get("terminal_model", ""),
            )

    def remember_terminal(self, provider: str, model: str) -> None:
        with self._lock:
            self._data["terminal_provider"] = str(provider or "")
            self._data["terminal_model"] = str(model or "")
            self._save()

    def _companion_selection(
        self, provider_key: str, model_key: str
    ) -> tuple[str, str]:
        provider = self._data.get(provider_key, "")
        if provider:
            return provider, self._data.get(model_key, "")
        main_provider = self._data.get("provider", "")
        if main_provider and main_provider != "nvidia":
            return main_provider, self._data.get("model", "")
        return main_provider, self._data.get(model_key, "")

    def pet_selection(self) -> tuple[str, str]:
        with self._lock:
            return self._companion_selection("pet_provider", "pet_model")

    def telegram_selection(self) -> tuple[str, str]:
        with self._lock:
            return self._companion_selection("telegram_provider", "telegram_model")


_service: SettingsService | None = None


def get_settings_service() -> SettingsService:
    global _service
    if _service is None:
        _service = SettingsService()
    return _service
