from __future__ import annotations

import asyncio
import json
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

import httpx

from app.core.config import DATA_DIR
from app.services.settings_service import get_settings_service

HISTORY_FILE = DATA_DIR / "telegram_memory.json"
HISTORY_KEEP = 40
HISTORY_SEND = 12
MORNING_STATE_FILE = DATA_DIR / "telegram_morning.json"


class TelegramService:
    def __init__(self) -> None:
        self._offset = 0
        self._histories: dict[str, list[dict]] = self._load_histories()
        self._chat_service = None
        self._voice_reply: set[str] = set()
        self._voice_off: set[str] = set()
        self._running: dict[str, asyncio.Task] = {}
        self._last_morning = self._load_morning()

    def _load_histories(self) -> dict[str, list[dict]]:
        try:
            data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return {
                    str(key): value
                    for key, value in data.items()
                    if isinstance(value, list)
                }
        except Exception:
            pass
        return {}

    def _save_histories(self) -> None:
        try:
            HISTORY_FILE.write_text(
                json.dumps(self._histories, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _load_morning(self) -> str:
        try:
            return str(json.loads(MORNING_STATE_FILE.read_text(encoding="utf-8")).get("last", ""))
        except Exception:
            return ""

    def _save_morning(self, day: str) -> None:
        self._last_morning = day
        try:
            MORNING_STATE_FILE.write_text(
                json.dumps({"last": day}, ensure_ascii=False), encoding="utf-8"
            )
        except Exception:
            pass

    def _token(self) -> str:
        return str(get_settings_service().get().get("telegram_bot_token", "")).strip()

    async def _api(self, method: str, payload: dict) -> None:
        token = self._token()
        if not token:
            return
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                await client.post(
                    f"https://api.telegram.org/bot{token}/{method}", json=payload
                )
        except Exception:
            pass

    async def send(self, chat_id: str | int, text: str) -> None:
        for start in range(0, max(len(text), 1), 3900):
            await self._api(
                "sendMessage",
                {"chat_id": chat_id, "text": text[start : start + 3900]},
            )

    async def send_voice(self, chat_id: str | int, text: str) -> bool:
        token = self._token()
        if not token:
            return False
        try:
            from app.services.voice_service import synthesize_speech

            mp3 = await synthesize_speech(text[:1200], rate="+6%")
            if not mp3:
                return False
            ogg = await asyncio.to_thread(self._to_ogg, mp3)
            if ogg is None:
                return False
            async with httpx.AsyncClient(timeout=45) as client:
                await client.post(
                    f"https://api.telegram.org/bot{token}/sendVoice",
                    data={"chat_id": str(chat_id)},
                    files={"voice": ("jon.ogg", ogg, "audio/ogg")},
                )
            return True
        except Exception:
            return False

    def _to_ogg(self, mp3: bytes) -> bytes | None:
        import shutil

        if not shutil.which("ffmpeg"):
            return None
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "in.mp3"
            dst = Path(tmp) / "out.ogg"
            src.write_bytes(mp3)
            result = subprocess.run(
                [
                    "ffmpeg", "-y", "-i", str(src),
                    "-c:a", "libopus", "-b:a", "48k", "-ar", "48000", "-ac", "1",
                    str(dst),
                ],
                capture_output=True,
            )
            if result.returncode != 0 or not dst.exists():
                return None
            return dst.read_bytes()

    async def _transcribe(self, file_id: str) -> str:
        token = self._token()
        if not token:
            return ""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                info = await client.get(
                    f"https://api.telegram.org/bot{token}/getFile",
                    params={"file_id": file_id},
                )
                file_path = info.json()["result"]["file_path"]
                audio = await client.get(
                    f"https://api.telegram.org/file/bot{token}/{file_path}"
                )
                raw = audio.content
        except Exception:
            return ""
        wav = await asyncio.to_thread(self._to_wav, raw)
        if wav is None:
            return ""
        try:
            from app.services.voice_service import VoiceService

            return await asyncio.to_thread(VoiceService().transcribe_wav, wav, "de-DE")
        except Exception:
            return ""

    def _to_wav(self, audio: bytes) -> bytes | None:
        import shutil

        if not shutil.which("ffmpeg"):
            return None
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "in.ogg"
            dst = Path(tmp) / "out.wav"
            src.write_bytes(audio)
            result = subprocess.run(
                ["ffmpeg", "-y", "-i", str(src), "-ar", "16000", "-ac", "1", str(dst)],
                capture_output=True,
            )
            if result.returncode != 0 or not dst.exists():
                return None
            return dst.read_bytes()

    async def _typing(self, chat_id: str | int) -> None:
        while True:
            await self._api("sendChatAction", {"chat_id": chat_id, "action": "typing"})
            await asyncio.sleep(4)

    def _system_message(self) -> dict:
        from app.services.persona_service import get_persona_service

        system = self._chat_service._system_prompt()
        memory = get_persona_service().read_memory_file(max_chars=6000).strip()
        if memory and memory[:400] not in system:
            system += "\n\nDEIN PERSOENLICHES GEDAECHTNIS (MEMORY.md):\n" + memory
        system += (
            "\n\nDu antwortest gerade ueber Telegram auf dem Handy des Nutzers. "
            "Halte Antworten kompakt und gut lesbar ohne Markdown-Tabellen."
        )
        return {"role": "system", "content": system}

    async def _answer(self, chat_id: str, text: str) -> str:
        from app.core.config import get_settings
        from app.schemas import ChatIn, MessageIn
        from app.services.chat_service import ChatService

        if self._chat_service is None:
            self._chat_service = ChatService()
        history = self._histories.setdefault(chat_id, [])
        history.append({"role": "user", "content": text})
        del history[:-HISTORY_KEEP]
        self._save_histories()
        provider, model = get_settings_service().telegram_selection()
        settings = get_settings()
        messages = [self._system_message(), *history[-HISTORY_SEND:]]
        payload = ChatIn(
            messages=[MessageIn(**m) for m in messages],
            persist=False,
            tool_mode="allow",
            max_tokens=2048,
            provider=provider or settings.default_provider,
            model=model or settings.emil_model,
            slot="emil",
        )
        parts: list[str] = []
        done_summaries: list[str] = []
        running_summaries: dict[str, str] = {}
        announced = 0
        async for event in self._chat_service.stream(payload):
            kind = event.get("type")
            if kind == "content":
                parts.append(event.get("delta") or "")
            elif kind == "tool" and event.get("status") == "running":
                summary = event.get("summary") or event.get("name") or "Aktion"
                if event.get("name"):
                    running_summaries[str(event["name"])] = str(summary)
                if announced < 3:
                    announced += 1
                    await self.send(chat_id, f"⚙️ {summary}")
            elif kind == "tool" and event.get("status") == "done":
                if event.get("ok") and event.get("name"):
                    name = str(event["name"])
                    done_summaries.append(running_summaries.get(name, name))
            elif kind == "error":
                parts.append(f"[Fehler] {event.get('message', '')}")
        answer = "".join(parts).strip()
        executed = list(dict.fromkeys(done_summaries))
        if not answer and executed:
            answer = "Erledigt ✅"
        if not answer:
            answer = "Da kam leider keine Antwort zurück."
        history.append({"role": "assistant", "content": answer})
        del history[:-HISTORY_KEEP]
        self._save_histories()
        if executed:
            report = "\n".join(f"• {s}" for s in executed[:8])
            answer = f"{answer}\n\n✅ Ausgeführte Befehle:\n{report}"
        return answer

    async def _handle(self, chat_id: str, text: str, voice: bool = False) -> None:
        typing = asyncio.create_task(self._typing(chat_id))
        try:
            answer = await asyncio.wait_for(self._answer(chat_id, text), timeout=180)
        except asyncio.CancelledError:
            typing.cancel()
            return
        except asyncio.TimeoutError:
            answer = (
                "Das hat zu lange gedauert. Versuch es nochmal oder wähle am PC "
                "ein schnelleres Modell."
            )
        except Exception as exc:
            answer = f"Da ist etwas schiefgelaufen: {exc}"
        finally:
            typing.cancel()
        wants_voice = (voice or chat_id in self._voice_reply) and chat_id not in self._voice_off
        if wants_voice:
            await self.send_voice(chat_id, answer)
        await self.send(chat_id, answer)

    def _launch(self, chat_id: str, text: str, voice: bool = False) -> None:
        old = self._running.get(chat_id)
        if old and not old.done():
            old.cancel()
        task = asyncio.create_task(self._handle(chat_id, text, voice))
        self._running[chat_id] = task

    async def _cancel_running(self, chat_id: str) -> bool:
        task = self._running.get(chat_id)
        if task and not task.done():
            task.cancel()
            return True
        return False

    async def morning_tick(self) -> None:
        data = get_settings_service().get()
        if not data.get("telegram_morning", False):
            return
        chat_id = str(data.get("telegram_chat_id", "")).strip()
        if not chat_id or not self._token():
            return
        target = str(data.get("telegram_morning_time", "07:30")).strip() or "07:30"
        now = datetime.now()
        today = now.strftime("%Y-%m-%d")
        if self._last_morning == today or now.strftime("%H:%M") < target:
            return
        self._save_morning(today)
        try:
            from app.services.show_service import _today_data
            from app.services.llm import complete

            context = json.dumps(_today_data(), ensure_ascii=False)
            text = await complete(
                "Du bist Jon und sprichst dem Nutzer Felix eine persönliche "
                "Guten-Morgen-Sprachnachricht auf sein Handy. Kurz (4-6 Sätze), warm, "
                "natürlich gesprochen: begrüße ihn, nenne Wetter, wichtige Termine und "
                "Erinnerungen aus den Daten, wünsche einen guten Start. Nutze nur echte "
                "Daten, erfinde nichts. Kein Markdown, keine Aufzählung.",
                f"Heutige Daten:\n{context}",
                max_tokens=500,
                temperature=0.8,
            )
        except Exception:
            text = "Guten Morgen, Felix! Ich wünsche dir einen richtig guten Start in den Tag."
        text = text.strip() or "Guten Morgen, Felix!"
        spoke = await self.send_voice(chat_id, text)
        await self.send(chat_id, ("🌅 " if not spoke else "🌅 ") + text)

    async def poll_once(self) -> None:
        token = self._token()
        if not token:
            await asyncio.sleep(5)
            return
        try:
            async with httpx.AsyncClient(timeout=35) as client:
                response = await client.get(
                    f"https://api.telegram.org/bot{token}/getUpdates",
                    params={"timeout": 25, "offset": self._offset},
                )
                data = response.json()
        except Exception:
            await asyncio.sleep(10)
            return
        if not data.get("ok"):
            await asyncio.sleep(30)
            return
        for update in data.get("result", []):
            self._offset = max(self._offset, int(update["update_id"]) + 1)
            message = update.get("message") or {}
            chat_id = (message.get("chat") or {}).get("id")
            text = (message.get("text") or "").strip()
            voice_msg = message.get("voice") or message.get("audio")
            if not chat_id:
                continue
            is_voice = False
            if not text and voice_msg and voice_msg.get("file_id"):
                await self._api("sendChatAction", {"chat_id": chat_id, "action": "typing"})
                text = (await self._transcribe(voice_msg["file_id"])).strip()
                is_voice = True
                if not text:
                    await self.send(
                        chat_id,
                        "Ich konnte die Sprachnachricht leider nicht verstehen. "
                        "Versuch es nochmal oder schreib mir.",
                    )
                    continue
            if not text:
                continue
            settings = get_settings_service()
            bound = str(settings.get().get("telegram_chat_id", "")).strip()
            if not bound:
                settings.update({"telegram_chat_id": str(chat_id)})
                await self.send(
                    chat_id,
                    "Verbunden! 🤝 Ich bin Jon und dieser Chat ist jetzt fest mit "
                    "deinem PC verknüpft. Schreib mir einfach, was ich tun soll.",
                )
                if text.startswith("/start"):
                    continue
                bound = str(chat_id)
            if str(chat_id) != bound:
                await self.send(chat_id, "Dieser Jon gehört schon jemand anderem. 🔒")
                continue
            if text.startswith("/start"):
                await self.send(
                    chat_id,
                    "Ich bin da. 👋 Schreib oder sprich mir, was ich auf deinem PC "
                    "tun soll — zum Beispiel: Öffne YouTube · Spiel was Entspanntes · "
                    "Wie geht es meinem PC? · Hab ich neue Mails?\n\n"
                    "Schick mir gerne auch eine Sprachnachricht. Befehle: /stimme = "
                    "ich antworte per Sprachnachricht · /endstimme = nur noch Text · "
                    "/stopp = laufende Aktion abbrechen · /reset = Gespräch vergessen.",
                )
                continue
            if text.startswith("/reset"):
                self._histories.pop(str(chat_id), None)
                self._save_histories()
                await self.send(chat_id, "Gespräch zurückgesetzt. 🧹")
                continue
            if text.startswith("/stopp") or text.startswith("/stop"):
                stopped = await self._cancel_running(str(chat_id))
                await self.send(
                    chat_id,
                    "Abgebrochen. ⛔" if stopped else "Gerade läuft nichts, alles ruhig. 👍",
                )
                continue
            if text.startswith("/endstimme"):
                self._voice_off.add(str(chat_id))
                self._voice_reply.discard(str(chat_id))
                await self.send(chat_id, "Okay, keine Sprachnachrichten mehr — nur noch Text. 💬")
                continue
            if text.startswith("/stimme") or text.startswith("/voice"):
                self._voice_off.discard(str(chat_id))
                self._voice_reply.add(str(chat_id))
                await self.send(
                    chat_id, "Alles klar, ich antworte dir jetzt als Sprachnachricht. 🎙️"
                )
                continue
            self._launch(str(chat_id), text, voice=is_voice)


_service: TelegramService | None = None


def get_telegram_service() -> TelegramService:
    global _service
    if _service is None:
        _service = TelegramService()
    return _service
