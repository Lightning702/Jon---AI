@echo off
setlocal enabledelayedexpansion
title Jon KI-Desktop
cd /d "%~dp0"
set ELECTRON_RUN_AS_NODE=
set NODE_OPTIONS=

if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo .env wurde erstellt. Bitte NVIDIA_API_KEY oder einen anderen Key in .env eintragen und die Datei erneut starten.
    start notepad ".env"
    pause
    exit /b 0
)

set PY=
py -3 -c "import sys" >nul 2>nul
if not errorlevel 1 set PY=py -3
if not defined PY (
    python -c "import sys" >nul 2>nul
    if not errorlevel 1 set PY=python
)
if not defined PY (
    echo Python wurde nicht gefunden oder ist nur der Windows-Store-Platzhalter.
    echo Bitte Python 3.11+ von https://www.python.org installieren und dabei "Add to PATH" anhaken.
    pause
    exit /b 1
)

%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 (
    echo Deine Python-Version ist zu alt. Bitte Python 3.11+ installieren.
    pause
    exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
    echo Node.js wurde nicht gefunden. Bitte Node.js 18+ von https://nodejs.org installieren.
    pause
    exit /b 1
)

findstr /I /C:"JON_LAN=true" ".env" >nul 2>nul
if not errorlevel 1 (
    powershell -NoProfile -Command "if(-not (Get-NetFirewallRule -DisplayName 'Jon Wear OS' -ErrorAction SilentlyContinue)){exit 1}else{exit 0}" >nul 2>nul
    if errorlevel 1 (
        echo Gebe Jon einmalig fuer Handy/Uhr im WLAN frei ^(Windows fragt kurz nach Admin^)...
        powershell -NoProfile -Command "Start-Process powershell -Verb RunAs -WindowStyle Hidden -ArgumentList '-NoProfile -Command New-NetFirewallRule -DisplayName ''Jon Wear OS'' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8756 -Profile Any'" >nul 2>nul
    )
)

set "WLANIP="
for /f "usebackq delims=" %%a in (`powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias 'WLAN' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty IPAddress)"`) do set "WLANIP=%%a"
if not defined WLANIP for /f "usebackq delims=" %%a in (`powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -like '192.168.*' -or $_.IPAddress -like '10.*' } | Select-Object -First 1 -ExpandProperty IPAddress)"`) do set "WLANIP=%%a"

set "LOGDIR=%LOCALAPPDATA%\Jon"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOGFILE=%LOGDIR%\backend.log"
del "%~dp0data\backend.log" >nul 2>nul

powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8756 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }" >nul 2>nul

%PY% -c "import fastapi,uvicorn,sqlalchemy,openai,anthropic,httpx,pydantic_settings,speech_recognition,pyautogui,pygetwindow,pyperclip,pypdf,cv2,edge_tts,cryptography,paho.mqtt.client,yt_dlp,pynput" >nul 2>nul
if errorlevel 1 (
    echo Installiere Backend-Abhaengigkeiten...
    %PY% -m pip install --disable-pip-version-check -r "%~dp0backend\requirements.txt"
    if errorlevel 1 (
        echo Erster Versuch fehlgeschlagen, versuche Installation nur fuer deinen Benutzer...
        %PY% -m pip install --disable-pip-version-check --user -r "%~dp0backend\requirements.txt"
        if errorlevel 1 (
            echo Die Installation der Backend-Abhaengigkeiten ist fehlgeschlagen. Bitte Meldungen oben pruefen.
            pause
            exit /b 1
        )
    )
)

echo Starte Jon-Backend...
del "%LOGFILE%" >nul 2>nul
start "Jon Backend" /min powershell -NoProfile -ExecutionPolicy Bypass -Command "$host.UI.RawUI.WindowTitle = 'Jon Backend'; Set-Location '%~dp0backend'; & %PY% -m app.main 2>&1 | ForEach-Object ToString | Tee-Object -FilePath '%LOGFILE%'"

echo Warte auf Backend...
set BACKEND_OK=
for /l %%i in (1,1,40) do (
    if not defined BACKEND_OK (
        powershell -NoProfile -Command "try{$null=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:8756/api/health;exit 0}catch{exit 1}" >nul 2>nul
        if not errorlevel 1 set BACKEND_OK=1
        if not defined BACKEND_OK ping -n 2 127.0.0.1 >nul
    )
)
if defined BACKEND_OK (
    echo Backend laeuft auf http://127.0.0.1:8756
    set "SPIELE="
    for /f "usebackq delims=" %%a in (`powershell -NoProfile -Command "try{$r=Invoke-RestMethod -TimeoutSec 5 http://127.0.0.1:8756/api/games; (($r.spiele | ForEach-Object { $_.titel + ' [' + $_.status + ']' }) -join ', ')}catch{''}"`) do set "SPIELE=%%a"
    if defined SPIELE (
        echo Spiele-Dienst laeuft: !SPIELE!
        echo Spiele starten erst ueber Werkzeuge ^> Spiele ^> Starten.
    )
    if defined WLANIP (
        echo.
        echo Fuer Handy/Uhr im selben WLAN eintragen:  http://%WLANIP%:8756
        echo Test im Handy-Browser:  http://%WLANIP%:8756/api/health
        echo.
    )
) else (
    echo.
    echo Das Backend ist nicht gestartet. Letzte Zeilen aus dem Log:
    echo ------------------------------------------------------------------
    powershell -NoProfile -Command "if(Test-Path '%LOGFILE%'){Get-Content '%LOGFILE%' -Tail 25}else{Write-Host 'Keine Log-Datei gefunden.'}"
    echo ------------------------------------------------------------------
    echo Vollstaendiges Log: %LOGFILE%
    pause
    exit /b 1
)

cd /d "%~dp0frontend"
if not exist "node_modules" (
    echo Installiere Frontend-Abhaengigkeiten...
    call npm install
    if errorlevel 1 (
        echo npm install ist fehlgeschlagen. Bitte Meldungen oben pruefen.
        pause
        exit /b 1
    )
)

echo Starte Jon-App...
call npm run dev

endlocal
