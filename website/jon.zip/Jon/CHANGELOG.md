# Changelog

Alle nennenswerten Änderungen an Jon.

## [4.60.1] — 2026-10-04

### 🎙️ Sprechen statt tippen

- **Sprachnachricht als Text:** Neben „Frag Jon …“ gibt es jetzt ein Mikrofon. Antippen, sprechen, auf ■ tippen. Jon wandelt das Gesprochene lokal in Text um und schreibt ihn ins Eingabefeld. Dort kannst du ihn noch ändern und dann wie gewohnt senden. Normales Tippen bleibt, wie es war.
- **Während der Aufnahme:** Pegel, Zeit und ein roter Stopp-Knopf. Esc verwirft die Aufnahme, nach zwei Minuten stoppt sie von selbst. Schon getippter Text bleibt erhalten, das Gesprochene wird angehängt.
- **Jon wird richtig verstanden:** Die Spracherkennung kennt jetzt Jon, MiniJon und FelWorks und schreibt nicht mehr „John“.

### 🛠️ Behoben

- Die Website-Demo nutzt automatisch Jons Standardmodell, wenn das am Pi eingestellte Modell ausfällt.
- Auf der Website standen im Download-Bereich noch 4.57.0 und ein alter Link zur Handy-App.

## [4.59.2] — 2026-10-04

### 🔑 Codes gelten für immer

- **Kein Ablaufdatum mehr:** Lizenzen aus Admin- und Entwickler-Codes laufen nie ab, auch wenn der Pi einmal nicht erreichbar ist.
- **Sperren wirkt trotzdem:** Jon fragt alle 6 Stunden beim Codeserver nach. Ist ein Code gesperrt oder der Admin-Code geändert, fällt das Gerät auf Standard zurück. Ohne Verbindung bleibt alles, wie es ist.

## [4.59.1] — 2026-10-04

### 🔑 Admin- und Entwickler-Codes über deinen Pi

- **Neue Stufe „Entwickler“:** Alles unbegrenzt wie Admin, aber ohne neue Codes zu erzeugen. Oben links steht dann „Entwickler“ in Blau.
- **Codes erzeugen als Admin:** Ein Klick auf „Admin“ zeigt ganz oben die Entwickler-Codes. Name und Geräteanzahl wählen, „Code erzeugen“, fertig. Jeder Code wird genau einmal angezeigt, lässt sich jederzeit sperren und wieder freigeben.
- **Ein Feld für alles:** „Lizenz oder Code eingeben“ nimmt Lizenzschlüssel, Admin-Code und Entwickler-Codes.
- **Codeserver auf dem Raspberry Pi:** Prüft Codes und stellt signierte Lizenzen für einzelne Geräte aus, über die feste Tailscale-Adresse auch unterwegs. Codes liegen dort nur als Hash, der Signierschlüssel hat den Pi nie verlassen, und nichts davon steht im Git oder in `jon.zip`. Bremse gegen Durchprobieren. Einrichtung per `scripts/codes-pi-einrichten.sh`, Details in `docs/CODES-PI.md`.

### 🤖 Jon Harness: Live-Verlauf

- **Jon meldet sich zwischendurch:** Bei jedem Schritt schreibt Jon einen kurzen Satz, was er gerade tut oder gefunden hat, ohne innere Gedankenkette.
- **Kompakte Aktionen:** Datei gelesen, Datei geändert mit +/−, Test gestartet, Test erfolgreich oder fehlgeschlagen mit den letzten Ausgabezeilen, korrigierte Schritte und Freigaben, alles als eigener Verlauf.
- **Arbeitsstatus oben:** Planen, Analysieren, Implementieren, Testen, Fertigstellen, dazu „Läuft seit …“, „Letzte Aktivität vor … Sek.“ und Stop. Der Arbeitsplan zeigt erledigte Schritte, den aktuellen Schritt in Gold und die offenen.
- **„Jon arbeitet gerade“:** Unten steht live, woran Jon gerade ist. Lange Aufträge dürfen jetzt bis zu 200 Schritte haben (Standard 80).

### 🧰 Werkzeuge neu gestaltet

- **Werkzeuge-Fenster:** breiter, Suche im Kopf, Navigation mit Symbolen für Harness, Fachteam, Stimmen & Transkripte, Beobachten und Support, Werkzeuge als Karten.
- **Stimmen & Transkripte:** komplett neu mit Ablagefläche für Audio und Video, Moduswahl, Stimmenauswahl als Karten, Auftragsliste mit Fortschritt, Ergebnis mit Player, Downloads, Zusammenfassung und Kopieren. Jetzt auch direkt in den Werkzeugen.
- **Support und Beobachten:** zweispaltig mit Infokarten, Tipps, Beispielen zum Antippen und schönerer Bestätigung.

### 🛠️ Behoben

- Das Pi-Demo-Skript hat beim Freigeben den ganzen Tailscale Funnel überschrieben. Die Demo läuft jetzt als Benutzerdienst unter `/demo`, andere Freigaben bleiben erhalten.
- Unter Beobachten und Support stand fälschlich „In dieser Gruppe ist gerade nichts frei“.

## [4.58.2] — 2026-10-03

### 🧈 Flüssiger

- **Premium-Dialog neu gestaltet:** fester Kopf, eine ruhige Scroll-Fläche mit schlanker Scrollbar und eine feste Leiste unten mit Tarifwahl und Kaufknopf. Beim Scrollen bekommen Kopf und Leiste eine feine Kante.
- **Kein Stottern mehr:** Keine Unschärfe-Filter mehr hinter scrollenden Flächen, keine Höhen- und Breiten-Animationen mehr, nur noch GPU-freundliche Einblendungen. Gemessen ohne Grafikkarte: Premium-Dialog und Werkzeuge scrollen mit 60 statt 30 Bildern pro Sekunde, der Dialog öffnet sich mit 60 statt 20.
- **Harness und Beobachten:** zeichnen beim Abfragen nur noch neu, wenn sich wirklich etwas geändert hat. Der Harness scrollt nur noch mit, wenn du unten bist, und springt nicht gegen dein eigenes Scrollen.

### 🌐 Neue Testseite

- **getjon.info/testen/ neu gestaltet:** im Look der Hauptseite mit Navigation und Fußzeile, einem Demo-Fenster mit Modus-Leiste (Jon, MiniJon, Maps, Transkribieren), Vorschlägen zum Losschreiben, Tipp-Anzeige, formatierten Antworten, Trefferliste und Karte für Orte und Routen, Live-Pegel beim Aufnehmen und Drag-and-drop für Audiodateien. Auf dem Handy sauber und ohne seitliches Scrollen.

## [4.58.1] — 2026-10-03

### ✦ Jon Premium, Standard und Admin

- **Drei Stufen, sichtbar neben „JON“:** Oben links steht jetzt „Standard“, „Premium“ oder „Admin“, am Handy im Chat-Kopf. Ein Klick öffnet den Premium-Dialog mit allen Funktionen, Tagesgrenzen, Tarifen, Lizenzeingabe und Admin-Anmeldung.
- **Premium:** Harness Pro, Fachteam ohne Limit, Funke am Handy, Fernsteuerung, Deep Learning und Recherche, Studio, Stimmen und Transkripte, Bildschirmanalyse, Browser-Agent, MiniJon-Aussehen, Familienpaket, Cloud-Sync, Alltags-Automatisierung und alle Spiele. Standard bleibt kostenlos mit 3 Harness-Aufträgen und 1 Fachteam-Lauf pro Tag.
- **Bezahlen über Stripe:** Checkout mit Abo (6,99 €/Monat oder 59,99 €/Jahr inkl. MwSt.), automatische Rechnungen, Stripe Tax und Kundenportal. Jon schaltet sich nach der Zahlung von selbst frei. Neue Seiten `getjon.info/premium/` und eine Dankesseite mit Lizenzschlüssel.
- **Fälschungssicher:** Lizenzen sind mit Ed25519 signiert und an bis zu drei Geräte gebunden. Der geheime Stripe-Key und der Signierschlüssel liegen nur in Netlify, nie im Git, im Download oder in der App. Admin gibt es nur mit dem Admin-Passwort des Lizenzservers.
- **Cloud-Sync:** Gedächtnis und Einstellungen Ende-zu-Ende verschlüsselt sichern und auf ein anderes Gerät holen.

### 👁️ Beobachten

- „Erinnere mich, wenn das Tiiny AI Pocket Lab rauskommt.“ Jon prüft das jetzt selbstständig jeden Tag mit der Websuche, entscheidet nur mit eindeutigem Beleg und Quelle und meldet sich genau einmal in der App und über Telegram. Liste unter **Werkzeuge → Beobachten**. Jon prüft, solange er auf PC oder Pi läuft.

### ✉️ Support

- **Werkzeuge → Support:** Probleme, Fehler, Vorschläge und Wünsche für neue Standard- oder Premium-Funktionen direkt an FelWorks schicken, wahlweise auch über das eigene E-Mail-Programm. Die Website hat dazu eine Support-Seite.

### 🌐 Jon ausprobieren

- **`getjon.info/testen/`:** Besucher schreiben mit Jon und MiniJon, finden Orte und Routen und transkribieren Sprache. Das läuft auf deinem Pi in einem abgeschotteten Dienst ohne Werkzeuge, ohne Gedächtnis und mit Ratenbegrenzung. Einrichtung per `scripts/demo-pi-einrichten.sh`.

### 🛠️ Behoben

- **„[Fehler] nvidia:“ ohne Text:** Große NVIDIA-Modelle wie Nemotron Ultra denken manchmal länger als 20 Sekunden still. Die Verbindung brach dann mit einer leeren Meldung ab. Pausen bis 180 Sekunden sind jetzt erlaubt, und jede Fehlermeldung sagt klar, was passiert ist.

### 💬 Harness-Sitzungen

- **Ein Chat pro Thema:** Ein neuer Auftrag im Harness startet keinen neuen Chat mehr. Folgeaufträge landen in derselben Sitzung, Jon kennt dabei die früheren Aufträge, ihre Ergebnisse und die geänderten Dateien. Mit **Neue Sitzung** beginnst du bewusst ein neues Thema.
- **Übersichtlicher Verlauf:** Frühere Aufträge der Sitzung klappen kompakt zusammen, der aktuelle bleibt voll sichtbar. Die Änderungsansicht zeigt alle Dateien der ganzen Sitzung. Vorschläge für den nächsten Schritt erscheinen, sobald Jon fertig ist.
- **Auch im Chat und in Telegram:** Startet Jon im normalen Chat erneut einen Harness-Auftrag im selben Projekt, arbeitet er in der laufenden Sitzung weiter. In Telegram setzt `/harness` die Sitzung fort, `/hneu` beginnt eine neue.

### 🖥️ Projektvorschau

- **Vorschau direkt im Harness:** Ein Klick auf **Vorschau** zeigt dein Projekt neben dem Verlauf, wahlweise in Desktop-, Tablet- oder Handybreite. Statische Seiten (index.html, dist, build, public …) öffnet Jon sofort über einen lokalen Server, der keine Geheimnisdateien wie `.env` ausliefert. Projekte mit `dev`-, `start`- oder `preview`-Skript startet Jon nach deinem Klick mit `npm run …` und erkennt die Adresse automatisch.
- **Lädt neu, wenn Jon fertig ist:** Nach jedem Auftrag mit Änderungen aktualisiert sich die Vorschau selbst. Protokoll, Neu laden, Im Browser öffnen und Stoppen sind eingebaut.

### 🛠️ Zuverlässig mit NVIDIA und Ollama

- **NVIDIA:** Statt nach 10 Sekunden ohne erstes Token aufzugeben, wartet der Harness bis zu 150 Sekunden, wiederholt bei 429, 5xx und Zeitüberschreitungen automatisch mit kurzen Pausen und weicht auf Jons Ersatzmodelle aus. Denkblöcke (`<think>`) und reine Reasoning-Antworten werden richtig gelesen. Jeder Wiederholversuch erscheint als Hinweis im Verlauf.
- **Ollama:** Der Harness fordert ein Kontextfenster von 16.384 Token an, damit Anweisungen und Dateien nicht mehr abgeschnitten werden. Reicht der Speicher nicht, fällt er automatisch auf die eingestellte Länge und eine kompakte Anleitung zurück. Der Kontext wird passend zum Fenster gekürzt, die letzte Aktion bleibt vollständig.
- **Windows:** PowerShell-Befehle laufen mit `-ExecutionPolicy Bypass`, damit `npm`, `npx` und Co. nicht an der Ausführungsrichtlinie scheitern. Das Modell erfährt, welche Shell läuft, und schreibt keine `&&`-Ketten mehr für PowerShell.
- **Kein Leerlauf mehr:** Ändert ein Modell eine Datei ohne Plan, nimmt Jon den Auftrag als Plan, statt den Schritt abzulehnen. Macht das Modell viermal hintereinander denselben Fehler, hält der Harness mit einer klaren Meldung an, statt alle 40 Schritte zu verbrauchen.
- **Fachteam:** Nutzt denselben zuverlässigen Modellzugang mit Wiederholungen und Ersatzmodellen.

## [4.58.0] — 2026-10-02

### ✦ Jons Fachteam – live animiert, überall

- **Fest in Jon eingebaut:** Jon setzt sein Fachteam jetzt selbst ein, sobald eine Aufgabe mehrere Perspektiven braucht oder du nach Agenten fragst – in App, Web, Telegram und am Handy. Das Team arbeitet nur lesend und fragt deshalb nicht mehr nach Freigabe.
- **Live-Karte im Chat:** Jons Kern in der Mitte, die Fachagenten fliegen heraus, Datenströme fließen entlang der Verbindungen, die Gegenprüfung läuft als Radar-Scan, beim Bündeln fließen die Ergebnisse zurück. Jeder Agent zeigt Status, Dauer und Ergebnis; das Team lässt sich in der Karte stoppen.
- **Agenten-Dock:** Läufe aus Telegram, vom Handy oder aus dem Terminal erscheinen unten rechts als kleine kreisende Pille – ein Tipp öffnet alle laufenden Teams und Harness-Aufträge.
- **Werkzeuge → Fachteam** neu gestaltet: Fachrichtungen als farbige Chips, Agentenzahl, Webrecherche und Verlauf.

### 🛠️ Jon Harness repariert

- **Jons Modell statt MiniJons:** Der Harness lief bisher standardmäßig mit MiniJons kleinem Plauder-Modell und konnte deshalb kaum coden. Jetzt nutzt er immer Jons Modell; MiniJon begleitet nur noch auf Wunsch.
- **Robuster:** Werkzeug-JSON mit Begleittext oder Codeblock wird erkannt. Hält ein Modell das Format dauerhaft nicht ein, bricht der Harness mit einem klaren Hinweis ab, statt alle Schritte zu verbrauchen.
- **Fachagenten im Harness** nutzen die Fachprofile des Teams.
- **Live-Karte im Chat** mit Werkzeug-Satellit, Arbeitsplan, Freigabe-Knöpfen und „Im Harness öffnen“.
- **Neuer Arbeitsbereich** in Jons Gold-auf-Tinte-Look mit animiertem Rahmen, solange Jon arbeitet.

### 🔥 Funke – dein neuer Begleiter auf dem Handy (Jon Gerät 1.7.0)

- **Funke ersetzt MiniJon auf dem Handy:** ein leuchtender Funke mit Gesicht und acht Stimmungen, der mit Jons vollem Modell und allen Werkzeugen Aufgaben komplett übernimmt.
- **Schnellaktionen** für Timer, Erinnerungen, Tagesplan, Lernen, Fachteam und Wetter, Diktat, Freigaben direkt im Gespräch und ein Verlauf, der bleibt.
- **Über allen Apps:** Die schwebende Figur ist jetzt Funke – orange und funkensprühend, während er arbeitet, und freut sich, wenn er fertig ist.
- **Fachteam- und Harness-Karten** auch im normalen Handy-Chat, dazu neue Vorschläge auf der Startseite.

### 🔄 Sicher aktualisieren

- **`jon-aktualisieren.bat`:** Doppelklick im Jon-Ordner holt die neue Version. Es wird nichts gelöscht: Eigene Dateien und lokale Änderungen bleiben erhalten, vorher wird ein Sicherungsstand angelegt. Ändert die neue Version eine Datei, die du selbst bearbeitet hast, bricht das Update ab, ohne etwas zu verändern.
- **Eingebauter Updater repariert:** Er hat lokale Änderungen bisher in den Git-Stash geschoben und danach nicht zurückgeholt. Jetzt arbeitet er wie die neue Update-Datei – ohne Stash, mit Sicherungsstand und Konfliktprüfung.

### ✨ Oberfläche

- **Neuer Startbildschirm** mit animiertem Jon-Kern und Vorschlägen für Fachteam, Harness, Entdecken und Jon Maps.
- **Chat-Blasen** mit animierten Werkzeug-Chips, einem atmenden Jon-Kern statt „Jon schreibt …“ und frei stehenden Karten ohne Doppelrahmen.
- **Behoben:** Nach einem Fehler beim Start (zum Beispiel ohne erreichbares Modell) blieb die Eingabe im „Stop“-Zustand hängen. Verbindungsabbrüche beenden jetzt jede Antwort sauber.

## [4.57.0] — 2026-10-02

- YouTube-Links können anhand tatsächlich abgerufener Untertitel zusammengefasst werden. Videos ohne verfügbare Untertitel melden einen Fehler.
- MP3, WAV, M4A, OGG, OPUS, FLAC, AAC und Videoton lassen sich mit `/transkript` vollständig lokal verschriften. Transkripte sind als Textdatei herunterladbar.
- `/podcast Dein Text` erstellt eine MP3 aus dem vollständigen Text. Lange Texte werden in Abschnitten gesprochen; die Sprachausgabe nutzt Microsofts Dienst.
- Neuer eigener Harness-Arbeitsbereich mit Projektleiste, Auftragssuche, Eingabefeld unten, Änderungsübersicht und farbiger Diff-Ansicht.
- Fachteam mit acht Profilen, begrenzten parallelen Teilaufgaben, Gegenprüfung, Abbruch und dauerhaftem Auftragsverlauf. Fehler und Widersprüche bleiben als offene Prüfung sichtbar.
- MiniJon begleitet Harness-Aufträge, verwendet seinen eigenen Modellzugang und zeigt Tätigkeiten als animierter 3D-Roboter. Ziehen zwischen Monitoren wurde korrigiert.
- Datierte Alltagsangaben bleiben über Neustarts erhalten. Bildschirmhilfe prüft das aktuelle Fenster und die Freigabe des gewählten Anbieters.
- Jon Gerät 1.6.0 enthält MiniJon als schwebenden Begleiter, das Fachteam und den Wechsel zwischen Overlay und Kiosk-Fenster.
- Das Windows-Paket enthält das lokale Whisper-Sprachmodell. Medienaufträge können neben Fachteam und Harness weiterlaufen.

## [4.56.1] — 2026-09-29

### 📱 Jon Gerät 1.4.3 – die Handy-App für die ganze Familie

- **Kiosk sauber verlassen:** Nach dem Beenden des Kiosk-Modus sind alle Apps sofort wieder
  frei, und Jon sperrt das Handy beim Öffnen nicht mehr von selbst. Hängt Android doch einmal
  an einer blockierten Systemseite fest, löst Jon das beim nächsten Start oder bietet
  „Jetzt neu starten“ an.
- **Viel kleiner:** Die App schrumpft von 130 MB auf 35 MB (Play-Paket 41 MB). Das
  Sprachmodell für „Hey Jon“ und die Offline-Abschrift (45 MB) lädt Jon erst, wenn es
  gebraucht wird – mit Prüfsumme gegen beschädigte Downloads.
- **Speicher sparen:** Jon behält standardmäßig nur ein Offline-Modell und löscht die
  anderen, sobald ein neues fertig ist. Unter Offline-KI steht, wie viel belegt ist, und
  „Nur Standard behalten“ schafft auf einen Tipp Platz. Fehlt ein gewähltes Modell, antwortet
  automatisch das Standardmodell.
- **Mehrere Jons:** Das Handy kann mit mehreren Jons gekoppelt sein, zum Beispiel mit dem Pi
  und dem PC. Unter Einstellungen → Verbindungen wechselst du per Tipp; fällt der aktive aus,
  springt das Handy von selbst zum nächsten erreichbaren. Die bisherige Kopplung wird übernommen.
- **Apps verstecken:** In der Kindersicherung lassen sich die freigegebenen Apps komplett
  verstecken. Menü, Einstellungen und Bildschirmzeit zeigen sie erst wieder, wenn die
  Verwaltung entsperrt ist – per Sprache („öffne WhatsApp“) gehen sie weiter.
- **Neues App-Symbol:** ein schlichtes „j“ mit türkisem Punkt, auch als Themen-Icon, in der
  Statusleiste und beim Start.

- **Drei Wege:** mit Jon am PC oder Pi, mit eigenem API-Schlüssel („Auf Jon verzichten“)
  oder ganz offline mit Gemma 4 & Co. direkt auf dem Handy. Die Offline-KI lädt Jon
  vor, wenn du sie oft nutzt – die erste Antwort kommt dann ohne Wartezeit.
- **Chat und Work** mit Plan, Ergebnis-Karten, Datei-Vorschau (Word, Excel, PowerPoint,
  PDF), Podcasts, Websites und Befehlen wie in Telegram (`/website`, `/timer 10`, `/sos` …).
- **Freie App-Auswahl:** Eltern legen fest, welche Apps aus Jon heraus erreichbar sind –
  Limits, Schlafenszeit und Kiosk gelten dann genau für diese Apps.
- **Updates ohne Kabel:** Die App holt neue Versionen von deinem PC oder Pi und
  installiert sie selbst. Neue Handys laden sie unter `http://<jon>:8756/geraet` per QR-Code.
  Jon auf dem Pi lässt sich direkt aus der App aktualisieren.
- **Teilen mit Jon:** Texte, Links, Fotos und Dateien aus jeder App an Jon schicken.
- **Im Hintergrund verbunden:** Jon Chat, Durchsagen und fertige Antworten kommen auch
  bei geschlossener App als Benachrichtigung.
- **Widget und Schnellzugriff:** Schritte und nächster Wecker auf dem Startbildschirm,
  „Mit Jon sprechen“ als Kachel in den Schnelleinstellungen.
- **Sicherung** auf den PC oder Pi (täglich automatisch, die letzten 10 bleiben) oder als
  Datei in den Downloads – samt Wiederherstellung.
- **Datenschutz-Seite** mit allen Berechtigungen und „Alle Daten löschen“.
- **Englisch:** Die App gibt es jetzt auch auf Englisch (Einstellungen → Sprache), Jon
  antwortet dann auf Englisch.
- **Fingerabdruck statt Admin-PIN:** Mit Warnhinweis – kommt ein neuer Fingerabdruck am
  Handy dazu, schaltet Jon die Funktion automatisch ab.

### 👨‍👩‍👧 Familie

- **Extra-Zeit anfragen:** Ist eine App gesperrt, kann das Kind um 15, 30 oder 60 Minuten
  bitten. Die Anfrage erscheint am PC als Karte im Chat und unter Geräte, und per Telegram –
  dort reicht `/ja` oder `/nein`. Die Antwort kommt sofort am Handy an.
- **Kinder-Modus:** Antworten passend zum Alter, Hausaufgaben-Hilfe Schritt für Schritt statt
  fertiger Lösungen, SafeSearch, nur sichere Werkzeuge und keine Webcam. Gilt für Jon am PC
  oder Pi, für den eigenen Zugang und für die Offline-KI.
- **Wochenbericht:** Jeden Sonntag um 18 Uhr Bildschirmzeit, meistgenutzte Apps, Schritte,
  Extra-Zeit-Anfragen und SOS der Woche – per Telegram und als Karte in Jon. Am PC unter
  Geräte → 📊 Woche, am Handy unter Bildschirmzeit.
- **SOS mit Standort und Anruf:** Auf Wunsch schickt das SOS den Standort mit (Karte in Jon,
  Standort in Telegram) und ruft danach direkt eine Nummer an.

### 🏠 Heimnetz und zweites Handy

- **Handys ohne Tailscale:** Mit „Im Heimnetz erreichbar“ koppeln Handys im selben WLAN
  direkt mit Jon am PC – eingerichtet im Assistenten „Jon-Gerät einrichten“.

### 🔐 Anmeldung

- Jon fragt bei jedem Öffnen nach Benutzername und Passwort – in der App und im Web.
  Telegram, Browser-Erweiterung, Handy-App und `jon` im Terminal verbinden sich weiter
  über den Geräte-Schlüssel.

## [4.55.1] — 2026-09-27

### 🎬 Dein Bildschirm als Video in Telegram

- **`/live` ist jetzt Video:** Jon nimmt den Bildschirm samt Mauszeiger auf und
  schickt alle 10 Sekunden ein neues Videostück, bis `/livestop` (höchstens
  10 Minuten). `/live 2` nimmt den zweiten Monitor, `/live alle` alle, ohne Angabe
  den Monitor mit der Maus. `/video` schickt sofort 15 Sekunden, `/video 40` länger.
  Das bisherige Standbild gibt es weiter mit `/livebild`.
- **Video nach Aktionen:** Sagst du Jon, er soll etwas öffnen, klicken oder
  tippen, nimmt er auf, während er Maus, Tastatur, Programme oder den Browser
  benutzt, und schickt dir das Video danach. Schaltbar mit `/video an|aus` und
  unter **Verbindungen → Telegram**.
- Aufgenommen wird mit ffmpeg (H.264). Fehlt ffmpeg, nimmt Jon mit OpenCV auf.

### ⌨️ Jon im Terminal repariert

- `jon` aus der fertigen App stürzte bei der ersten Nachricht mit „no such table:
  memories“ ab: Das Terminal hat seine Datenbank nie eingerichtet. Jetzt schon —
  und ein Fehler in einer Antwort beendet die Sitzung nicht mehr.
- Die fertige App legt neben sich keinen leeren Datenordner mehr an, wenn es
  schon Jon-Daten gibt, sondern nutzt sie — Terminal und App teilen sich damit
  Gedächtnis, Einstellungen und Schlüssel.
- Das Setup richtet den Befehl `jon` gleich bei der Installation ein, im
  portablen Paket macht das `Jon einrichten.exe`.
- `anbieter` zeigt Nummern (`anbieter 1`), warnt, wenn ein Anbieter noch keinen
  Schlüssel hat, und mit `schluessel <anbieter> <key>` hinterlegst du ihn direkt
  im Terminal.

## [4.54.0] — 2026-09-26

### 📲 Telegram antwortet wieder — auch wenn NVIDIA hakt

Über Telegram kam mit NVIDIA oft gar keine Antwort. Drei Ursachen, alle behoben:

- **Zu wenig Geduld.** Mit seinen rund 50 Werkzeugen braucht NVIDIA für das erste
  Wort manchmal 20 Sekunden und mehr. Jon hat nach 20 Sekunden aufgegeben und das
  Modell als „überlastet“ abgestempelt. In Telegram wartet er jetzt bis zu
  45 Sekunden pro Versuch, insgesamt bis zu 5 Minuten.
- **Tote Ersatzmodelle.** NVIDIA hat `openai/gpt-oss-120b` abgeschaltet (Antwort
  410), `openai/gpt-oss-20b` hängt nur noch. Genau diese beiden waren Standard und
  Ersatz. Neue Standards: `nvidia/nemotron-3-ultra-550b-a55b` für Jon und
  `meta/muse-glimmer-30b` für Mini Jon und Telegram. Steht noch ein abgeschaltetes
  Modell in der `.env` oder in den Einstellungen, nimmt Jon automatisch das neue.
  Aus der Modellliste sind die toten Modelle verschwunden.
- **Nachfragen hat die Antwort gelöscht.** Wer ungeduldig ein zweites Mal
  geschrieben hat, hat damit die laufende Antwort abgebrochen, und es kam gar
  nichts. Jetzt stellt Jon neue Nachrichten hinten an und beantwortet sie der
  Reihe nach. `/stopp` bricht weiterhin alles ab.

### 🦙 Ollama für Telegram — auch wenn Jon eine API benutzt

- **Verbindungen → Telegram** hat jetzt eine Auswahl für Anbieter und Modell.
  Wähle `ollama`, dann antwortet Jon in Telegram lokal über Ollama, während er in
  der App bei NVIDIA oder einer anderen API bleibt. Freigegebene Ollama-Server
  anderer Geräte (zum Beispiel vom Raspberry Pi) stehen ebenfalls zur Wahl.
- **Direkt im Chat umschalten:** `/anbieter` zeigt alle verfügbaren Anbieter,
  `/anbieter ollama` wechselt. `/modell` zeigt das aktuelle Modell und die
  Ollama-Modelle, `/modell ollama gemma3` wählt eines, `/modell auto` folgt
  wieder Jon.
- **Ollama als letzte Rettung:** Antwortet kein API-Modell, springt Jon (bei
  eingeschaltetem Anbieterwechsel) auf Ollama, statt mit einer Fehlermeldung
  aufzugeben — in Telegram und in der App.

### 🏷️ Jon von FelWorks

Fragt jemand, wer Jon gemacht hat, nennt er FelWorks — jetzt überall: im Chat,
im Terminal, am Telefon, in Telegram-Gruppen und in der Handy-Web-App. Das
Sprachmodell im Hintergrund gibt er nicht mehr als seinen Hersteller aus.

## [4.53.2] — 2026-09-21

### ⌨️ `jon` im Terminal — jetzt auch in der fertigen App

Der Befehl `jon` lief bisher **nur aus dem Quellcode**. In der installierten App
und im portablen Paket ging er ins Leere: Die gebündelte `jon-backend.exe` startet
über `run_backend.py`, und das hat ohne Rücksicht auf die Aufrufart immer den
Server hochgefahren — die Abzweigung in die Terminal-Sitzung wurde nie erreicht.

Jetzt erkennt auch die EXE `cli`, `terminal` und `jon` als erstes Wort und startet
die Sitzung. Und du musst nichts mehr einschalten: Beim ersten Start der App legt
Jon den Befehl selbst an (`%LOCALAPPDATA%\Jon\bin\jon.cmd`, unter macOS und Linux
`~/.local/bin/jon`) und trägt den Ordner in den PATH ein. Neues Terminal öffnen,
`jon` tippen — fertig. Zieht die App um oder kommt ein Update, zeigt der Befehl
automatisch auf die neue Fassung.

Wer das nicht will, entfernt es unter Einstellungen → Diagnose wieder oder setzt
`JON_KEIN_TERMINAL_BEFEHL=1`.

## [4.53.1] — 2026-09-21

### 🔍 Warum schweigt der Telegram-Bot?

Blieb ein Bot in einer Gruppe stumm, gab es bisher nichts zu sehen — Jon hat
Telegram-Fehler still geschluckt. Jetzt zeigt **Einstellungen → Diagnose → Bot
prüfen** in Klartext, woran es liegt: ob überhaupt ein Token auf diesem Gerät
eingetragen ist (jedes Gerät braucht seinen eigenen Bot), wie der Bot heißt, ob
sein **Privatsphäre-Modus** an ist, ob ein **Webhook** dazwischenfunkt, wie viele
Nachrichten angekommen sind und — je Gruppe — wie viele davon Jon gesehen, als
Anrede erkannt und beantwortet hat.

Einen fremden Webhook räumt Jon dabei gleich selbst weg: Solange einer
eingetragen ist, liefert Telegram **keine einzige** Nachricht an den Bot aus.
Dasselbe passiert jetzt automatisch, wenn beim Abholen ein Konflikt gemeldet
wird. Fehler landen außerdem im Protokoll, statt lautlos zu verschwinden.

Neu dafür: `GET /api/system/telegram`.

## [4.53.0] — 2026-09-20

### 📺 Jon zeigt dir seinen Bildschirm — über Telegram

Schreib deinem Jon-Bot **/live**, und er schickt dir ein Bild von seinem
Bildschirm, das sich **von selbst weiter aktualisiert**: alle Monitore
nebeneinander, alle paar Sekunden frisch, direkt im Chat. **/livestop** beendet
es wieder. Im selben Atemzug bekommst du einen Link zur Live-Ansicht im Browser —
die läuft flüssiger, kann Vollbild, einzelne Monitore und ein schnelleres Tempo.

Ein echter Telegram-**Videoanruf** ist das nicht: Anrufe laufen bei Telegram nur
zwischen Personen, ein Bot kann sie technisch nicht führen. Das laufend
erneuerte Bild im Chat ist der Weg, der ohne Umwege funktioniert — und ist der
Sache sehr nah.

Am PC findest du dasselbe unter **Einstellungen → Bildschirm live zeigen**, und
im Gespräch genügt „zeig mir deinen Bildschirm". Auf einem Gerät ohne Monitor —
dem Pi zum Beispiel — sagt Jon das klar, statt ins Leere zu greifen.

### 🔗 Deine Jons finden sich — über das Internet

Jon auf dem PC und Jon auf dem Raspberry Pi waren bisher zwei Fremde. Jetzt gibt
es den **Verbund**: Unter **Einstellungen → Geräte im Verbund** trägst du den
Kopplungscode des anderen Geräts ein, bestätigst dort die Anfrage — fertig.

Danach erreichen sich deine Jons **von überall**. Im selben WLAN sprechen sie
direkt miteinander, sonst über Jons verschlüsselten Vermittler — dieselbe
abgesicherte Leitung, über die schon das Handy mit Jon spricht. Niemand
unterwegs kann mitlesen, und es braucht keine offene Portweiterleitung.

Im Chat sagst du einfach „frag den Pi, ob die Erinnerung noch steht" — der andere
Jon antwortet mit seinem eigenen Gedächtnis und seinen eigenen Werkzeugen. Über
Telegram zeigt **/geraete** alle verbundenen Geräte, und **/live pi** holt dir den
Bildschirm eines anderen Geräts. In der Geräteliste siehst du Version, Weg
(Heimnetz oder Internet) und wann jedes Gerät zuletzt geantwortet hat.

## [4.52.0] — 2026-09-20

### 🖥️ Kein schwarzer Bildschirm mehr am Raspberry Pi

Wer Jon am Pi im WLAN aufgerufen hat — `http://<pi>:8756/app/?token=…` —, sah oft
nur **Schwarz**. Grund: Über eine Netzwerkadresse gilt eine Seite dem Browser als
unsicher, und dann gibt es `navigator.mediaDevices` schlicht nicht. Jons
Sprachsteuerung hat beim Start genau daran gehorcht, ist gestolpert und hat die
ganze Oberfläche mitgerissen, bevor das erste Pixel stand.

Jetzt prüft Jon vorher, ob der Browser überhaupt ein Mikrofon herausgibt. Ist
keines da, startet die Oberfläche trotzdem vollständig, der Mikrofonknopf ist
durchgestrichen und die Einstellungen sagen in einem Satz, warum: über eine
Netzwerkadresse erlauben Browser keinen Mikrofonzugriff, das geht nur über
localhost oder https. Dasselbe gilt fürs Kopieren — wo die Zwischenablage
gesperrt ist, kopiert Jon jetzt auf dem alten Weg statt mit einem Fehler
abzubrechen.

Und falls doch einmal etwas im Aufbau schiefgeht, bleibt der Bildschirm nicht
schwarz: Jon zeigt eine Karte mit dem Fehlertext und einem Knopf zum Neuladen.

### 🔑 Der Geräte-Schlüssel fragt nach, statt still zu bleiben

Fehlt der Schlüssel oder ist er alt, kam bisher eine leere Oberfläche. Jetzt
öffnet Jon ein kleines Feld, in das du den Schlüssel einfügst — mit dem Hinweis,
wo er steht (`~/.jon/data/access.token` am Pi, Einstellungen → Diagnose am PC).

### 📦 Die fertige Web-App liegt jetzt bei

Der Pi musste die Oberfläche bisher selbst bauen — was auf kleinen Geräten gern am
Arbeitsspeicher scheiterte und dann eine veraltete Version stehen ließ. Ab jetzt
liegt die gebaute Web-App im Ordner `webapp/` im Projekt: `git pull`, Dienst neu
starten, fertig. Node.js braucht der Pi nicht mehr. `pi-update.sh` räumt alte
Bauten weg, nennt am Ende wieder die komplette Adresse **mit** Schlüssel, und die
Oberfläche wird nicht mehr zwischengespeichert — ein Update kommt damit sofort am
Handy an.

## [4.51.3] — 2026-09-13

### ⏱️ Eine Uhr für Timer, Wecker und Stoppuhr

Timer, Wecker und Stoppuhr sind jetzt **eine einzige Uhr im Chat**, mit drei
Reitern. Sie zeigt den Ring, die großen Ziffern und genau die Knöpfe, die zur
gewählten Art passen: beim Timer die Restzeit und wann er abläuft, beim Wecker
die Klingelzeit und wie lange es noch dauert, bei der Stoppuhr die laufende Zeit
auf Zehntel genau. Läuft nichts, stellst du direkt in der Karte ein und drückst
**Starten**.

Jon versteht die Uhr auch im Gespräch: „erhöh um 7 Minuten“, „mach zwei Minuten
weniger“, „Wecker eine halbe Stunde später“, „pausier mal“, „weiter“,
„nochmal von vorn“, „stopp“ oder „Ton aus“. Welche Uhr gemeint ist, findet er
selbst — über die Art (Timer, Wecker, Stoppuhr), über die Beschriftung
(„der Pizza-Timer“) oder einfach die zuletzt gestartete.

Der **Weckton kommt jetzt aus dem PC**, nicht nur aus dem Chatfenster. Läuft ein
Timer ab, klingelt Jons Backend — auch wenn das Fenster im Hintergrund liegt.
Wecker bekommen zusätzlich weiterhin einen echten Windows-Weckruf mit Popup, damit
sie auch klingeln, wenn Jon geschlossen ist; doppelt tönt es dabei nie.

Und Uhren, die du **über Telegram** startest, tauchen trotzdem im Chat auf: Jon
meldet sie mit einer Karte, sobald du wieder am Rechner bist.

### ⚡ Websuche in Sekunden statt Minuten

Eine Frage ans Netz ging bisher durch Jons Browser: Fenster starten, Seite laden,
Treffer auslesen. Jetzt sucht Jon **direkt** — in ein bis zwei Sekunden, ohne dass
etwas aufgeht. Die Suchmaschinen laufen parallel statt nacheinander, und die
Zeitlimits sind kuerzer. Gibt die schnelle Suche zu wenig her, holt Jon die Treffer
still aus seinem Browser nach — der probiert jetzt auch mehrere Suchmaschinen
durch, statt bei der ersten aufzugeben.

**Ein Fenster geht nur noch auf, wenn du es sagst.** Fragst du etwas, sucht Jon
still. Erst bei „oeffne“, „im Browser“, „geh auf“, „klick“, „ausfuellen“ oder
„in den Warenkorb“ bekommt er Browser, Browser-Agent und open_url ueberhaupt in die
Hand — bei einer reinen Frage stehen sie ihm gar nicht zur Verfuegung.

**Und Jon sucht nicht mehr im Kreis.** Hoechstens drei Suchen pro Frage, danach
antwortet er mit dem, was er hat. Vorher konnten daraus sechs Suchen und mehrere
Minuten werden.

**Er weiss wieder, welcher Tag heute ist.** Im Terminal fehlte der Hinweis auf das
aktuelle Datum — deshalb kam dort „das neueste iPhone ist das 15“ aus dem
Gedaechtnis statt aus der Suche. Jetzt gilt auch im Terminal: erst suchen, dann
antworten.

**Und er erfindet keine Zahlen mehr.** Preise, Betraege, Daten und Versionen
nennt Jon nur, wenn sie wirklich im Suchergebnis stehen; findet er keinen Preis,
sagt er das, statt einen zu raten. Bei Preisfragen liest er die Trefferseiten
automatisch mit, damit die Zahl auch wirklich vor ihm liegt - das gilt auch fuer
Treffer aus dem Browser. Duenne Ergebnisse landen nicht mehr im Zwischenspeicher,
sonst haette eine schlechte Suche 15 Minuten lang nachgewirkt. Eine Suche ohne
Suchbegriff wird gar nicht erst losgeschickt.

**Haengt dein Modell, weicht Jon aus.** Das Terminal kann das jetzt genauso wie die
App: Antwortet das gewaehlte Modell nicht, nimmt Jon ein anderes, sagt es dir — und
deine Modellwahl bleibt gespeichert. Welches Modell zuletzt gehangen hat, merkt er
sich ueber Sitzungen hinweg und probiert es nicht jedes Mal neu. Auch nach einem
Werkzeug-Aufruf gibt es jetzt ein Zeitlimit; vorher konnte Jon dort beliebig lange
haengen.

### ⌨️ Jon in jedem Terminal

Tipp `jon` — und du hast Jon komplett im Terminal. In Windows CMD, in PowerShell, im
macOS Terminal, unter Linux und im integrierten Terminal von VS Code. Beim Start
begruessen dich Logo, Menue und der Prompt `Du>`; von da an gilt der volle
Funktionsumfang: Chat, Code, Dateien, System, Browser, Projekte, Tools, Gedaechtnis
und der Agenten-Modus. `hilfe` zeigt Beispiele, Befehle und was Jon hier alles kann.

In **VS Code** (auch Cursor, Windsurf und JetBrains) erkennt Jon den Editor von
selbst und startet im **Code-Modus**: Er laedt den Ordner, nennt Projekttyp,
Git-Zweig und Groesse und meldet sich mit `Du (code)>`. Ohne Editor reicht ein
Projektordner — schon eine einzelne `index.html` genuegt. Im Code-Modus arbeitet Jon
nur in diesem Ordner und schreibt direkt in die Dateien, statt Code im Chat
auszugeben. `chat` und `code` wechseln jederzeit, `projekte` zeigt den Projektbaum.

**Saetze sind keine Befehle mehr.** „Code mir mit HTML eine Website“ ging bisher als
Befehl `code` durch und startete nur wieder die Projektanalyse. Jetzt gilt ein Wort
nur dann als Befehl, wenn es allein steht (oder mit `/` davor) — alles andere geht an
Jon. `/code bau mir ein Menue` schaltet um **und** erledigt den Auftrag gleich mit.

Anbieter und Modell waehlst du mit `anbieter` und `modell` — die Wahl bleibt
ueber Sitzungen hinweg gemerkt.

Eingerichtet wird der Befehl in der App unter **Zahnrad → Jon im Terminal**: ein
Klick, und `jon` liegt im PATH. Eine einzelne Frage geht auch direkt:
`jon "erklaere mir dieses Projekt"`.

### ▶️ Player — alle Downloads offline

Was der Downloader holt, bleibt jetzt da. Videos und Musik wandern in Jons
**Mediathek** und lassen sich im neuen **Player** (Werkzeuge → Player) jederzeit
ohne Internet anschauen und anhoeren — mit Vorschaubild, Suche, Filter nach Video
oder Musik, Weiter/Zurueck und Loeschen. Auch Playlists landen Song fuer Song
darin, nicht nur als ZIP.

### 🐾 Mini Jon, Katze und Hund sehen besser aus

Die 3D-Modelle sind runder und lebendiger: groessere Koepfe in Kindchen-Proportion,
Augen mit Iris, Pupille und zwei Glanzlichtern aus derselben Lichtrichtung, weichere
Schatten und ein sanfteres Laecheln. Mini Jons Augen sitzen jetzt richtig auf der
Kugel statt schief davor — suess statt sonderbar.

## [4.45.0] — 2026-09-12

### 🕶️ Alles wieder in Jons eigenem Browser

Jon sucht, öffnet, liest und klickt wieder komplett in **seinem eigenen, privaten
Browser** — auch Seiten, die du dir nur ansehen willst. Das ist die Voreinstellung.
Der Vorteil: Was Jon öffnet, kann er auch lesen. Er sieht die Seite mit ihren
sichtbaren Elementen, kann weiterklicken, vergleichen, Formulare ausfüllen — und
dein eigener Browser bleibt unberührt, ohne fremde Tabs und ohne Verlauf von Jon.

„Mach das in Edge“, „nimm meinen normalen Browser“ oder „öffne das mit Brave“ gilt
weiterhin sofort für genau diese eine Anfrage — Jon versteht jetzt auch
„normal“ und „gewohnt“ als deinen Standardbrowser. Dauerhaft umstellen kannst du es
unter **Einstellungen → Browser**.

Versucht das Modell eine Adresse über die Konsole zu öffnen — `Start-Process
https://…`, `start …`, `explorer …` —, fängt Jon das weiterhin ab und schickt sie
in seinen Browser.

## [4.44.0] — 2026-09-12

### 🌐 Webseiten gehen wieder in deinen Browser

„Oeffne mir YouTube“ landete zuletzt in Jons eigenem Browserfenster. Das war als
Vorteil gedacht — dort kann Jon mitlesen —, im Alltag will man eine Seite aber
einfach da haben, wo die Lesezeichen, die Anmeldungen und die Erweiterungen liegen.

Ab jetzt gilt die einfache Regel: **Seiten für dich öffnet Jon in deinem ganz
normalen Browser.** Seinen eigenen nimmt er nur noch dann, wenn er selbst lesen,
suchen, vergleichen oder klicken muss — denn nur dort sieht er wirklich, was auf
der Seite steht. Beides lässt sich jederzeit umdrehen: „mach das in Edge“ oder
„nimm deinen eigenen Browser“ gilt sofort für genau diese eine Anfrage,
dauerhaft stellst du es unter Einstellungen → Browser um.

Die Websuche bleibt, wie sie war: Sie läuft weiter in Jons Browser, damit er die
Treffer wirklich auswerten kann, statt nur ein Suchfenster aufzuschieben.

Versucht das Modell eine Adresse doch über die Konsole zu öffnen —
`Start-Process https://…`, `start …`, `explorer …` —, fängt Jon das ab und
leitet sie selbst in den eingestellten Browser um. Die Regel greift also auch dann,
wenn das Modell den falschen Weg wählt.

## [4.43.1] — 2026-09-12

### 🖱️ Der Einrichter reagiert wieder

Ein Doppelklick auf „Jon einrichten.cmd" tat nichts. Zwei Gründe: Die Datei suchte
eine `.ps1` unter einem Namen, den sie erst beim Bauen bekam — und `powershell -File`
meldet eine fehlende Datei mit **Exit-Code 0**, weshalb auch die eingebaute Pause nie
ansprang. Das Fenster blinkte auf und war weg.

Ersetzt durch **„Jon einrichten.exe"**: ein eigenständiges kleines Programm mit Jons
Symbol, das nichts Zweites mehr braucht, seinen eigenen Ordner findet und Fehler im
Klartext stehen lässt, bis man Enter drückt.

## [4.43.0] — 2026-09-12

### 📊 Präsentationen wie von Hand gemacht

Die alten Folien waren Gliederungen: fünf Stichwörter, keine Bilder, keine Bewegung,
stellenweise sogar Platzhalter wie „X PB/Monat". Das ist vorbei.

- **Echte Folienübergänge.** Jede Folie bekommt einen Wechsel — Blenden, Schieben,
  Wischen, Aufdecken, sogar **Morphen**. PowerPoint erkennt sie als seine eigenen,
  weil Jon sie als echtes OOXML schreibt (python-pptx kann das von Haus aus nicht).
- **Animationen.** Überschrift, Text und Stichpunkte blenden nacheinander ein,
  Aufzählungen Punkt für Punkt. Alles über `effekte: false` abschaltbar.
- **Echte Diagramme.** `layout: chart` erzeugt ein richtiges PowerPoint-Diagramm mit
  Datenreihen, Beschriftungen und Legende — als Balken, Linie, Fläche, Kreis, Donut
  oder gestapelt. Man kann es in PowerPoint anklicken und weiterbearbeiten.
- **Echte Tabellen.** `layout: table` setzt eine richtige Tabelle mit farbiger
  Kopfzeile und Zebrastreifen statt einer gemalten Attrappe.
- **Bilder, die Jon selbst malt.** Ein `bild_prompt` pro Folie genügt — Jon erzeugt
  das Bild und setzt es ein.
- **Vier neue Layouts:** `agenda` (nummerierte Gliederung mit Erklärungen), `text`
  (Fließtext, wenn ein Gedanke Raum braucht), `compare` (Gegenüberstellung mit
  Kopfleisten) und die beiden oben.
- **Viel mehr Text.** Jede Inhaltsfolie hat jetzt einen erklärenden Einleitungssatz,
  Stichpunkte sind ausformulierte Aussagen statt Fragmenten, und Sprechernotizen
  sind Pflicht. In der Messung: gut das Doppelte an Text pro Folie.
- **Keine erfundenen Zahlen mehr.** Der Skill verbietet Platzhalter ausdrücklich und
  verlangt eine Websuche, sobald echte Zahlen vorkommen.
- Der Textumbruch wird jetzt richtig gerechnet: Karten wachsen mit dem Inhalt, und
  bei sehr viel Text verkleinert Jon die Schrift, statt über den Rand zu laufen.

### 🌐 Jons eigener Browser ist die Regel

- **Alles Web-Mäßige läuft in Jons Browser** — Suche, Seiten öffnen, Aufträge. Nur
  dort kann er die Seite danach wirklich lesen.
- **Auf Zuruf ein anderer.** „Mach das in Edge", „such das mit Brave" — Jon versteht
  den Browsernamen aus normaler Sprache und nutzt ihn für genau diese Anfrage. Danach
  gilt wieder sein eigener, ohne Nachfrage. `open_url` kannte den Schalter vorher gar
  nicht und behauptete fälschlich, es öffne im „Standardbrowser".
- **Ehrlich beim Rückfall.** Kommt Jons Browser nicht durch (Captcha, Firewall),
  sagt das Ergebnis jetzt, dass die direkte Suche einsprang und warum.

### 🖥️ Desktop-Symbol auch für die ZIP

Die portable Fassung hatte keinen Installer und damit kein Symbol. Jetzt gibt es
gleich drei Wege dorthin:

- **„Jon einrichten.exe"** liegt der ZIP bei — ein eigenes kleines Programm **mit
  Jons Symbol**, das auf Doppelklick Desktop-Symbol und Startmenü-Eintrag anlegt und
  Jon startet. Fehlt `Jon.exe` daneben, weil noch nichts entpackt wurde, sagt es das
  im Klartext und wartet, statt wortlos zu verschwinden.
- **Jon fragt selbst.** Startest du die portable Fassung per Doppelklick auf
  `Jon.exe`, bietet er beim ersten Mal an, das Symbol anzulegen — mit „Nicht mehr
  fragen", falls du das nicht willst.
- **Auf Zuruf:** „leg mir ein Desktop-Symbol an" oder „entfern das Desktop-Symbol",
  auf Windows, macOS und Linux.

## [4.42.0] — 2026-09-12

### 🛠️ Jon macht jetzt Dateien — echte, die du anklicken kannst

Bisher konnte Jon dir erklären, wie man eine PDF schreibt. Jetzt schreibt er sie: eine
echte Datei auf deiner Festplatte, am richtigen Ort, als anklickbare Karte im Chat.

- **Er erzeugt echte Dokumente.** PDF, Word (docx), OpenDocument (odt), Excel (xlsx),
  ODS, CSV, Markdown, Text — dazu jede Code-Datei von Python bis Rust. Den Inhalt
  schreibt er vollständig aus: Überschriften, Absätze, Aufzählungen, nummerierte
  Schritte, bei Tabellen echte Zellen mit fetter Kopfzeile.
- **Jons eigener Ordner.** Beim ersten Start legt er sich `Jon/` im Benutzerordner an,
  mit Fächern für Projects, Documents, PDFs, Images, Videos, Audio, Blender, Code,
  Downloads, Generated, Workspace, Logs, Temp, Backups und Config. Sagst du nichts dazu,
  sortiert er selbst ein — eine PDF landet unter PDFs, ein Python-Skript unter Code.
- **Dein Speicherort gewinnt.** „Speicher das auf dem Desktop", „leg alles unter
  Desktop/Meine Projekte/Essen ab", „mach einen Ordner namens YouTube Projekt" — der
  Ordner wird angelegt und benutzt. Der Speicherort ist frei einstellbar.
- **Datei-Karte im Chat** statt eines Pfads im Fließtext: Symbol, Name, Typ, Größe,
  Ordner und drei Knöpfe — **Öffnen**, **Herunterladen** und **Im Ordner öffnen**. Der
  letzte öffnet wirklich den Dateimanager: Explorer unter Windows, Finder unter macOS,
  nautilus/dolphin/nemo/thunar unter Linux, mit der Datei markiert.
- **Er findet wieder, was er gemacht hat.** Jede erzeugte Datei landet in einem Index
  mit Titel, Projekt, Zeit und Typ. „Zeig mir die PDF über Essen von letzter Woche"
  genügt — Jon sucht nach Bedeutung und Zeitraum, nicht nach Dateinamen.
- **3D mit Blender.** Beschreib die Szene, und Jon schreibt das bpy-Skript selbst, lässt
  Blender im Hintergrund laufen, **repariert eigene Fehler und versucht es erneut**,
  speichert die .blend-Datei, rendert ein Vorschaubild und exportiert auf Wunsch nach
  fbx, obj, glb, gltf oder stl. Ist Blender nicht installiert, sagt er genau das — statt
  so zu tun, als wäre etwas entstanden.
- **Über Telegram kommt die Datei mit.** Was Jon erzeugt, schickt er dir als Dokument
  oder Bild in den Chat, mit Namen und Ablageort. Zu große Dateien meldet er ehrlich,
  statt sie stumm zu verschlucken.
- **Er weiß, was auf dem Rechner fehlt.** Beim Start prüft Jon Python, Node, npm, Git,
  FFmpeg und Blender samt Version, dazu seine Bibliotheken und ob überhaupt ein Modell
  eingerichtet ist. Fehlt etwas, nennt er den Installationsbefehl.
- **Sicherheit bleibt vorn.** Jon arbeitet nur in seinem Ordner, deinem Benutzerordner
  und Ordnern, die du freigibst. Systemverzeichnisse sind gesperrt, Pfad-Tricks mit `..`
  laufen ins Leere, und nichts wird versehentlich überschrieben — aus `Bericht.pdf` wird
  `Bericht-2.pdf`.

### 🧠 Neuer System-Prompt

Jons Anweisungen waren über Jahre zu einem einzigen 14.500-Zeichen-Block gewachsen.
Jetzt sind es 17 klar getrennte Abschnitte in einer eigenen Datei — kürzer, schärfer,
und **passend zum Betriebssystem**: unter macOS und Linux verspricht er keine
PowerShell mehr. Ein Regressionstest bewacht, dass keine Fähigkeit beim nächsten Umbau
still verschwindet.

### 🐞 Behoben

- **Shell-Befehle stürzten an Sonderzeichen ab.** `run_cmd` und `run_powershell`
  lasen die Ausgabe mit der ANSI-Codepage; ein einziges unpassendes Byte — wie es
  pytest, npm, git oder ffmpeg ständig ausgeben — ließ den Lese-Thread sterben und
  Jon meldete nur `'NoneType' object is not subscriptable`. Jetzt wird die Ausgabe
  gegen mehrere Kodierungen geprüft, und Umlaute kommen in beide Richtungen sauber an.
- **Mehrfach zitierte Befehle** wie `cd /d "C:\Ordner mit Leerzeichen" && "python.exe"
  -m pytest` scheiterten an der Zitierregel von `cmd`. Jon nutzt jetzt den
  vorhersagbaren Weg.

## [4.41.0] — 2026-09-12

### 🧠 Jon rechnet vorher damit — und lernt, wenn es anders kommt

Bisher hat Jon gehandelt und danach protokolliert. Jetzt sagt er sich **vorher**, was er
erwartet, vergleicht es mit dem, was wirklich passiert, und zieht seine Schlüsse aus dem
Unterschied. Daraus wird ein geschlossener Kreis: erwarten → handeln → vergleichen →
lernen.

- **Er weiß, wie sicher er sich ist.** Vor jedem Werkzeug schätzt Jon aus seiner eigenen
  Statistik, wie wahrscheinlich es klappt. Frag ihn „schaffst du das?", und du bekommst
  eine Zahl mit Begründung statt eines freundlichen Ja.
- **Überraschungen sind der Lehrstoff.** Weicht das Ergebnis stark von seiner Erwartung
  ab, notiert er das als Erfahrung, hält es im Gedächtnis fest — und bei einem echten
  Bruch legt er sich selbst die Frage hin, warum etwas nicht mehr geht, das früher lief.
- **Er weiß, wie gut er sich kennt.** Unter Denken → Gelernt steht sein Brier-Wert: wie
  treffsicher seine eigenen Einschätzungen zuletzt waren, und welche Werkzeuge ihn am
  häufigsten überraschen.
- **Offene Fragen statt geratener Antworten.** Wenn Jon etwas nicht weiß, merkt er sich
  die Frage. Unter Denken → Offen siehst du sie, kannst sie einzeln klären lassen oder
  Jon nachts selbst suchen lassen — die Antwort landet danach in seinem Gedächtnis.
  Auch Widersprüche im Gedächtnis werden zu Fragen, statt stumm nebeneinander zu stehen.
- **Gelernte Fertigkeiten.** Machst du denselben Ablauf immer wieder, findet Jon das
  Muster in seinem Protokoll und merkt es sich als **einen** Handgriff — mit Namen,
  Platzhaltern und Erfolgsquote. Danach führt er ihn in einem Rutsch aus, statt jeden
  Schritt neu zu erfinden. Riskante Schritte brauchen weiterhin deine Freigabe.
- **Ein echter Planer im Backend.** Größere Aufträge zerlegt Jon in Schritte mit
  Abhängigkeiten, arbeitet sie der Reihe nach ab und **plant selbst um**, wenn einer
  scheitert — bis zu zweimal, mit dem Fehlertext als Ausgangspunkt. Klappt ein Plan im
  ersten Anlauf, wird daraus automatisch eine Fertigkeit.
- **Er teilt sich den Aufwand ein.** Vor der Antwort schätzt Jon, wie schwer die Sache
  ist. Auf einen kurzen Zuruf antwortet er direkt; bei einem vielschichtigen Auftrag holt
  er mehr Hintergrund heran und prüft sich strenger selbst.
- **Arbeitsgedächtnis mit Budget.** Was Jon vor einer Antwort über Ziele, Welt, Notizen,
  Fertigkeiten und offene Fragen heranzieht, wird nach Relevanz gewichtet und passt in ein
  festes Zeichenbudget — statt alles stumpf anzuhängen.
- **Neue Werkzeuge** in der Gruppe „Denken & Lernen": `selbsteinschaetzung`,
  `ueberraschungen`, `frage_merken`, `offene_fragen`, `frage_klaeren`, `fertigkeiten`,
  `fertigkeit_nutzen`, `plan_machen`, `plan_ausfuehren`.
- **Alles abschaltbar** unter Einstellungen → Denken. Erwartung, Aufwandsschätzung und
  Fragen-Sammeln laufen lokal und kosten nichts; das nächtliche Klären und das
  automatische Lernen von Fertigkeiten sind bewusst aus, bis du sie einschaltest.
- Der Selbsttest wächst von 53 auf **65 Fälle** (alle grün), die Testsuite von 540 auf
  **566 Tests**.

## [4.40.0] — 2026-09-07

### 🧩 Jon im Browser — und alles Neue endlich im Download

Diese Ausgabe bringt die **Jon-Erweiterung für Chrome, Edge und Brave** und macht
zugleich alles herunterladbar, was seit 4.36.4 entstanden ist: den Android Connector
aus 4.37, den Browser-Agenten aus 4.38 und Jons neues Denken aus 4.39.

- **Jon-Symbol im Browser.** Ein Klick, und Jon nimmt sich die offene Seite vor:
  zusammenfassen, erklären, recherchieren, markierten Text verbessern, zu Jons Wissen
  hinzufügen, in ein Projekt speichern — oder frei fragen. Die Antwort läuft im Popup
  Wort für Wort mit.
- **Rechtsklick → „Mit Jon …"** auf jeder Seite und jeder Markierung: erklären,
  zusammenfassen, übersetzen, recherchieren, zu Jon senden, zu einem Projekt
  hinzufügen, als Notiz speichern.
- **Kein zweiter Jon.** Die Erweiterung rechnet nichts selbst, sie spricht mit dem Jon
  auf deinem Rechner — dein Modell, dein Gedächtnis, deine Projekte, deine Kosten.
- **Datensparsam.** Kein dauerhaftes Content-Script: Die Seite wird nur gelesen, wenn du
  eine Aktion auslöst, und das lässt sich ganz abschalten. Im Chat hat die Erweiterung
  nur Jons **Gast-Werkzeuge** — keine Dateien, keine Systembefehle. Der Geräte-Schlüssel
  liegt allein im lokalen Speicher deines Browsers.
- **Zwei Wege zur Erweiterung:** Sie liegt dem Windows-Paket unter `resources/extension`
  bei und steht als eigener Download auf der Website. Einbauen über `chrome://extensions`
  → Entwicklermodus → „Entpackte Erweiterung laden".
- Die Versionsnummer steht wieder überall gleich — `package-lock.json` war auf 4.37.0
  stehen geblieben.

## [4.39.1] — 2026-09-05

### 🌐 Jon surft standardmäßig selbst — und du entscheidest, was liegen bleibt

- **Jon-Browser ist jetzt Standard** für Websuche und alles, was mit Webseiten zu tun
  hat. `web_search` sucht im eigenen Browser und liefert echte Treffer mit Quelle,
  `open_url` öffnet dort — und Jon kann die Seite danach wirklich lesen.
- **Umstellbar** unter Einstellungen → Browser-Agent → „Womit öffnet Jon Webseiten?":
  Jon-Browser, Standardbrowser, Chrome, Edge, Firefox, Brave, Opera, Vivaldi. Jon
  sagt ehrlich dazu, dass er bei einem fremden Browser nicht mitlesen kann. Neues
  Werkzeug `browser_wahl`.
- **RAM oder Festplatte**: Jons Browser hält auf Wunsch **alles nur im
  Arbeitsspeicher** — kein Profil, kein Cache, keine Cookies auf der Platte, und
  auch Screenshots landen in einem flüchtigen Ordner, der beim Schließen verschwindet.
  Oder wie bisher auf der Festplatte, damit Logins erhalten bleiben.
- **Brave Search** ist die neue Standard-Suchmaschine im Browser, weil sie sich am
  zuverlässigsten lesen lässt. Blockt eine Suchmaschine den Browser (Captcha,
  Firewall), umgeht Jon das **nicht** — er nimmt die direkte Suche und sagt Bescheid.

## [4.39.0] — 2026-09-05

### 🧠 Jon denkt: Gedächtnis, Ziele, Eigeninitiative — und 47 Baustellen erledigt

Der größte Umbau seit es Jon gibt. Jon merkt sich, was passiert ist, versteht Zeit,
verfolgt Ziele über Tage, denkt von selbst voraus und weiß, was er kann.

**Gedächtnis und Zeit**
- **Ereignisgedächtnis**: Jede Aktion, jeder Chat, jeder Fehler landet auf einer
  Zeitachse. Neu: `was_war` und `verlauf_heute` — „Was habe ich gestern gemacht?"
  beantwortet Jon aus echten Daten statt zu raten.
- **Zeitverständnis**: „gestern", „vorgestern", „letzte Woche", „vor 3 Tagen",
  „Montag", „24.12." werden überall verstanden.
- **Gedächtnis mit Relevanz**: Erinnerungen werden nach Passung geholt, nicht nach
  Alter. Wiederholungen ersetzen alte Einträge, echte Widersprüche werden gesammelt
  und nachts geklärt, Ungenutztes verfällt.
- **Verlauf wird zusammengefasst** statt abgeschnitten — der Anfang eines langen
  Gesprächs geht nicht mehr verloren.
- **Nachts nacharbeiten**: Jon fasst den Tag zusammen, merkt sich dauerhafte Fakten,
  löst Widersprüche auf und leitet daraus die Ziele für morgen ab.

**Vorausdenken**
- **Ziele** mit Frist, nächstem Schritt, Fortschritt und Abhängigkeiten (`/denken`).
- **Eigeninitiative**: Jon schaut regelmäßig auf gestern, heute, die Ziele und die
  Termine und schlägt vor, was ansteht. Harmloses erledigt er auf Wunsch selbst,
  alles andere legt er dir vor.
- **Weltmodell**: Personen, Projekte, Geräte, Orte und ihre Beziehungen — statt 90
  getrennter Dateien.
- **Notizblock** als Arbeitsgedächtnis, das über Antworten hinweg gilt.
- **Selbstbild**: Jon kennt seine Werkzeuge, seine Erfolgsquote je Werkzeug und
  seine Grenzen — und sagt vorher, ob er sich etwas zutraut.
- **Erfahrungsgedächtnis** je Website und Werkzeug: was dort klappt und was nicht.
- **Lernen**: Jon erkennt wiederkehrende Abläufe, schreibt daraus Skills, lernt aus
  Fehlern und kann Trainingsdaten für ein eigenes Modell exportieren.
- **Agententeam**: große Rechercheaufgaben laufen auf mehreren Teilagenten parallel.

**Sicherheit und Verlässlichkeit**
- **Risikowächter für alle Werkzeuge**: niedrig läuft durch, mittel fragt im
  Nachfragemodus, hoch fragt **immer** — auch wenn du „alles erlauben" eingestellt
  hast. Kaufen, senden, löschen und gefährliche Shell-Befehle sind hoch.
- **Systemordner sind gesperrt**: In Windows-, Programm- und Systemverzeichnissen
  verändert Jon nichts, egal was er gerade tut.
- **Datenschutz-Gewissen**: Zugangsdaten und Zahlungsangaben verlassen den PC nicht,
  persönliche Angaben nur mit Hinweis — einstellbar warnen / streng / locker.
- **Rückgängig**: Die letzte Dateiaktion lässt sich zurücknehmen.
- **Budget** in Tokens je Tag und Euro je Monat, mit Warnung und Stopp.
- **Aufträge überleben Abstürze** und werden nach dem Neustart als unterbrochen
  gemeldet.
- **Verständliche Fehlermeldungen** statt roher Ausnahmen, und Jon prüft zuerst, ob
  überhaupt Internet da ist.
- **Selbstprüfung**: Auf Wunsch prüft Jon unsichere Antworten selbst und sagt, woran
  er zweifelt.

**Unter der Haube**
- **Werkzeugauswahl versteht Bedeutung** statt Stichwortlisten — „kannst du auf
  einer Homepage was raussuchen" findet jetzt den Browser.
- **Werkzeug-Registry** statt einer 3500-Zeilen-if-Kette; neue Werkzeuge sind ein
  Dekorator.
- **177 verschluckte Fehler** werden jetzt gezählt und stehen in der Diagnose.
- **Schema und Migration** für die JSON-Dateien, mit Sicherung vor jeder Umstellung.
- **Ergebnis-Cache** für wiederholte Abfragen.
- **Ereignisbus** als gemeinsamer Kern, an dem Wahrnehmung, Handlung und Ziele hängen.
- **Karten im Chat überleben das Neuladen**, und die Whitelist steht nur noch an
  einer Stelle.
- **Browser**: eigene Sitzung je Gespräch, Cookie-Dialoge datensparsam, Screenshots
  auf Wunsch von einem sehenden Modell beschrieben, Datei-Uploads, einstellbare
  Suchmaschine, automatisches Aufräumen von Screenshots und Profil-Cache.
- **Barrierefreiheit**: Fokusrahmen, Escape und Strg+Enter im Freigabedialog,
  ruhigere Animationen bei „prefers-reduced-motion".
- **Zweisprachig**: Die neuen Oberflächen sprechen Deutsch und Englisch.
- **Benchmark-Suite** mit 53 festen Prüfungen (`/api/denken/benchmark`) — sie fällt
  auf, bevor du es merkst. Dazu 26 neue Tests, insgesamt 537 grün.

## [4.38.0] — 2026-09-05

### 🌐 Browser-Agent: Jon benutzt das Web wirklich selbst

Jon bekommt einen echten Chromium-Browser als Werkzeug — keine Selektor-Bastelei pro
Website, sondern ein Agent, der jede Seite über ihre sichtbaren Elemente versteht.

- **Ein Auftrag genügt.** `browser_task` bekommt einen Satz („Such mir das Buch und leg
  es in den Warenkorb"), plant, öffnet Seiten, liest sie, klickt, füllt Formulare aus,
  passt sich an, wenn sich die Seite ändert, und berichtet am Ende auf Deutsch.
- **Website-unabhängig.** Elemente kommen aus Rollen, ARIA-Labels, Beschriftungen und
  sichtbarem Text und bekommen stabile IDs (e1, e17). Keine fest verdrahteten
  CSS-Pfade für einzelne Shops.
- **Planmodus.** Mehrstufige oder riskante Aufträge werden erst geplant, dann ausgeführt
  — und ein Plan ist ausdrücklich keine Erlaubnis. Einstellbar: Auto, Immer, Aus.
- **RiskActionGuard.** Kaufen, bestellen, buchen, absenden, löschen wird programmatisch
  gestoppt, nicht nur vom Sprachmodell. Jon zeigt Anbieter, Auslöser und die gefundenen
  Beträge und fragt nach. Die Freigabe gilt genau einmal und verfällt, sobald sich Preis,
  Anbieter oder Menge ändern.
- **Probelauf (Dry Run).** Jon plant und schaut nur nach, verändert nichts.
- **Passwörter bleiben im Browser.** Passwort- und Zahlungsfelder füllt Jon nie aus,
  CAPTCHAs und 2FA umgeht er nicht — da übernimmt der Nutzer.
- **Seiteninhalt ist nur Text.** Versucht eine Website, Jon Anweisungen zu geben
  („Ignoriere alle bisherigen Anweisungen"), erkennt er das, meldet es und arbeitet
  normal weiter.
- **Eigenes Browserprofil** unter `data/browser/profil`: Logins bleiben erhalten, das
  Sprachmodell sieht Cookies und Tokens trotzdem nie.
- **Neue Karte im Chat** mit Plan, aktuellem Schritt, Protokoll und den Knöpfen
  „Bestätigen" / „Abbrechen", plus neue Einstellungen unter „Browser-Agent".
- **Neue Werkzeuge:** `browser_task`, `browser_search`, `browser_press`, `browser_scroll`,
  `browser_select`, `browser_forward`, `browser_reload`, `browser_tab_new`,
  `browser_tab_switch`, `browser_tab_close`, `browser_wait`, `browser_status`,
  `browser_confirm` — dazu die bekannten `browser_goto`, `browser_read`, `browser_click`,
  `browser_fill`, `browser_screenshot`, `browser_back`, `browser_close`.

## [4.37.0] — 2026-09-01

### 📱 Android Connector: Das Handy wird ein Gerät in Jon

Aus der gekoppelten Handy-App wird ein vollwertiges Gerät, das Jon abfragen darf — immer
nur so weit, wie du es freigibst.

- **Neue Kategorie „Geräte"** unter Einstellungen → 🔌 Verbindungen: Karte je Handy mit
  Online-Punkt, Akku, Verbindungsart, letztem Kontakt, Umbenennen, Trennen und einem
  Schalter für jede Berechtigung.
- **Drei Stufen.** Standard (Status, Dateien) ist an, Persönlich (Benachrichtigungen,
  Zwischenablage, Standort, Kontakte) und Sensibel (Kamera, Mikrofon) sind aus. Sensible
  Funktionen fragen zusätzlich am Handy nach.
- **Neue Werkzeuge** für die KI: `android_device_status`, `android_battery_status`,
  `android_notifications_list`, `android_files_list`, `android_files_send`,
  `android_files_receive`, `android_clipboard_send`, `android_location_get`,
  `android_contacts_search`, `android_camera_request_photo`. Jon sieht ein Werkzeug nur,
  wenn ein Gerät die passende Freigabe hat.
- **„Jon, schick die PDF auf mein Handy."** Dateien gehen jetzt in beide Richtungen, in
  32-KB-Teilen über denselben verschlüsselten Kanal wie der Chat.
- **Connector-System.** Neuer `ConnectorManager` mit dem `AndroidConnector` als erstem
  Teilnehmer; weitere Connectoren melden ihre Werkzeuge künftig genauso dynamisch an.
- **Companion-App (1.1.0).** Neuer Bildschirm „Verbinder": zeigt für jede Funktion, was
  der PC freigegeben hat und was Android erlaubt, fordert fehlende Berechtigungen an und
  kann jede Funktion sofort sperren. Ein Vordergrunddienst hält die Verbindung und zeigt
  sichtbar an, dass das Handy mit Jon verbunden ist.
- **Kamera nur sichtbar.** Eine Fotoanfrage erscheint als Hinweis mit Begründung; die
  Kamera öffnet sich erst nach dem Tippen. Fürs Mikrofon gibt es bewusst kein Fernwerkzeug.
- Grenzen von Android (Zwischenablage lesen, fremde Downloads, Start nach dem Neustart)
  stehen jetzt in [docs/ANDROID.md](docs/ANDROID.md).

## [4.36.4] — 2026-08-30

### 🖥️ Start über start-jon.bat bleibt nicht mehr hängen

Beim Doppelklick öffnete sich nur ein Fenster und dann passierte nichts mehr. Dahinter
steckten zwei getrennte Fehler.

- **Der Start blieb wirklich stehen.** Blieb vom letzten Mal ein Backend-Prozess übrig,
  hielt der die Datei `backend.log` offen. Der neue Start schrieb sein Log über
  `Tee-Object` in genau diese Datei — das schlug fehl, und damit starb der Backend-Start
  sofort, noch bevor Python lief. Das Fenster wartete dann endlos auf ein Backend, das
  nie kam.
  - Die bat räumt jetzt vor dem Start auch Backend-Prozesse ab, die keinen Port mehr
    halten (erkannt an ihrer Befehlszeile), nicht nur die, die auf 8756 lauschen.
  - Und selbst wenn das Log noch gesperrt ist, startet Jon trotzdem: Er weicht dann auf
    eine Log-Datei im Temp-Ordner aus, statt abzubrechen.
- **Im Fenster stand nichts mehr.** Vite löscht beim Start standardmäßig den Bildschirm
  und schob damit alle Meldungen der bat aus dem Bild — das Fenster wirkte tot.
  `clearScreen: false` schaltet das ab, jetzt bleibt alles stehen.
- Die Zeile mit den Spielen war seit dem Zugangsschutz in 4.36.0 verschwunden: Die
  Abfrage lief ohne Geräte-Schlüssel und wurde abgewiesen. Sie schickt den Schlüssel
  jetzt mit.
- Neu im Fenster: ein Hinweis, dass es offen bleiben muss, und wo das Backend-Log liegt.

## [4.36.3] — 2026-08-30

### 💬 Jon schreibt wieder wie ein Mensch, nicht wie ein Datenblatt

Bei Vergleichen baute Jon gern Markdown-Tabellen. Da der Chat den Text aber roh anzeigt,
standen dort nackte Striche und Trennzeilen wie `|---|---|` — das sah nach Rohdaten aus
statt nach einer Antwort.

- Jon weiß jetzt: keine Tabellen. Vergleiche kommen als kurze Absätze mit
  Zwischenüberschrift und Aufzählung. Listen, Absätze und Überschriften bleiben
  ausdrücklich erwünscht — nur die Striche sind weg.
- Als Netz darunter: Rutscht einem Modell doch eine Tabelle durch, wandelt Jon sie beim
  Anzeigen in eine Aufzählung um — im Chat und in Telegram. Code-Blöcke bleiben dabei
  unangetastet, ein `cat datei | grep x` wird also nicht zerlegt.

## [4.36.2] — 2026-08-30

### 🖼️ Bilder und Videos direkt im Chat

Jon kann jetzt selbst malen, ohne dass du das Fenster „Video / Foto" öffnest. Sag ihm
einfach „mal mir ein Bild von …" — er formuliert den Prompt aus, erzeugt das Bild und
zeigt es direkt in der Unterhaltung.

- Ohne eigenen API-Schlüssel läuft das kostenlos über Pollinations. Sobald du in
  „Video / Foto" einen Schlüssel einträgst, nimmt Jon deinen Anbieter — der Schlüssel
  bleibt gespeichert und gilt auch für den Chat.
- Unter jedem Bild sitzen drei Knöpfe: **Herunterladen** legt es in deinen
  Downloads-Ordner (mit sprechendem Dateinamen), **Groß ansehen** öffnet es, und
  **Im Studio öffnen** springt ins Bild-Fenster.
- Der Telegram-Bot schickt dir das fertige Bild als echtes Foto — auch aus Gruppen. Bei
  Videos kommt ein Video, notfalls die Datei.
- Auch im Bild-Fenster selbst gibt es jetzt einen Herunterladen-Knopf.

### 🔎 Eine Websuche, die diesen Namen verdient

„Wie teuer ist das neue iPhone?" beantwortete Jon aus dem Gedächtnis — mit einem Modell
von vor Jahren. Und suchte er doch, kamen Werbeanzeigen statt Treffern zurück, mit
kaputten Sonderzeichen. Beides ist behoben.

- **Jon weiß, welcher Tag heute ist.** Im Systemprompt steht das echte Datum, dazu die
  Regel: Bei Preisen, Produkten, Versionen, Personen, News und Terminen wird gesucht,
  nicht geraten. Und: Was die Suche findet, gilt — er darf nicht mehr behaupten, ein
  Produkt gäbe es nicht, nur weil er es nicht kennt.
- **Neuer Suchdienst** mit drei Quellen hintereinander: DuckDuckGo Lite, DuckDuckGo HTML
  und Wikipedia. Fällt eine aus, übernimmt die nächste.
- **Werbung fliegt raus.** Bisher waren die ersten zwei von sechs Treffern gekaufte
  Anzeigen. Auch Umlaute und das Euro-Zeichen kommen jetzt sauber an, und die
  Beschreibung gehört wieder zum richtigen Treffer (vorher konnten sie verrutschen).
- **Jon liest die Seiten wirklich**: Mit `read` holt er den Text der besten Treffer und
  kann echte Zahlen nennen, statt nur Suchergebnis-Schnipsel zu wiederholen.
- Jede Antwort der Suche trägt ihren Stand mit Datum und Uhrzeit, damit Jon sagen kann,
  wie aktuell die Information ist.

## [4.36.1] — 2026-08-29

### 🩹 Die App bekam den Geräte-Schlüssel gar nicht

In 4.36.0 blieb Jon nach dem Start auf „nicht verbunden" stehen. Ursache waren zwei
Lücken in der Kette, über die der Schlüssel vom Backend zur Oberfläche kommt:

- **`preload.cjs` reichte den Schlüssel nie durch.** Die Zeile `token: jonToken` fehlte,
  `window.jon.token` war deshalb immer `undefined`. Jede Anfrage an `/api/` kam ohne
  Schlüssel an und wurde mit 401 abgewiesen. Die App zeigte das nicht als Fehler, sondern
  versuchte es stumm alle zwei Sekunden erneut.
- **Der Electron-Hauptprozess rief die API ohne Schlüssel.** `/api/settings`,
  `/api/system/idle` und die Quickwrite-Endpunkte gingen an der Absicherung vorbei; nur
  der Shutdown-Aufruf hatte einen Schlüssel. Alle laufen jetzt über `apiFetch()`.

### 🔁 Ein falscher Schlüssel sperrt nicht mehr dauerhaft aus

Der eigentliche Konstruktionsfehler war, dass Electron **raten** musste, welche Datei das
Backend benutzt, und sich das Ergebnis für die ganze Laufzeit merkte. Ein falscher Tipp
bedeutete: dauerhaft ausgesperrt, ohne Meldung, ohne Ausweg.

- `/api/health` nennt jetzt den Pfad seiner Schlüsseldatei (nur den Pfad, nicht den
  Schlüssel). Electron fragt beim Start dort nach, statt zu raten.
- Das Backend schreibt seinen wirksamen Schlüssel immer in genau diese Datei — auch wenn
  er aus `JON_TOKEN` kommt. Datei und Wirklichkeit können nicht mehr auseinanderlaufen.
- Kommt trotzdem einmal ein 401, holt sich die Oberfläche über den Hauptprozess einen
  frischen Schlüssel und wiederholt die Anfrage. Das gilt für die App, Mini Jon und die
  Schnellfrage.

### 🩺 Abgewiesene Anfragen sind jetzt sichtbar

Genau dieser Fehler war von außen unsichtbar — deshalb protokolliert Jon Abweisungen jetzt
(höchstens eine Meldung alle 30 Sekunden) und zeigt ihre Anzahl in der Diagnose. Eine
Zahl, die steigt, während die App „nicht verbunden" anzeigt, benennt das Problem sofort.

### 🧪 Tests, die genau diese Kette absichern

Zehn neue Tests prüfen die Übergabe über alle Sprachgrenzen hinweg: dass `/api/health` den
Pfad meldet und die Datei den wirksamen Schlüssel enthält, dass jedes Preload den Schlüssel
weiterreicht und nachfragen kann, dass jedes Fenster ihn mitbekommt, dass Oberfläche und
kleine Fenster nach einer Abweisung wiederholen — und dass **kein** Aufruf im
Hauptprozess an der Absicherung vorbeigeht. Insgesamt 425 Tests.

## [4.36.0] — 2026-08-29

### 🔒 Zugangsschutz: Jon fragt jetzt nach einem Geräte-Schlüssel

Bis 4.35.1 war jede der 283 Programmschnittstellen ungeschützt — auch
`POST /api/system/powershell`, `/system/files/write` und `/system/files/delete`. Mit
`JON_LAN=1` (der dokumentierte Weg, das Handy als PC-App zu nutzen) konnte damit **jedes
Gerät im selben WLAN** beliebige Befehle auf dem PC ausführen. Und weil `CORS_ORIGINS`
auf `*` stand, konnte auch **jede beliebige Webseite** im Browser Befehle an
`127.0.0.1:8756` schicken — ohne LAN-Modus, ohne Zutun.

- Jon erzeugt beim ersten Start einen Geräte-Schlüssel und legt ihn in
  `data/access.token` ab. Ohne diesen Schlüssel antwortet jede `/api/`-Anfrage mit 401.
- Der Schlüssel wird als `X-Jon-Token`-Kopfzeile, als `?token=`-Anhang oder als Cookie
  akzeptiert — damit funktionieren auch Downloads, Bilder und Live-Streams.
- Die App bekommt ihn beim Start direkt vom Programm, ohne dass du etwas eintippen musst.
  Mini Jon, die Schnellfrage, der private Browser und die Blockwelt ebenso.
- `CORS_ORIGINS` steht nicht mehr auf `*`, sondern erlaubt genau die Adressen, unter denen
  Jons eigene Oberfläche läuft.
- Die Spiele-Schnittstelle (`/api/mp/`) und `/api/health` bleiben offen — sonst könnten
  Mitspieler nicht mehr beitreten.

### 📱 Handy koppeln über Einstellungen → Diagnose

Weil der Schlüssel nun nötig ist, gibt es einen Weg, ihn ans Handy zu bringen: Die neue
Ansicht zeigt die vollständige Adresse inklusive Schlüssel zum Kopieren. Das Handy merkt
sich den Schlüssel und entfernt ihn aus der Adresszeile. Mit **Neues Token** lässt sich
alles Gekoppelte auf einen Schlag abmelden.

Dabei fiel auf, dass `http://<PC-IP>:8756/app` in der **installierten Version noch nie**
funktioniert hat: Die Web-Oberfläche lag nur im Quellcode-Ordner, im Windows-Paket fehlte
sie — der Aufruf lief seit jeher in ein 404. Sie wird jetzt mit ins Backend-Paket gelegt
und dort gefunden, wo sie liegt (Quellcode oder Bundle). Findet Jon sie nicht, sagt die
Diagnose das, statt eine tote Adresse anzubieten.

### 🩺 Diagnose: sichtbar machen, was still kaputtging

Jon startet 24 Hintergrunddienste. Bisher verschwand jeder Fehler darin in einem
`except: continue` — Telegram, Kalender oder der Dateiwächter konnten wochenlang tot sein,
ohne dass es jemand merkte.

- Alle Hintergrunddienste laufen jetzt über eine gemeinsame Registrierung. Stirbt einer,
  wird das protokolliert statt verschluckt.
- Neue Ansicht unter Einstellungen → **Diagnose & Handy koppeln**: Version, Laufzeit,
  Adresse, Datenverzeichnis, der Zustand jedes einzelnen Dienstes und die letzten
  Meldungen.
- **Protokoll speichern** legt eine Textdatei mit Dienstzuständen und Protokoll an — das,
  was man einem Fehlerbericht beilegt.
- Das Protokoll landet rollierend in `data/jon.log` (max. 4 × 2 MB) statt in `print`.

### 💾 Daten überleben jetzt einen Absturz

36 Dateien hielten Jons Zustand — Freunde, Aufgaben, Erinnerungen, Konten, Tresor. Alle
53 Schreibvorgänge schrieben direkt in die Zieldatei: Ein Absturz oder Stromausfall
mittendrin hinterließ eine halbe Datei, und der Inhalt war beim nächsten Start weg.

- Geschrieben wird jetzt erst in eine Nebendatei, dann per `os.replace` umgeklappt. Der
  alte Stand bleibt vollständig, bis der neue vollständig auf der Platte liegt.
- Windows verweigert das Umklappen, solange jemand die Datei liest — deshalb wird es bis
  zu 25-mal wiederholt statt aufzugeben.
- `read_json` gibt bei einer kaputten Datei den Standardwert zurück, statt den Dienst
  abstürzen zu lassen.

### 💬 Lange Gespräche brechen nicht mehr ab

Bisher ging bei jeder Nachricht der **komplette** Verlauf ans Modell. Lange Gespräche
wurden immer langsamer und teurer, bis der Anbieter mit einem Kontext-Fehler abbrach.

- Der Verlauf wird auf ein Zeichenbudget gekürzt (`CONTEXT_BUDGET_TOKENS`, Standard
  24000). Die Systemanweisung und die neuesten Nachrichten bleiben immer erhalten.
- Was wegfällt, kommt als kurze Zusammenfassung mit — Jon vergisst den Anfang also nicht
  vollständig.
- Eine einzelne riesige Nachricht (etwa eine eingefügte Datei) wird in der Mitte gekürzt,
  statt allein das ganze Budget zu sprengen.

### 🧾 Updates werden auf Echtheit geprüft

Der Update-Download prüfte bisher nur Größe und `MZ`-Kopf.

- Jedes Release bekommt eine `SHA256SUMS.txt`; der Download wird dagegen geprüft und bei
  Abweichung verworfen.
- `scripts/build_installer.py` erzeugt die Prüfsummendatei automatisch mit.

### 🧪 Tests und reproduzierbare Builds

- 35 neue Tests: Zugangsschutz, atomares Schreiben unter parallelem Zugriff,
  Verlaufskürzung, Freigabe-Dialog und Tresor — vier davon waren bisher **komplett
  ungetestet**, obwohl sie über Datenverlust entscheiden.
- Insgesamt **415 Tests**, alle grün.
- `backend/requirements.lock` nagelt alle 31 Abhängigkeiten auf die Version fest, mit der
  gebaut wurde. Der Installer benutzt die Lockdatei, wenn sie da ist.

## [4.35.1] — 2026-08-29

### 🩹 Versionszeile in der Seitenleiste sitzt wieder mittig

Ganz unten links klebte „Jon Desktop v…" am unteren Rand statt mittig im Streifen zu
stehen. Schuld war die Polsterung: Die Regel für den Geräterand (`safe-bottom`) hat den
unteren Abstand auf 0 gesetzt und damit den oberen von 16 Pixeln allein gelassen.

- Der Streifen hat jetzt eine feste Höhe und zentriert seinen Inhalt selbst — oben und
  unten je 18 Pixel, waagrecht unverändert links.
- Auf dem Handy bleibt der Geräterand berücksichtigt, der Streifen wächst dort einfach mit.

## [4.35.0] — 2026-08-29

### 🎨 Video / Foto: Bilder und Videos in Jon erstellen

Unter 🧰 Werkzeuge steckt ein neues Fenster — oder du tippst `/bild`. Beim ersten Öffnen
suchst du dir aus, womit Jon malen soll: mit deinem eigenen API-Schlüssel, komplett
kostenlos ohne Anmeldung oder lokal auf deinem eigenen Rechner.

- Zur Auswahl stehen Pollinations (kostenlos, ohne Schlüssel), Together AI mit FLUX,
  OpenAI, Google Gemini und Imagen, Stability AI, Replicate, fal.ai und dein eigener
  Rechner. Über Replicate und fal.ai entstehen auch echte Videos.
- Der lokale Weg ist der gleiche Gedanke wie bei Ollama: Alles bleibt auf deinem PC.
  Ollama selbst erzeugt keine Bilder — dafür trägst du die Adresse deines Bilder-Servers
  ein (Stable Diffusion WebUI, SD.Next oder Forge auf Port 7860).
- Schreib, was zu sehen sein soll, wähl Größe und Modell, fertig. Alles landet in einer
  Galerie und bleibt als Datei lokal auf deinem Rechner.
- Der Schlüssel wird nur bei dir gespeichert und geht ausschließlich an den Anbieter,
  den du ausgesucht hast.

### 🟢 NVIDIA-Modelle im Video-/Foto-Fenster

Jon kennt deinen NVIDIA-Schlüssel schon — im Bild-Fenster steht NVIDIA deshalb sofort
bereit, ohne dass du irgendetwas eintippst.

- FLUX läuft direkt bei NVIDIA: `flux.2-klein-4b` (Standard, in Sekunden fertig),
  `flux.1-schnell`, `flux.1-dev` und `flux.1-kontext-dev`.
- Das Modellfeld ist frei beschreibbar. Jedes Bildmodell, das NVIDIA unter
  build.nvidia.com anbietet, funktioniert damit — auch neue, die erst später dazukommen.
- Bildgröße und Seitenverhältnis rechnet Jon automatisch auf das um, was NVIDIA
  akzeptiert, statt mit einer Fehlermeldung abzubrechen.
- Bedient NVIDIA ein Modell gerade nicht, sagt Jon das in einem klaren Satz und
  schlägt ein Modell vor, das läuft.

### 🖌️ Bilder bearbeiten statt nur neu erzeugen

Bei Anbietern, die das können, gibt es im Bild-Fenster jetzt eine Vorlage: ein Bild vom
PC oder direkt aus deiner Galerie, dazu ein Satz, was sich ändern soll.

- Unterstützt bei NVIDIA, OpenAI, Google Gemini, Replicate, fal.ai und deinem lokalen
  Bilder-Server. Anbieter, die nur neu malen können, sagen das offen.
- NVIDIA nimmt für seine Bearbeitungs-Modelle derzeit keine eigenen Bilder an
  (Antwort 500 von deren Schnittstelle) — Jon erklärt das im Fenster, statt still zu
  scheitern. Text zu Bild läuft dort normal.

### 🧠 Jon Code ist jetzt wirklich Experte

Das Wissen, mit dem Jon Code arbeitet, war bisher knapp beschrieben. Jetzt steht dort,
was er tatsächlich beherrschen soll — und wie er dabei vorgeht.

- Ausdrücklich benannt sind Sprachen von Python, TypeScript, Rust und Go bis C++, Kotlin,
  Swift und SQL, dazu Frontend-Frameworks, Backends, Datenbanken, Nebenläufigkeit,
  Betriebssystem-Unterschiede, Git, Build-Systeme, Tests, Profiling und Sicherheit.
- Neuer Experten-Maßstab: Randfälle mitdenken (leere Eingaben, Zeitzonen, Kodierungen,
  gleichzeitige Zugriffe), Fehler nie stumm schlucken, Ressourcen schließen, keine
  Zugangsdaten im Code, SQL nur parametrisiert, Ursache statt Symptom beheben.
- Er darf keine Funktionen oder Bibliotheken mehr erfinden: Kennt er eine Schnittstelle
  nicht sicher, liest er sie im Projekt nach.
- Nach der Änderung prüft er selbst nach — Datei erneut lesen, Test oder Build laufen
  lassen — und meldet erst danach fertig. Und er behauptet nicht mehr, etwas sei
  getestet, wenn er es nicht wirklich ausgeführt hat.

### ⌨️ Alle Befehle mit einem Druck auf „/"

Ein `/` im Chatfeld zeigt jetzt alle Befehle mit Erklärung und Zweitnamen. Tippst du
weiter, bleibt nur übrig, was passt: `/n` zeigt `/notizen`, `/navigation` und `/nutzung`.

- Mit ↑ und ↓ wählen, Enter oder Tab führt aus. Braucht ein Befehl noch Text, setzt Jon
  ihn ins Feld und wartet. Esc blendet die Liste aus.

### 🗺️ Jon Maps auf Zuruf — und mit der genauen Adresse

Fragte man aus Jon Maps heraus „Jon fragen" zu einem Haus, stand im Chat nur die
Hausnummer — Jon wusste nicht, wo das ist, und zählte allgemein auf, was man um 21 Uhr so
machen kann.

- Die Frage aus Jon Maps enthält jetzt den vollständigen Ort: Straße, Hausnummer,
  Postleitzahl, Ort, Bundesland, Land und die genauen Koordinaten. Fehlt der Straßenname,
  schreibt Jon „Felixdorf Hausnummer 21".
- `/maps <Frage>` erzwingt die Karte: Jon überlegt nicht mehr, ob eine Karte passt,
  sondern sucht wirklich in der Umgebung dieses Ortes und fragt nicht nach der Stadt.
  `/lerne <Thema>` startet genauso direkt eine Tiefenrecherche.
- `/maps` allein öffnet weiterhin einfach die Karte.
- Auch die Ortskarte selbst zeigt jetzt die volle Adresse statt nur „21".

## [4.34.8] — 2026-08-28

### 🔧 Werkzeuge und Einstellungen gehen wieder auf

Die Handy-Anpassung aus 4.34.7 hatte die Kopfzeile seitlich scrollbar gemacht. Ein
scrollender Kasten schneidet aber alles ab, was aus ihm herausragt — und damit auch die
Klappmenüs hinter 🧰 Werkzeuge, ⚙️ Einstellungen und der Modellauswahl. Sie öffneten
sich zwar, blieben aber unsichtbar in einer 28 Pixel hohen Zeile stecken.

- Die Kopfzeile schneidet nichts mehr ab: Statt zu scrollen, schrumpfen Anbieter- und
  Modellauswahl auf schmalen Bildschirmen mit und kürzen ihren Text.
- Geprüft bei 375 und 894 Pixel Breite: Werkzeugmenü, Einstellungen und die Panels
  dahinter (z. B. Kalender) öffnen wieder und passen vollständig auf den Bildschirm.

### 🔌 Verbindungen öffnen wieder

„Einstellungen → 🔌 Verbindungen …" tat manchmal einfach nichts. Der Knopf holte erst die
Einstellungen vom Backend und öffnete das Fenster danach — war das Backend gerade nicht
erreichbar, brach der Aufruf still ab und es passierte gar nichts.

- Das Fenster geht jetzt sofort auf, das Menü schließt sich sofort mit.
- Ist das Backend nicht erreichbar, öffnet es mit den Standardwerten, statt zu
  verschwinden. Das gilt für alle Stellen, die die Einstellungen laden.

### 🖥️ Start über start-jon.bat lässt kein Backend zurück

Startete man Jon über `start-jon.bat` und die App verabschiedete sich, lief das Backend
allein weiter — der nächste Start traf dann auf einen belegten Port. Und war Port 5173
noch von einem alten Entwicklungsserver besetzt, beendete sich die App sofort wieder,
weil Vite den Port fest braucht.

- Die bat räumt jetzt vor dem Start auch Port 5173 ab, aber nur, wenn dort wirklich ein
  `node` oder `electron` liegt.
- Endet die App — ob normal oder durch einen Absturz —, stoppt die bat das Backend
  hinterher: erst über den Shutdown-Endpunkt, dann gezielt über den Port, und nur eigene
  Python-Prozesse.
- Beendet sich die App mit einem Fehler, sagt die bat das mit Code und Pfad zum
  Backend-Log, statt einfach zu verschwinden.
- Die App selbst versucht im Entwicklungsmodus erneut zu laden, wenn der Vite-Server
  beim ersten Versuch noch nicht steht, und lädt sich nach einem Absturz der Oberfläche
  selbst neu.

## [4.34.7] — 2026-08-28

### 📱 Jon am Handy — die volle Oberfläche über den Raspberry Pi

Läuft Jon auf dem Pi, rufst du ihn im WLAN unter `http://<pi>:8756/app` auf. Diese
Oberfläche war bisher für Maus und großen Bildschirm gebaut. Jetzt lässt sie sich mit dem
Daumen bedienen.

- **Unterhaltungen als Schublade:** Auf schmalen Bildschirmen liegt die Seitenleiste
  aus dem Weg und fährt über ☰ herein, mit abdunkelndem Hintergrund. Ein Tipp auf eine
  Unterhaltung schließt sie wieder. Am PC ist alles unverändert.
- **Kopfzeile passt sich an:** Modellauswahl und Werkzeugleiste schrumpfen, scrollen
  seitlich und verlieren auf dem Handy nur ihre Beschriftungen — nichts wird mehr
  abgeschnitten, nichts schiebt die Seite in die Breite.
- **Kein Zoom-Gehüpfe mehr:** Eingabefelder haben auf Touchgeräten 16px, damit Safari
  und Chrome beim Antippen nicht mehr hineinzoomen. Knöpfe und Eingabezeile sind auf
  44 Pixel Höhe gewachsen.
- **Volle Höhe, echte Ränder:** Die App rechnet mit der dynamischen Fensterhöhe
  (`100dvh`) und respektiert die sichere Fläche unten, sodass die Eingabezeile nicht mehr
  hinter der Browserleiste oder dem Homebalken verschwindet.
- **Nachrichten und Karten** nutzen auf dem Handy fast die ganze Breite.
- **Zum Startbildschirm hinzufügen** funktioniert sauber: eigene Farbe für die
  Statusleiste, Vollbild-Modus und Titel.
- **Backend-Adresse:** Wird Jon über einen anderen Namen oder Port erreicht (Reverse
  Proxy, Tailscale, Port 80), spricht die Oberfläche jetzt denselben Ursprung an, statt
  stur `127.0.0.1:8756` zu versuchen.

## [4.34.6] — 2026-08-28

### 🗺️ Jon Maps versteht die Filter

Jon bedient die Kartenfilter jetzt selbst. „Starte eine Route von meinem Standort zum
nächsten Supermarkt" genügt — er sucht den nächstgelegenen Treffer, plant die Route und
zeigt die anderen Läden gleich daneben.

- Ziel und Zwischenstopps einer Route dürfen ein Filter (`supermarkt`, `apotheke`,
  `tankstelle` …) oder ein Laden- und Markenname sein: „zum Interspar in meiner Nähe".
- „nächster", „in meiner Nähe", „um mich herum" werden verstanden und aus der Suche
  herausgerechnet, statt als Ortsname im Geocoder zu landen.
- Neue Filter: **Bäckereien**, **Drogerien** und **Post & Paket** — zusammen 22 Stück.
  Marken wie Interspar, Billa, Hofer, dm, Shell oder McDonald's kennt Jon direkt und
  sucht sie in der passenden Kategorie.
- Findet er in 2,5 km nichts, weitet er auf 10 und 25 km aus, statt aufzugeben.
- In der Kartenkarte im Chat stehen die Alternativen als Chips: ein Klick rechnet die
  Route sofort dorthin um — Karte, Dauer, Entfernung und Text ziehen mit. „Groß öffnen"
  übernimmt die neue Route und schaltet den passenden Filter in Jon Maps scharf.
- Overpass läuft über drei Server: fällt einer aus, übernimmt der nächste.

### ✈️ Jon und Mini Jon unterwegs

Was Jon am PC kann, kann er jetzt auch über Telegram — und Mini Jon zum ersten Mal
überhaupt: Er hatte dort bisher gar keine Werkzeuge.

- Standort teilen (📎 → Standort), und „hier" ist wirklich dort, wo du bist. Live-Standorte
  werden dabei schonend übernommen, nicht bei jedem Zucken.
- Zu jeder Karte kommt ein **Kartenpin** zum Antippen, zu jeder Route zusätzlich ein
  Routenlink fürs Handy.
- **/lernen &lt;Thema&gt;** startet eine echte Tiefenrecherche am PC, **/lernstatus**,
  **/lernstop** und **/lernweiter** steuern sie. Sobald sie fertig ist, meldet sich Jon
  von selbst mit Zusammenfassung, Quellen und Dateien — auch wenn du die Recherche
  einfach im Gespräch angestoßen hast.
- In Gruppen antworten beide weiterhin nur auf @Erwähnung, dort aber mit einem bewusst
  kleinen Werkzeugkasten: Karten, Routen, Websuche, Wetter und Deep Learning. Kein
  Zugriff auf PC, Mails, Zwischenablage oder Freunde-Chats — den vollen Satz hat nur der
  Chat, der mit deinem PC verbunden ist.

### 🗑️ Jon deinstallieren

Im Zahnrad-Menü ganz unten: **Jon deinstallieren**. Der Dialog zeigt zuerst genau, was
verschwinden würde — Ordner, Dateizahl und Größe — bevor irgendetwas passiert.

- Gelöscht werden Jons Datenordner (Unterhaltungen, Gedächtnis, Einstellungen,
  Wissensbasis, Tresor, Kalender, Freunde, Schlüssel) und die `.env` mit den API-Schlüsseln.
- Der Autostart-Eintrag wird entfernt.
- Auf Wunsch startet danach der Windows-Deinstallierer und entfernt das Programm.
- Läuft Jon aus dem Quellordner, bleibt dieser stehen — der Dialog sagt das ausdrücklich.
- Der Knopf bleibt gesperrt, bis `JON LOESCHEN` eingetippt wurde. Systempfade wie das
  Benutzerverzeichnis werden grundsätzlich abgelehnt, auch wenn sie eingetragen würden.

## [4.34.5] — 2026-08-23

### 📍 Freunde auf der Karte

Jon Maps zeigt jetzt, wo deine Freunde sind — über Jons vorhandene, verschlüsselte
Freundesverbindung, ohne fremden Server.

- **Standort teilen ist standardmäßig aus.** Unter ▦ Ebenen → „Freunde auf der Karte"
  schaltest du ihn ein, entweder für alle Freunde oder für einzelne. Dort steht auch, wer
  dich gerade sehen kann, und ein Schalter nimmt es sofort wieder zurück.
- Freunde erscheinen als Marker mit ihrem Avatar. Frische Standorte leuchten blau, ältere
  werden blass und grau, damit du nie einen alten Punkt für den aktuellen hältst. Nach
  30 Minuten ohne Nachricht verschwinden sie ganz.
- Ein Klick auf einen Freund öffnet seine Karte: Entfernung, Alter der Meldung,
  Genauigkeit, dazu Route hin, Umsehen und Nachricht schreiben.
- Blockierst oder entfernst du jemanden, wird sein Standort sofort mitgelöscht.

### 🎯 Standort auf 100 statt 150 Meter

Jon fragt den Windows-Standortdienst jetzt mit hoher Genauigkeit an, nimmt mehrere
Messungen und behält die beste. Auf Geräten mit GPS greift damit auch das GPS. Auf einem
Desktop ohne GPS bleibt die WLAN-Ortung die physikalische Grenze — für metergenau setzt
du deinen Standort weiter mit einem Klick auf die Kartenmitte.

### 🕯️ ECHO: die Verstorbenen haben ein Modell

Bisher war der Verstorbene, den man in die Leichenhalle bringt, ein unsichtbarer Punkt auf
der Trage. Jetzt liegt dort wirklich jemand: eine Gestalt unter einem Leinentuch, mit
Kopf, Haar, dem Tuch über Brust, Armen und Beinen und einem Zettel am Fuß. Er erscheint,
wenn der Auftrag beginnt, und verschwindet, sobald du die Trage schiebst.

### 👀 Multiplayer: Freunde schauen wieder dorthin, wo sie hinsehen

In ECHO und AETHERIA drehte sich der Kopf entfernter Spieler immer zu **dir** statt in
ihre eigene Blickrichtung — die Blickneigung wurde zwar übertragen, aber nie benutzt.
Jetzt zeigt der Kopf genau dorthin, wo der Freund wirklich hinschaut, auch nach oben und
unten. (In der Blockwelt war es bereits richtig.)

### 🏝️ Harmonische Inseln: ein Ziel, das weitergeht

- **Der Spielstand wurde nie gespeichert.** Gespeichert wurden nur Fortschritt, Ort und
  Saat — Leuchtturmstufe und Herzen las das Spiel beim Start zwar, geschrieben hat sie
  aber niemand. Nach jedem Beenden fing man von vorne an. Das war der eigentliche Grund,
  warum sich das Spiel ziellos anfühlte. Jetzt bleibt alles erhalten.
- **Nach dem Leuchtturm ist nicht Schluss.** Bisher hörte das Sammeln auf, sobald das
  Licht brannte. Jetzt hält dieses Licht den Nebel zurück: Was du weiter zum Turm
  bringst, drängt ihn Stück für Stück ab — und mit jedem Stück zieht **ein neuer Bewohner
  zu**, manchmal mit Haustier. Die Anzeige zeigt, wie viele Bewohner schon da sind und
  wie weit es bis zum nächsten Zuzug ist. Jeder Zuzug braucht etwas mehr als der letzte.

### 🙂 Mini Jon und seine Tiere bekommen Wangen

Die 3D-Modelle von Mini Jon, Katze und Hund haben jetzt weiche rosa Wangen, wenn du
„Wangen" einschaltest — vorher gab es die nur in der flachen 2D-Ansicht. Der Schalter
wirkt sofort in der Vorschau und auf dem Desktop.

## [4.34.4] — 2026-08-23

### 🗺️ Jon Maps — eine eigene Karten- und Navigationsplattform

Jon hat jetzt seine eigene Karte. Kein eingebettetes fremdes Kartenfenster, sondern eine
Oberfläche, die zu Jon gehört: Liquid Glass über einer Karte, die den ganzen Bildschirm
einnimmt. Zu öffnen über 🧰 Werkzeuge → Jon Maps oder mit `/maps`.

- **Liquid Glass in Hell und Dunkel.** Die Panels sind echtes Glas: 30–46 px
  Hintergrundunschärfe, ein Lichtreflex, der beim Überfahren wandert, ein Rahmen aus
  Farbverlauf statt einer Linie, feine innere Kanten, sehr weiche Schatten und eine
  Rauschtextur, damit es Material bleibt und nicht Milchglas wird. Die Karte bewegt sich
  sichtbar hinter den Flächen. Umschalten jederzeit oben rechts, der Modus wird gemerkt.
- **Die Karte selbst.** Zoomen, schieben, drehen, neigen, 2D/3D-Schalter, 3D-Gebäude mit
  echten Höhen aus OpenStreetMap, echtes 3D-Gelände aus Höhendaten, Satellitenbilder,
  Fahrradnetz, ÖPNV-Netz und Fußwege als eigene Ebenen.
- **Globus.** Weit genug herausgezoomt wird die Karte zur Kugel und beim Hineinzoomen
  wieder flach — fließend, ohne Bruch. Auch von Hand schaltbar.
- **Suche** nach Städten, Adressen, Straßen, Restaurants, Hotels, Bahnhöfen, Flughäfen,
  Tankstellen, Parks und Sehenswürdigkeiten, dazu Schnellfilter für die Umgebung.
- **Echte Routen** für 🚶 Fuß, 🚗 Auto, 🚲 Fahrrad und 🚌 Bus & Bahn — mit Dauer,
  Entfernung, Alternativrouten, Zwischenstopps und Abbiegeanweisungen.
- **Dein Standort, auf den Meter statt auf die Stadt.** Jon holt den echten
  Windows-Standortdienst (auf ~150 m genau, ohne Schlüssel, ohne Cloud) und merkt sich
  das Ergebnis dauerhaft — auch für Fragen im Chat wie „Was gibt es hier in der Nähe?".
  Vorher wurde nur die IP geschätzt, die je nach Anbieter im falschen Bundesland oder
  sogar im falschen Land landet. Klappt der Standortdienst nicht, setzt du deinen
  Standort unter ▦ Ebenen mit einem Klick auf die Kartenmitte.
- **Erde-Ansicht** 🌎 — ein Knopf schaltet Satellitenbild, echtes 3D-Gelände und
  3D-Gebäude zusammen ein und neigt die Kamera. Über Luftbildern bekommen die Gebäude
  helle Fassaden und neutrales Licht, damit sie plastisch wirken statt als schwarze
  Klötze.
- **Street Exploration.** Auf einen Punkt klicken und auf Straßenebene wechseln: echte
  Straßenfotos, umsehen per Ziehen, vor und zurück entlang der Straße mit W und S.
- **Jon World Explorer.** Die Welt frei erkunden als 🚶 Mensch auf Augenhöhe, 🚗 Auto auf
  Fahrzeughöhe oder ✈️ Flugzeug mit freier Flughöhe. Eine berechnete Route lässt sich
  abfahren.
- **Maps im Chat.** Fragen wie „Wie lange brauche ich zu Fuß zum Bahnhof?" oder „Finde mir
  ein Restaurant in der Nähe" beantwortet Jon mit dem neuen Tool `maps` — die interaktive
  Karte erscheint direkt im Chat, mit Dauer, Entfernung und Alternativen.

### 🧠 Jon Deep Learning — Jon arbeitet sich selbst in ein Thema ein

„Jon, lerne alles über Quantenmechanik. Du hast zwei Stunden." Ab jetzt macht er das
wirklich. Zu öffnen über 🧰 Werkzeuge → Deep Learning oder mit `/lerne`.

- **Eigenständige Recherche** in Stufen: Thema analysieren, Unterthemen bilden, Plan
  aufstellen, suchen, Quellen öffnen und lesen, Inhalte bewerten, Quellen vergleichen,
  Widersprüche erkennen und gegenprüfen, Wissen herausziehen, speichern, Skill bauen,
  Wissen indexieren.
- **Zeitbudget.** Jon teilt die Zeit selbst auf die Unterthemen auf und wechselt weiter,
  sobald eins fertig ist. Nennt man die Zeit im Satz („du hast zwei Stunden"), erkennt er
  sie.
- **Live im Chat**: Fortschrittsbalken, verbleibende Zeit, aktuelles Unterthema und ein
  laufendes Protokoll, das zeigt, welche Seite gerade geöffnet, gelesen, verglichen oder
  gespeichert wird.
- **Wissensordner.** Das Ergebnis landet als Markdown unter `skills/<thema>/` mit
  README.md, einer Datei je Unterthema, sources.md und skill.md. Skills dürfen jetzt
  Ordner sein, und Jon liest einzelne Wissensdateien mit dem neuen Tool
  `read_skill_file`.
- **Pause, Fortsetzen, Abbrechen** jederzeit. Der Fortschritt wird laufend gespeichert;
  nach einem Neustart lässt sich eine unterbrochene Recherche weiterführen.
- **Verlauf** aller Recherchen mit Dauer, Quellenzahl, Dateien und Skill.
- **Sicherer Webzugriff.** Der Recherche-Agent liest nur: kein Login, kein Kauf, keine
  Formulare, keine ausführbaren Dateien, keine Adressen im lokalen Netz.

### Dazu

- Alle Kartendienste sind **kostenlos und ohne Schlüssel**: OpenFreeMap, Nominatim,
  Overpass, OSRM, Valhalla, Transitous, KartaView, CyclOSM, ÖPNV-Karte und offene
  Höhen- und Satellitenkacheln. Jede Ebene ist in der `.env` austauschbar.
- Rad- und Fußwege laufen über Valhalla, weil der öffentliche OSRM-Demoserver nur das
  Autoprofil kennt und sonst stillschweigend die Autoroute zurückgegeben hätte.
- Karte und Deep-Learning-Ansicht werden erst geladen, wenn man sie öffnet — der Start
  von Jon bleibt dadurch gleich schnell.

## [4.34.3] — 2026-08-11

### ⬇️ Downloader: ganze Amazon-Music-Playlists

Bisher ging pro Amazon-Music-Link genau ein Song. Jetzt nimmt der Downloader auch
Playlist- und Album-Links und lädt alles auf einmal.

- Einen Playlist-, Album- oder geteilten Amazon-Music-Link einfügen — Jon liest die
  komplette Trackliste mit Titel, Künstler und Länge und zeigt sie vor dem Laden an.
- **Alle Songs als ZIP**: Jon sucht zu jedem Titel die passende Aufnahme, macht MP3s
  daraus (320 kbps, drei Songs gleichzeitig) und packt sie durchnummeriert in eine
  ZIP-Datei, benannt nach der Playlist.
- Der Fortschritt zeigt „x von y Songs" und den Titel, der gerade läuft.
- Songs, zu denen es keine Aufnahme gibt, überspringt Jon und listet sie am Ende auf,
  statt den ganzen Download abzubrechen.
- Amazon Music bleibt kopiergeschützt — Jon lädt nichts von Amazon, sondern benutzt die
  öffentliche Trackliste als Einkaufszettel und holt die Aufnahmen wie bisher von YouTube.
- Nebenbei behoben: Geteilte Links auf einen einzelnen Song (`…/albums/…?trackAsin=…`)
  landeten beim Album statt beim Song, und der Künstlername fehlte oft. Beides kommt
  jetzt sauber aus den Song-Daten.

## [4.34.2] — 2026-08-10

### ⬇️ Downloader: gekaufte YouTube-Filme

„This video requires payment to watch" kam auch dann, wenn man den Film längst gekauft
hatte — der Downloader war schlicht nicht eingeloggt und sah nur die Bezahlschranke.

- Neuer Abschnitt **YouTube-Login** im Downloader. Jon liest die Cookies entweder direkt
  aus deinem Browser (Firefox, Brave, Edge, Chrome, Chromium, Opera, Vivaldi, Safari) oder
  aus einer exportierten `cookies.txt`, die du einmal hinterlegst.
- Scheitert ein Download an Bezahlung, Mitgliedschaft, Altersfreigabe oder der
  Bot-Abfrage, probiert Jon die hinterlegten Logins automatisch durch, statt sofort
  aufzugeben.
- Der Fehlertext sagt jetzt, was zu tun ist, und unterscheidet „noch kein Login
  hinterlegt" von „Login abgelaufen oder falsches Konto".
- Der Login-Bereich klappt von selbst auf, wenn ein Video ihn braucht.
- Cookies bleiben lokal in `<Daten>/downloader/cookies.txt` — nichts wird hochgeladen.

## [4.34.1] — 2026-08-10

### 👥 Koop in den neuen Spielen

Die Harmonischen Inseln und die Blockwelt spielt ihr jetzt zu zweit — über denselben
Freundschaftscode wie ECHO, AETHERIA und die alte Browser-Blockwelt.

- **K** öffnet die Koop-Anzeige: einer erstellt ein Spiel, der andere tippt den
  sechsstelligen Code ein. Wer beitritt, meldet sich selbst bereit; der Gastgeber startet
  mit Enter.
- Ihr seht euch gegenseitig laufen, sauber zwischen den Servertakten geglättet.
- In der Blockwelt bekommt der Gast die Welt des Gastgebers (gleiche Saat), und jeder
  gesetzte oder abgebaute Block erscheint auch beim anderen.
- Auf den Harmonischen Inseln zählt jede Lieferung für beide, und geschenkte Herzen
  zählen zusammen.
- Der Netzcode (`spiele/felwerk/src/fw/Koop.*`) liegt in der gemeinsamen Engine, spricht
  dasselbe JSON-Protokoll über TCP 8759 und wird von beiden Spielen geteilt.

### 🏝️ Die Harmonischen Inseln haben ein Ziel

Vorher konnte man sammeln und abgeben, aber nichts sagte einem wofür. Jetzt schon:

- Der Leuchtturm nennt seinen **Auftrag**: „braucht 3 × Korn", mit Fortschrittsbalken.
  Sechs Stufen, jede mit eigenem Wunsch — das schickt dich abwechselnd zur Farm, zum Berg
  und in die Werkstatt. Das Gewünschte zählt doppelt, alles andere einfach.
- Über dem Kopf mancher Bewohner schwebt ein **Wunsch**. Hast du das Passende dabei,
  schenkst du es mit **F** und bekommst ein **Herz**.
- Ist der Turm fertig, kommen alle Bewohner an der Werft zusammen, es steigen Lichter auf,
  und ein Abspann zählt die verschenkten Herzen. Weiterspielen geht trotzdem.

### 🎮 Steuerung

- **Blockwelt**: A und D waren vertauscht — der Rechts-Vektor zeigte nach links.
- **Harmonische Inseln**: W lief nach hinten (aus der Vorversion), jetzt läuft W nach vorn.

## [4.34.0] — 2026-08-10

### 🧱 Die Blockwelt hat keinen Rand mehr

Die Voxel-Sandbox ist wieder so weit wie im Browser — nur eben als eigenes Programm.

- **Endlose Welt**: Felder von 16 × 16 Blöcken entstehen, während du läufst, und werden
  hinter dir wieder freigegeben. Im Speicher liegen immer nur ein paar hundert Felder,
  egal wie weit du gehst.
- **Landschaften**: Aus drei Lagen Perlin-Rauschen wachsen Ebene, Wald, Wüste mit Kakteen,
  Schneeland und Gebirge, dazu Seen, Strände und Wälder. Die Anzeige nennt Landschaft und
  Position.
- **Echte Texturen**: 20 Kacheln werden beim Start Bildpunkt für Bildpunkt gemalt —
  Grasnarbe über Erde, Jahresringe im Stamm, Fugen im Ziegel, die weiße Binde am TNT.
  Keine einzige Bilddatei liegt bei.
- **16 Blocksorten** in der Leiste, mit 1–9 und dem Mausrad wählbar.
- **TNT und Enderperle**: Ein Klick auf TNT zündet die Lunte, die Explosion reißt ein Loch
  und steckt benachbartes TNT an. Die Enderperle fliegt im Bogen und versetzt dich dorthin,
  wo sie landet.
- Gespeichert wird nur, was du geändert hast — die Datei bleibt klein.

### 🏝️ Harmonische Inseln: W läuft nach vorn

In der isometrischen Ansicht liefen W und S verkehrt herum, weil die Blickrichtung von der
Kamera zum Ziel gerechnet wurde statt umgekehrt. Jetzt geht W nach vorn und S zurück.

## [4.33.9] — 2026-08-09

### 🏝️ Harmonische Inseln — ein neues Spiel zum Runterkommen

Ein schwebendes Archipel in der Abendsonne, in echter isometrischer Schrägsicht, als
eigenes Programm neben ECHO, AETHERIA und STARFALL.

- Vier Inseln, durch Holzbrücken verbunden: die Herzinsel mit Markt, runder Werkstatt und
  Gildenhalle, dazu Farm, Steinmutter und Werft.
- Korn, Stein und Bretter sammeln und zum unfertigen Leuchtturm bringen — er wächst in
  sechs Stufen, bis sein Licht brennt.
- Die Bewohner leben ihr eigenes Leben: sie wandern über die Brücken, tragen selbst
  Bretter zur Baustelle, haben Haustiere dabei und jubeln mit, wenn der Turm wächst.
- Alpakas, Schafe und Capybaras auf der Weide, Blätter im Wind, Gischt an den Ufern, ein
  Regenbogen über dem Berg und weiche Schatten unter allem.
- In C++ ohne Engine geschrieben; Gelände, Häuser, Figuren und Klänge entstehen zur
  Laufzeit. Läuft mit rund 150 Bildern je Sekunde auf einer Intel-UHD-620.

### 🧱 Blockwelt läuft jetzt als eigenes Spiel

Die Voxel-Sandbox startet nicht mehr im Browser, sondern wie ECHO als eigenes Fenster aus
dem Spiele-Tab.

- Neu in C++ geschrieben: Landschaft mit Hügeln, Stränden, Seen, Wäldern und Höhlen,
  weiche Kantenverschattung, Tag- und Nachtwechsel mit Sternen.
- Abbauen, setzen, graben, schwimmen, fliegen — und **Mini Jon schwebt mit**: Auf `T`
  baut er dir Haus, Turm, Brücke, Baum oder Leuchtfeuer, Block für Block zum Zuschauen.
- Änderungen werden gespeichert und beim nächsten Start wieder eingesetzt.

### 🌸 Cozy — ein dritter Modus in Weiß und Rosa

Neben Hell und Dunkel gibt es jetzt **Cozy**: zartes Rosa auf Weiß, für Jon und für Mini
Jon. Der Goldton der ganzen Oberfläche hängt jetzt an einer einzigen Stelle, deshalb
färbt sich alles mit — Knöpfe, Ränder, Verläufe, Bildlaufleisten.

### 👀 Mini Jon und sein Haustier sehen endlich aus wie gedacht

In den 3D-Modellen wurden Teile in falscher Reihenfolge verkettet — Ohren, Augen, Nase
und Beine rutschten dabei ins Innere des Körpers, übrig blieb eine glatte Kugel. Jetzt
sitzt alles am richtigen Platz:

- Katze und Hund haben Ohren mit Innenohr, Augen mit Iris und Lichtpunkt, Schnauze,
  Beine mit Pfoten und einen Schweif, der sich bewegt.
- Mini Jon hat glänzende Augen und ein Lächeln aus dem Goldton.
- Neue Beleuchtung mit Haupt-, Fülllicht und Fellschimmer.

### 🖊️ Kleinigkeiten

- Haustierauswahl umgezogen: sie steht jetzt bei „Mini Jon anpassen" zwischen Farbe,
  Augen und Größe, nicht mehr im Einstellungsmenü.
- Heller und Cozy-Modus sind etwas abgetönt — auf Weiß in Weiß war zu wenig zu erkennen.
- Lange Texte brechen sauber um: im Spiele-Tab werden Beschreibungen gekürzt („mehr
  lesen" klappt sie auf), und in den Haftnotizen läuft kein Wort mehr aus dem Zettel.

## [4.33.8] — 2026-08-08

### ☎️ Jon anrufen — und von überall telefonieren

Bisher rief nur Jon an. Jetzt geht es in beide Richtungen, und zwar von überall.

- **Jon anrufen**: In der SIP-App einfach den eigenen Benutzernamen wählen. Jon hebt ab,
  begrüßt dich und redet mit dir — mit demselben Zugriff wie im Chat. Der Begrüßungssatz
  ist über `phone_greeting` frei wählbar, und wer das nicht will, schaltet eingehende
  Anrufe mit `phone_accept_incoming` ab. Ohne gültiges SIP-Passwort nimmt Jon nichts an.
- **Von unterwegs, mit mobilen Daten**: Die Serveradresse steht jetzt auf
  **Automatisch** — Jon nennt jedem Anrufer die Adresse, über die dieser ihn tatsächlich
  erreicht hat. Zu Hause die WLAN-Adresse, unterwegs die Tailscale-Adresse. Beim
  Verlassen des Hauses muss nichts umgestellt werden. Die Anleitung für Tailscale steht
  in `docs/TELEFON.md`; der SIP-Port gehört weiterhin **nicht** in den Router.

### 🔇 Jon sagt jetzt, wenn er nichts hört

Kam beim Anruf kein Ton an, wartete Jon stumm. Jetzt sagt er es nach sechs Sekunden ins
Telefon, und der Anrufeintrag nennt den Grund statt pauschal „Gespräch beendet" —
meistens fehlt die Firewallregel für die Sprachpakete.

### 🔌 SIP kommt nach einem Neustart wieder hoch

Hielt nach dem Schließen der App noch der alte Prozess den Port, blieb die
Telefonfunktion stumm und wirkte wie vergessen. Die Sockets binden jetzt mit
`SO_REUSEADDR`, und schlägt es trotzdem fehl, nennt die Meldung den Prozess, dem der Port
gehört.

Dazu: SIP läuft zusätzlich über **TCP** — manche SIP-Apps sprechen kein UDP und meldeten
sonst nur „IOError". Jeder Anmeldeversuch wird mit Quelle, Transport und Grund
protokolliert und im Einrichtungs-Tab angezeigt.

## [4.33.7] — 2026-08-08

### 📞 Jon ruft dich auf dem Handy an

Sag „Jon, ruf mich in 15 Minuten an" — und 15 Minuten später klingelt dein Handy. Nicht
eine Benachrichtigung, sondern ein **echter eingehender Anruf** mit Annehmen und
Ablehnen. Du hebst ab, Jon sagt „Hey Felix!", und ihr redet.

**Ohne Anbieter, ohne Kosten.** Kein Twilio, kein Vonage, keine Telefonie-API. Jon ist
selbst die Telefonanlage: ein SIP-Registrar und ein SIP-Endpunkt direkt im Backend, dazu
ein eigener RTP-Sprachkanal. Dein Handy meldet sich mit einer kostenlosen SIP-App
(Linphone) bei Jon an, alles läuft über dein eigenes Netz.

- **Natürliche Zeitangaben**: „jetzt", „in 20 Minuten", „heute um 18 Uhr", „morgen um 9",
  „nächsten Montag um 17 Uhr" — und für Wiederkehrendes „jeden Montag um 18 Uhr".
  Zeitpunkte werden mit Zeitzone gespeichert, Sommer- und Winterzeit sind abgedeckt.
- **Echtes Gespräch**: Jon hört durchgehend zu, merkt an einer mitlaufenden
  Sprecherkennung, wann du fertig gesprochen hast, und antwortet satzweise — der erste
  Ton kommt, bevor der ganze Satz fertig berechnet ist.
- **Unterbrechen geht**: Sagst du „warte" oder „stopp", während Jon redet, bricht er
  mitten im Wort ab und hört zu.
- **Telefonstimme statt Chatbot**: Am Telefon gilt ein eigener Systemprompt — kurze
  gesprochene Sätze, kein Markdown, keine Aufzählungen, keine Emojis.
- **Neue Werkzeuge**: `call_user`, `schedule_call`, `list_scheduled_calls`,
  `cancel_call`, `update_call`. „Welche Anrufe sind geplant?", „Lösch den um 18 Uhr",
  „Verschieb ihn auf 19 Uhr" funktionieren im Chat.
- **Eigener Bereich** unter Werkzeuge → 📞 Telefonanrufe: Ampel für SIP, Handy und
  Bereitschaft, Einrichtungsassistent mit den fertigen Zugangsdaten, geplante Anrufe zum
  Bearbeiten, Testanruf-Knopf und Gesprächsverlauf.

**Alles lokal**: Spracherkennung mit faster-whisper auf deinem Rechner, Sprachausgabe mit
Jons gewohnter Stimme, und das Sprachmodell ist das, was du in Jon eingestellt hast —
auch Ollama. Audio wird nur im Arbeitsspeicher verarbeitet und danach verworfen; ein
Gesprächsprotokoll entsteht nur, wenn du es einschaltest.

**Sicherheit**: Das SIP-Passwort erzeugt Jon zufällig, angemeldet wird per Digest, und
Jon nimmt selbst keine eingehenden Anrufe an. Für unterwegs gehört der Port nicht ins
Internet, sondern in ein VPN — die Anleitung für Tailscale steht in `docs/TELEFON.md`.

Warum kein Asterisk, obwohl es dafür gemacht ist: Asterisk gibt es für Windows nicht. Es
bräuchte WSL2 oder Docker, und deren NAT-Netz macht gerade die dynamischen RTP-Ports
unzuverlässig. Der eingebaute Stack startet einfach mit `start-jon.bat` mit.

35 neue Tests, 286 insgesamt.

## [4.33.6] — 2026-08-07

### 🕳️ STARFALL rechnet die Scheibe jetzt relativistisch

Die Schwarzloch-Simulation zeigt nicht mehr eine hübsche Näherung, sondern das, was
Astrophysiker rechnen. Fünf Änderungen bringen das Bild näher an das Beobachtbare:

- Das Strahlungsprofil der Akkretionsscheibe folgt dem relativistischen Fluss nach
  **Page und Thorne (1974)** statt der newtonschen Näherung. Der Fluss verschwindet
  exakt an der ISCO und fällt weit außen mit `r⁻³`. Für Schwarzschild liegt das
  Maximum bei 8,39 r_g statt bei 8,17 r_g; mit Spin wandert die Scheibe nach innen
  und wird heißer.
- **Chandrasekhar-Randverdunklung** für streuungsdominierte Scheibenatmosphären.
- **Endliche Schichtdicke**: die optische Tiefe folgt der tatsächlichen Weglänge durch
  die Schicht, dazu Kantenaufhellung am Innenrand.
- **Differentielle Scherung** im Turbulenzmuster — Strukturen werden zu Spiralfäden
  ausgezogen, statt rund zu bleiben.
- **Zeitliche Akkumulation**: Steht die Kamera still, friert die Simulationszeit ein
  und das Bild baut sich in voller Auflösung über bis zu 192 Halton-versetzte
  Abtastungen auf. Vorher lief der Raymarch dauerhaft in 28 bis 70 Prozent Auflösung
  — genau das hat den Photonenring verwaschen.

Die angezeigten Kennzahlen kommen aus demselben Page-Thorne-Profil wie das Bild,
damit Anzeige und Darstellung nicht auseinanderlaufen.

### 📦 STARFALL ist im Windows-Paket dabei

Setup und portable ZIP nehmen den STARFALL-Ordner jetzt mit — wer Jon installiert, hat
alle vier Titel der FelWorks Game Collection sofort unter Werkzeuge → Spiele. Saves,
Einstellungen und die Logdatei bleiben dabei außen vor.

### 🎬 Werbespot direkt im Browser

Neuer Ordner `motion/`: ein 20-Sekunden-Spot für Jon im Hochformat 1080 × 1920 bei
60 FPS, der komplett zur Laufzeit entsteht — jedes Pixel aus WebGL-Shadern, jeder Ton
aus Oszillatoren, keine einzige Bild- oder Videodatei als Vorlage. `index.html`
öffnen, **MP4 exportieren** drücken, fertige Datei hochladen. Kein After Effects,
kein ffmpeg.

### ⬇️ Website: eigener Abschnitt zum Downloader

Die Website erklärt jetzt, was der eingebaute Downloader kann: Vorabprüfung mit Titel,
Kanal, Dauer und Vorschaubild, vier Qualitätsstufen oder MP3, Fortschritt in Klartext
— und der Hinweis, dass alles lokal auf dem eigenen PC läuft.

## [4.33.0] — 2026-08-03

### 🤝 „KI teilen" ist jetzt verständlich

Das Freigabe-Fenster war eine Wand aus Fachbegriffen. Jetzt fragt es zuerst das
Einfachste: **Gebe ich meine KI frei — oder nutze ich die von jemandem?** Danach kommen
nummerierte Schritte statt Optionen.

- Ganz oben steht in einem Satz, was Teilen überhaupt bedeutet: Ein Freund schickt seine
  Fragen an **deine** KI, braucht selbst keinen Schlüssel und sieht von deinem PC nichts
  außer den Antworten.
- Aus „Sichtbarkeit: privat / eingeladen / öffentlich" wurde die Frage **Wer darf
  mitschreiben?** mit den Antworten *Jeder mit meinem Code*, *Nur wen ich einlade* und
  *Gerade niemand* — jede mit einem Satz Erklärung.
- Der Code steht groß da, mit **Code kopieren** und **Link kopieren** und dem Hinweis,
  wann man was braucht (gleiches WLAN oder nicht).
- Aus „Verbundene Benutzer" wurde **Wer gerade verbunden ist** mit Klartext:
  *schreibt gerade*, *verbunden*, *gerade offline* — und **rauswerfen** statt „entfernen".
- Läuft Ollama gar nicht, sagt das Fenster das sofort, statt dich raten zu lassen.
- Name, Beschreibung und „neuer Code" sind unter **Details** eingeklappt.

Der Knopf sitzt jetzt im **Freunde-Chat** links unter deinem Jon-Code — dort, wo man
sowieso ist, wenn man etwas mit Freunden teilen will. Aus der Chat-Kopfzeile ist er raus.

### 🪪 Jon-Code neben jedem Namen

In der Freundesliste steht unter jedem Namen sein **Jon-Code**, und im Chat-Kopf des
offenen Gesprächs ebenso. Ein Klick kopiert ihn — praktisch, wenn du einen Freund an
jemand anderen weiterreichen willst.

### 🎮 ECHO: Sprung nach vorn mit Q

**Q** teleportiert dich **3 Meter in Blickrichtung**, danach **10 Sekunden Abklingzeit**.
Der Sprung prüft vorher per Strahl, ob der Weg frei ist, hält vor Wänden an, setzt dich
sauber auf den Boden und bricht ab, wenn am Ziel kein Platz ist („Kein Platz zum
Springen"). Während die Abklingzeit läuft, zeigt Jon die Restsekunden an.

### 🧭 Mitspieler schauen in die richtige Richtung

In der **Blockwelt** saß die Gesichtstextur auf der falschen Seite des Kopfes: Die
Spielfiguren blickten exakt entgegengesetzt zu ihrer Laufrichtung, weil das Gesicht auf
der **+Z**-Seite lag, die Blickrichtung im Spiel aber **−Z** ist. Gesicht und Kopfneigung
sitzen jetzt richtig — auch bei Jon selbst. ECHO und AETHERIA waren bereits korrekt
(dort zeigt das Modell mit Nase und Augenbrauen nach −Z).

## [4.32.9] — 2026-08-02

### 🧊 Echte 3D-Modelle für Mini Jon, Katze und Hund

Aus der Schattierung von 3.38.0 sind jetzt richtige 3D-Modelle geworden. Neu ist
`frontend/electron/pet3d.js`: ein eigener **WebGL-Renderer ohne jede Fremdbibliothek** —
nichts wird nachgeladen, alles läuft offline im Mini-Jon-Fenster.

- **Echte Geometrie** statt Zeichnung: Kugeln, Ellipsoide, Kegel und ein Torus werden zur
  Laufzeit erzeugt, mit Normalen pro Vertex.
- **Echte Beleuchtung**: gerichtetes Licht, Ambient, Blinn-Phong-Glanzlicht und ein
  Rim-Light, alles pro Pixel im Fragment-Shader. Tiefentest an, damit sich Teile richtig
  verdecken.
- **Mini Jon** ist eine Kugel in deiner Gesichtsfarbe mit goldenem Ring, zwei Augen und
  einem Mund, der sich beim Sprechen wirklich öffnet — Lippensynchronität und Blinzeln
  steuern jetzt das 3D-Modell.
- **Die Katze** hat Körper, Kopf, zwei Ohren mit rosa Innenseite, Schnauze, Nase,
  Schnurrhaare und einen geschwungenen Schwanz. **Der Hund** hat Körper, Kopf, Schnauze,
  feuchte Nase, Schlappohren und Rute. Beide drehen sich sanft, wippen und schlafen
  sichtbar ein; die Laufrichtung dreht das Modell mit.
- **Fällt WebGL aus**, schaltet Jon automatisch auf die plastische CSS-Darstellung von
  3.38.0 zurück statt gar nichts zu zeigen.

### Der Schalter sitzt jetzt dort, wo er hingehört

Der 3D-Schalter ist aus dem Zahnrad-Menü **in „Mini Jon anpassen"** umgezogen — direkt
neben Farbe, Augen und Größe. Dort gibt es auch eine **Live-Vorschau in 3D** mit
Umschalter zwischen Mini Jon, Katze und Hund; Farbwechsel sind sofort am Modell zu sehen.

Nachgemessen im Browser: Mini Jon füllt 68 % der Fläche mit 822 verschiedenen
Farbwerten, Katze und Hund liegen bei 346 bzw. 783 — das ist echte Schattierung auf
gekrümmten Flächen, keine Flächenfüllung. Ausschalten stellt exakt die alte flache
Darstellung wieder her.

## [3.38.0] — 2026-08-02

### 🧊 3D-Modus für Mini Jon, Katze und Hund

Ein Schalter im Zahnrad-Menü unter **Mini Jon & Haustier** — und alle drei bekommen Tiefe:

- **Mini Jon** wird zur Kugel statt zur Scheibe: ein Glanzlicht oben links, Abschattung
  unten rechts, dazu eine sanfte Drehung um die eigene Achse (`rotateY`/`rotateX` mit
  Perspektive) und ein mitwandernder Bodenschatten.
- **Katze und Hund** bekommen plastische Verläufe für Körper, Kopf und Ohren, Glanzlichter
  in den Augen, eine feuchte Nase, einen weichen Bodenschatten und dieselbe leichte
  Drehung. Ihre Laufrichtung bleibt dabei erhalten.
- Der Schatten überlebt jetzt auch das Schlafen: `setPetSleep` arbeitet mit einer
  CSS-Klasse statt einem Inline-Filter, der den Schatten vorher überschrieben hätte.
- Aus bleibt aus: Ohne den Schalter sieht alles exakt so aus wie bisher.

### 🤝 Ollama teilen direkt aus dem Chat

- Neuer Knopf **🤝 Ollama teilen** in der Chat-Kopfzeile. Er öffnet Freigabe und
  Verbindungsaufbau in einem Fenster — Server freigeben, Code kopieren oder den Code eines
  anderen eintragen.
- **Neuer Eintrag in der Anbieterauswahl**: Sobald dir jemand seinen Server freigegeben
  hat, steht dort **„Ollama von &lt;Name&gt;"** — nur dann, sonst nicht.
- Wählst du ihn, ist **das Modell fest vorgegeben**: Es ist genau das, was der Besitzer
  teilt. Statt der Modell-Auswahl steht ein Schloss mit dem Modellnamen; ändern kann man
  es nicht. Wechselt der Besitzer sein Modell, zieht die Anzeige beim nächsten
  Aktualisieren nach.

### 🛑 Der Knopf neben dem X beendet jetzt wirklich alles

Der Pfeil-nach-unten in der Titelleiste hat Jon bisher nur ausgeblendet — Backend und
Konsolenfenster liefen weiter. Jetzt stoppt er **alles**: Jon-Fenster, Mini Jon, das
Backend und das zugehörige Konsolenfenster (`start-jon.bat`, `jon-backend.exe`,
`app.main`). Wer Jon weiter im Hintergrund laufen lassen will, nimmt den Eintrag
**Fenster ausblenden (Jon läuft weiter)** im Infobereich.

Die komplette Suite bleibt grün (247 → 251).

## [3.37.2] — 2026-08-02

### 🤝 Ollama-Server über den Jon-Chat freigeben

Wer die stärkere Grafikkarte hat, kann seinen Ollama-Server jetzt für andere Jon-Nutzer
freigeben. Sie chatten darüber, als wäre es ihr eigenes Modell — ohne Zugriff auf
irgendetwas anderes auf dem fremden PC.

- **Neuer Bereich „Serverfreigabe"** in den Ollama-Einstellungen: an/aus, Freigabename,
  Beschreibung, Sichtbarkeit (**Privat**, **Nur Eingeladene**, **Öffentlich**),
  Freigabecode und Einladungslink zum Kopieren, jederzeit abschaltbar.
- **Verbinden per Code oder Link**: `AB39KD12` genügt im Heimnetz — Jon sucht den Server
  per Broadcast (UDP 8762). Über Tailscale oder von außerhalb nimmt man
  `AB39KD12@100.101.102.103:8758` bzw. `jon://ollama/…`.
- **Automatisch in der KI-Auswahl**: Modelle eines verbundenen Servers erscheinen unter
  dem Anbieter `ollama` als eigene Gruppe „Freigabe <Code>". Chatverlauf, Streaming und
  sämtliche Ollama-Einstellungen (Temperatur, Top P, Top K, Max Tokens, Context Length,
  Keep Alive, Seed, System Prompt, Timeout) gelten unverändert weiter.
- **Verwaltung für den Besitzer**: verbundene Benutzer mit Adresse, Verbindungsstatus
  (aktiv/verbunden/offline), genutztem Modell, Anzahl Sitzungen und Anfragen sowie
  Zeitpunkt der letzten Aktivität. Einzelne Benutzer entfernen oder allen den Zugriff
  entziehen — beides wirkt sofort, auch mitten in einer laufenden Antwort.
- **Einladungen** gelten für genau einen Benutzer und verfallen nach der ersten Nutzung.
  **Neuen Code erzeugen** macht den alten augenblicklich ungültig.

### Sicherheit

- **Kein offener Zugriff.** Beim Beitritt bekommt jeder Gast ein eigenes Zugriffstoken
  (256 Bit, `secrets.token_urlsafe`). Ohne gültiges Token antwortet jeder
  `/share/api/*`-Endpunkt mit **401** — auch bei öffentlicher Sichtbarkeit.
- Tokens liegen **nur als SHA-256-Hash** in `data/ollama_share.json` und werden
  zeitkonstant verglichen (`hmac.compare_digest`).
- Die Freigabe hängt am LAN-Chat-Port **8758**, **nicht** an Jons Steuer-API
  (127.0.0.1:8756). Freigegeben ist ausschließlich das Antworten des Modells — Chats,
  Dateien, Werkzeuge und PC-Steuerung des Besitzers bleiben unerreichbar. Die Werkzeuge
  eines Gastes laufen weiterhin auf seinem eigenen Rechner.
- Fehlversuche werden pro Adresse gebremst (10 pro Minute).
- Anfragen von Gästen werden gefiltert: Sampling-Werte (Temperatur, Top P, Top K, Seed,
  Stop) gelten, aber **Context Length** und **Max Tokens** deckelt der Gastgeber auf seine
  eigenen Einstellungen, und sein Keep Alive bleibt gültig — niemand kann den Speicher des
  Gastgebers mit `num_ctx: 1000000` sprengen.
- Freigabe aus = alle Tokens sofort ungültig; laufende Streams brechen ab.

### Dokumentation

Neues Kapitel „Server für andere freigeben" in [docs/OLLAMA.md](docs/OLLAMA.md) und auf
[getjon.info](https://getjon.info/ollama.html), dazu README (de/en), FEATURES, API, FAQ
und EXAMPLES.

30 neue Tests decken Sichtbarkeiten, Einladungen, Beitritt, Tokenprüfung, Widerruf,
Rate-Limit, Netzwerksuche, die Gastgeber-Endpunkte und den Chat über einen fremden Server
ab; die komplette Suite bleibt grün (217 → 247). Zusätzlich end-to-end gegen einen echten
Ollama-Server geprüft: Gastgeber freigeben, Gast verbinden, Antwort streamen, Zugriff
widerrufen — der Gast bekommt danach sofort eine klare Meldung.

## [3.37.0] — 2026-08-02

### 🦙 Ollama komplett eingebaut

Ollama war bisher nur ein Eintrag in der Anbieterliste mit fester Adresse aus der `.env`.
Jetzt hat es einen eigenen Bereich in den Einstellungen, einen sichtbaren Serverstatus und
alle Regler, die Ollama wirklich kennt — und es darf auf einem ganz anderen Rechner laufen.

- **Neuer Einstellungsbereich „Ollama"** im Zahnrad-Menü mit Statuszeile
  (Online/Offline · Antwortzeit · Modellanzahl) und dem Fenster **Server & Modelle …**.
  Es gibt **keinen** neuen Anbieter und keine zweite Anbieterseite: Die Anbieterliste ist
  unverändert, nur der vorhandene `ollama`-Eintrag kann jetzt mehr.
- **Offizielle Ollama-API** (`/api/chat`, `/api/tags`, `/api/version`) statt der
  OpenAI-kompatiblen Hilfsschnittstelle. Das war nötig, weil `/v1` **Top K**,
  **Context Length** (`num_ctx`) und **Keep Alive** stillschweigend verwirft — nachgemessen
  über `/api/ps`. Über die native API greifen sie wirklich.
- **Server frei wählbar:** Server-URL, Host/IP, Port und http/https sind einzeln
  einstellbar und halten sich gegenseitig synchron. Darunter schlägt Jon die Adressen
  dieses PCs zum Anklicken vor — **localhost**, **Heimnetz (LAN)** und **Tailscale**
  (erkannt am Bereich 100.64.0.0/10). Damit läuft das Modell auf dem Rechner mit der
  starken Grafikkarte, während Jon auf dem Laptop sitzt.
- **Serverstatus jederzeit:** Zustand, Antwortzeit in Millisekunden, Ollama-Version,
  gewähltes Modell, Anzahl installierter Modelle und Zeitpunkt der letzten erfolgreichen
  Verbindung. Aktualisiert sich alle 15 Sekunden, **Verbindung testen** fragt sofort nach.
- **Modelle** automatisch laden, neu laden und auswählen — direkt aus `/api/tags`. Die
  Modellwahl im Ollama-Fenster und die oben im Chat bleiben synchron.
- **Alle Antwort-Einstellungen:** Temperatur, Top P, Top K, Max Tokens (`-1` = ohne Limit),
  Context Length, Keep Alive, Seed, System Prompt, Streaming an/aus, Timeout und
  automatische Wiederverbindung. Alles landet in `data/ollama.json` und wird beim Start
  geladen.
- **Fehler statt Absturz:** „Keine Verbindung zu Ollama unter …", „Das Modell X ist auf dem
  Server nicht installiert (ollama pull X)", „Ollama hat zu lange gebraucht", „passt nicht
  in den Speicher" — jeweils mit dem konkreten nächsten Schritt. Falsche Eingaben (Port 0,
  Host mit Leerzeichen, Temperatur 5) werden mit Klartext abgelehnt und ändern die
  gespeicherte Konfiguration nicht.
- **Automatische Wiederverbindung:** Bricht die Verbindung vor der ersten Antwort weg,
  versucht Jon es bis zu dreimal mit wachsendem Abstand.
- **Modelle ohne Werkzeuge** (z. B. `gemma3:270m`) antworten trotzdem: Meldet der Server
  `does not support tools`, wiederholt Jon die Anfrage automatisch ohne Werkzeuge.
- **Ausschalten heißt ausschalten:** Steht der Schalter auf aus, verschwindet Ollama aus
  der Anbieterliste und aus dem Konten-Bereich, statt weiter „verbunden" zu behaupten.
- Neue Endpunkte: `GET/PUT /api/ollama/config`, `POST /api/ollama/reset`,
  `GET /api/ollama/status`, `POST /api/ollama/test`, `GET /api/ollama/models`,
  `GET /api/ollama/hosts`.
- Neue Dokumentation **[docs/OLLAMA.md](docs/OLLAMA.md)**: Was ist Ollama, Voraussetzungen,
  Installation, Einrichtung, Server/Port/Host, LAN, Tailscale, Verbindung testen, Modelle
  installieren und wechseln, Fehlerbehebung, FAQ, Sicherheit und Tipps. Dazu die
  Ollama-Seite auf [getjon.info](https://getjon.info).

38 neue Tests decken Konfiguration, Validierung, Status, Modell-Liste, Chat-Optionen,
Werkzeug-Runden, Streaming an/aus, Reconnect und alle Fehlerfälle ab; die komplette Suite
bleibt grün (211 → 217). Zusätzlich gegen einen echten Ollama-Server (0.32.5) gegengeprüft: `num_ctx`
und `keep_alive` kommen dort nachweislich an.

## [3.36.3] — 2026-07-30

### Fix — Koop ging nur auf demselben Gerät

Der Freundschaftscode existierte immer nur in dem Jon, das die Lobby angelegt hat. Tippte
man ihn am zweiten Rechner ein, fragte dieses Jon **sich selbst** — und antwortete
„Code nicht gefunden". Funktioniert hat nur die lange Einladung `CODE@adresse:8760`, und
selbst deren Adresse war oft falsch: Jon nahm einfach den ersten Eintrag von
`socket.gethostname()`, und das war auf diesem Rechner die VPN-Adresse (`10.2.0.2`) statt
der echten WLAN-Adresse. Laptop gegen PC war damit praktisch unspielbar.

- **Lobby-Suche im Netzwerk** (neu `coop_lan_service.py`): Jeder Jon horcht auf
  **UDP 8761**. Kennt das Jon des Gastes den Code nicht, fragt es per Broadcast „wer hat
  `AB39KD`?" — der Gastgeber antwortet mit Adresse, Ports und Lobby-Infos. Gesucht wird
  auf allen Netzwerkkarten (255.255.255.255 **und** die Broadcast-Adresse jedes Subnetzes),
  damit ein aktives VPN die Suche nicht verschluckt.
- **`redirect` im Koop-Protokoll**: Statt eines Fehlers schickt der Server jetzt
  `{"t":"redirect","host":…,"tcp_port":…,"ws_port":…}`. Browser (`blockwelt.html`) und
  C++-Spiele (`CoopSession`) verbinden sich daraufhin neu zum Gastgeber — maximal drei
  Weiterleitungen, danach eine ehrliche Fehlermeldung.
- **Richtige LAN-Adresse in der Einladung**: Die Adapter kommen über
  `GetAdaptersAddresses`. Sortiert wird nach Gateway, DHCP, Adaptertyp und Name —
  VPN-, Hyper-V-, VirtualBox-, WSL- und Docker-Adapter landen hinten. In der Antwort an
  einen Sucher nennt der Gastgeber gezielt die Adresse der Netzwerkkarte, die in dessen
  Subnetz liegt. Aus `10.2.0.2` wird so `10.0.0.253`.
- **Windows-Firewall**: `GET /api/mp/network` sagt, ob die Koop-Regeln fehlen; in der
  Lobby erscheint dann **Netzwerk freigeben** (`POST /api/mp/firewall`). Das legt nach
  einer Windows-Rückfrage genau zwei Regeln an — TCP 8759/8760 und UDP 8761.
- **Blockwelt**: Im Beitreten-Fenster listet **Netzwerk durchsuchen** alle offenen Spiele
  im Heimnetz mit Gastgeber, Spielerzahl und Adresse zum Anklicken (`GET /api/mp/scan`).
  Die Lobby zeigt die Einladung so an, wie der Server sie kennt.
- **ECHO/AETHERIA**: Der Code allein genügt jetzt auch hier. Ein Beitritt setzt Adresse
  und Port vorher auf das lokale Jon zurück, damit nach einem Fremdspiel kein alter
  Gastgeber hängen bleibt; die angezeigte Einladung kommt vom Server (`invite_tcp`).

Verifiziert mit zwei getrennten Jon-Instanzen (eigene Datenordner, eigene Ports): Der
Gast kennt den Code nicht, findet die Lobby über die Netzwerksuche, wird weitergeleitet
und steht danach mit dem Gastgeber in derselben Lobby — einmal als ECHO-Client über TCP,
einmal als Browser über WebSocket.

### Spiele 1.1.0
`ECHO_VERSION` steht jetzt auf **1.1.0**, passend zur Sammlung in `jon-spiele.json`.

## [3.35.0] — 2026-07-30

### Fix — der Beenden-Knopf ließ das Backend doch weiterlaufen

3.34.0 hat nur den Prozess beendet, den die App **selbst** gestartet hatte. Lief das
Backend aus `start-jon.bat`, aus dem Autostart oder aus einer vorherigen Sitzung, kannte
Electron dessen PID nicht — und `jon-backend.exe` blieb im Task-Manager stehen. Im
Entwicklungsmodus (`npm run dev`) startet die App gar kein Backend, dort hat das
Aufräumen deshalb nie gegriffen: die Portsuche hing an `app.isPackaged`.

- Neu `POST /api/system/shutdown`: das Backend beendet sich selbst sauber, egal wer es
  gestartet hat. `quitJon()` fragt zuerst höflich (max. 2 s) und greift erst dann hart
  durch. Neu `GET /api/system/whoami` (PID + Version) zum Nachprüfen.
- Das Aufräumen der Ports 8756/8758/8759/8760 läuft jetzt **immer**, nicht nur in der
  Installer-Version — und tötet nur Prozesse, die auch wirklich `jon-backend`, `python`,
  `pythonw` oder `py` heißen, statt blind alles auf dem Port.

Verifiziert: sauberes Herunterfahren beendet den Prozess in 0,5 s mit Code 0; ein
absichtlich fremd gestartetes Backend ohne `JON_PARENT_PID` ist nach dem Aufräumen
ebenfalls in 0,5 s weg.

### Neu — Update über die .exe funktioniert wirklich

`/update` prüfte zwar auf neue Versionen, brach in der Installer-Version aber mit
„Bitte lade die neueste Version manuell herunter" ab — ein Update über die App gab es
schlicht nicht. Jetzt:

- `update_service.py` kennt die Installationsart (`exe` / `git` / `manual`) und liest im
  EXE-Modus das GitHub-Release samt `Jon-Setup.exe` (Adresse, Größe, Release-Text).
- **Maßgeblich ist, was installierbar ist**: angeboten wird die Version des fertigen
  Releases, nicht die Versionsnummer aus dem Quellcode. Ist auf `main` schon eine höhere
  Version angekündigt, für die es noch kein Installationsprogramm gibt, sagt Jon das —
  und bietet kein Update an, das dann doch dieselbe Version installieren würde.
- `download_installer()` lädt mit Fortschrittsanzeige nach `DATA_DIR/updates/` und
  **prüft, was ankommt**: nur `https`, Mindestgröße, Größe wie im Release angekündigt,
  und die Datei muss mit `MZ` beginnen (eine HTML-Fehlerseite wird also nicht als
  Programm gestartet). Halbe Downloads landen in `.part` und werden bei jedem Fehler
  weggeräumt; alte Installer verschwinden nach dem nächsten erfolgreichen Download.
- Der Ablauf endet mit `INSTALLER <pfad>`; die App fragt einmal nach, startet das
  Installationsprogramm losgelöst und beendet Jon danach, damit die Dateien nicht mehr
  gesperrt sind. Der Installer bringt Jon anschließend selbst zurück
  (`runAfterFinish`). Electron nimmt dafür nur Pfade der Form
  `X:\...\Jon-Setup*.exe` an — kein beliebiges Programm.
- Chats, Konten und Einstellungen liegen unter `DATA_DIR` und werden nicht angefasst.

Für Quellcode-Installationen bleibt alles wie gehabt (`git pull` + bedingtes
`pip`/`npm`), das wird jetzt nur noch bewusst über `install_mode()` ausgewählt.

### Kleinigkeiten
- Herausgeber überall FelWorks; `win.publisherName` ist bei electron-builder 25
  veraltet und liegt jetzt unter `win.signtoolOptions.publisherName`.
- 10 neue Tests in `test_update.py` (Installationsart, Release-Auswahl, kein Downgrade,
  Download-Prüfungen, Fortschritt, Aufräumen, kompletter Ablauf bis `INSTALLER`).
  Gesamt **172 Tests grün**.

## [3.34.0] — 2026-07-30

### Fix — Multiplayer: „man kann sich nicht verbinden"

Der Koop aus 3.33.0 funktionierte nur in Sonderfällen. Vier echte Ursachen, alle
gefunden und behoben:

- **Der Server war für Mitspieler gar nicht erreichbar.** Uvicorn lauschte auf
  `127.0.0.1`, solange nicht `JON_LAN=1` in der `.env` stand — und diese Datei gab es
  gar nicht. Ein Freund am zweiten PC lief also immer ins Leere, obwohl das Menü die
  LAN-IP versprach. Jetzt hat der Koop einen **eigenen Port 8760 auf `0.0.0.0`**
  (`create_coop_app()` in `multiplayer_routes.py`, gestartet als `_coop_web_server()` —
  nach dem Muster des P2P-Chats, inkl. „Port belegt"-Abfangen). Dieser Port liefert
  ausschließlich `/api/mp/*` und `/blockwelt`; Chat, Dateien, Konten und PC-Steuerung
  bleiben auf 8756 und damit lokal. `JON_LAN` braucht man für Koop nicht mehr.
  Ein Gast ohne eigenes Jon kann sogar direkt `http://<adresse>:8760/blockwelt` öffnen.
- **ECHO/AETHERIA schickten den Handshake nur einmal pro Programmstart.**
  `CoopSession::update()` hing an einem `everSent`-Flag, das nie zurückgesetzt wurde.
  Der erste Versuch klappte; jeder weitere — nach einem Tippfehler im Code, nach
  „Lobby verlassen", nach einem Serverfehler — verband die Leitung, sagte aber nie
  „hallo" und blieb für immer auf **VERBINDE** stehen. Ersetzt durch `handshakeSent`,
  das `beginConnect()` bei jedem Verbindungsaufbau löscht.
- **Der Fehlerbildschirm war eine Sackgasse.** `ZURUECK ZUM MENUE` setzte nur die
  Ansicht zurück, die Sitzung blieb im Zustand `COOP_ERROR` — und `update()` sprang
  sofort wieder in den Fehlerbildschirm. Jetzt räumt `ACT_RETRY` die Sitzung sauber auf.
- **Abgelehnte Verbindungen wurden nicht erkannt.** `NetClient` prüfte beim
  nicht-blockierenden `connect()` nur `writefds`, nie `exceptfds` oder `SO_ERROR` — ein
  geschlossener Port lief 6 s pro Adresse in den Timeout, bei IPv6+IPv4 also 12 s
  scheinbares Hängen. Jetzt sofortige Erkennung mit klarer Meldung
  („Kein Jon-Server auf host:port" statt „Verbindung abgelehnt").

Dazu aufgeräumt:

- Der Handshake meldet **jeden** Fehlgrund an den Client (`resume`, `create`, `join`,
  `handshake`) statt nur beim Beitreten; die WebSocket-Route schickt keine doppelte
  Fehlermeldung mehr.
- Die Blockwelt schließt den alten Socket, bevor sie einen neuen öffnet, und ignoriert
  Ereignisse veralteter Verbindungen — vorher konnte das `onclose` eines toten Sockets
  die frische Verbindung wieder auf „verloren" setzen.
- Die Lobby zeigt jetzt **zwei** Felder: den Code für denselben PC und die
  **Einladung mit Adresse** (`AB39KD@192.168.1.20:8760`) für andere PCs, beide mit
  Kopierknopf. Adresse und Port holt die Seite aus `/api/mp/info`
  (neu: `ws_port`, `invite_host`).
- Das Koop-Menü in ECHO verarbeitet den Team-Chat auch während der 0,22-s-Eingabesperre
  nach dem Öffnen; die Sperre blockiert nur noch Tasten und Klicks, nicht die
  Serverantworten.
- `jon-backend.spec` nimmt `websockets` vollständig mit, damit der WebSocket-Koop auch
  in der gepackten `jon-backend.exe` läuft.

Verifiziert: zwei Browser-Kontexte über die echte Netzwerkadresse (10.2.0.2) bis
`phase=playing` inkl. Ping und Team-Chat, ohne JS-Fehler; ECHO verbindet sich nach einem
absichtlich fehlgeschlagenen ersten Versuch im selben Prozess und taucht im Roster des
Gastgebers auf.

### Neu — Jon beenden stoppt auch das Backend

Das X der App versteckte das Fenster nur; `jon-backend.exe` lief unbemerkt weiter.

- **X beendet Jon jetzt wirklich** (`quitJon()`): Backend stoppen, Fenster schließen,
  Tray-Symbol entfernen. Wer Jon nur wegklicken will, hat dafür einen neuen Knopf
  in der Titelleiste (⌄, „In den Hintergrund") und den Tray-Eintrag
  „Im Hintergrund weiterlaufen" — Strg+Alt+J holt ihn zurück.
- **`stopBackend()`** killt den Prozessbaum und räumt danach übrig gebliebene Listener
  auf 8756/8758/8759/8760 ab, damit kein Backend einer vorherigen Sitzung stehen bleibt.
- **Parent-Watchdog im Backend**: Electron gibt seine PID als `JON_PARENT_PID` mit;
  `_parent_watchdog()` prüft alle 2 s, ob die App noch lebt, und fährt das Backend
  sonst selbst herunter. Damit bleibt auch nach einem Absturz der App nichts hängen.

### Fix — ECHO: Aufzugtür führte vor eine Wand

Die Aufzugkabine steht im hinteren Teil des Schachtraums und öffnet nach vorn. Die
Eingangstür vom Flur landet aber je nach Grundriss irgendwo an der Raumwand — ein
kopfloser Durchlauf über 40 Seeds zeigt: **168 von 328 Aufzugtüren (51 %)** öffneten
auf die Stahlwand der Kabine statt auf ihren Eingang.

Wer jetzt eine Aufzugtür öffnet, **steigt direkt in die Kabine ein** (`Game::enterCab()`):
Tür auf, Spieler in die Kabine, Blick zur Kabinentür, Ding — und das Etagenpanel
(1 – 4) hat 6 s Zeit, bevor der Aufzug von selbst losfährt. Neu dafür:
`World::cabInRoom()` und `World::cabForDoor()`.

### Tests & Werkzeuge
- 4 neue Tests in `test_multiplayer.py`: Koop-Port liefert Lobby und Spielseite und
  eben **nicht** den Rest der API; die drei Ports sind verschieden; jeder Handshake-
  Fehler nennt seinen Grund; ein zweiter Versuch auf derselben Leitung klappt.
  Gesamt **162 Tests grün**.
- `ECHO.exe -nettest <adresse> [CODE]` prüft jetzt zwei Versuche hintereinander
  (erst absichtlich auf einen geschlossenen Port, dann richtig) und fällt damit auf
  genau den behobenen Handshake-Fehler herein, falls er zurückkommt.
- `ECHO.exe -seeds N` zählt Aufzugtüren, Kabinen und blockierte Zugänge.

## [3.33.0] — 2026-07-30

### Neu — Online-Multiplayer für alle drei Spiele
- **Serverautoritativer Koop-Server im Jon-Backend**
  (`backend/app/services/multiplayer_service.py`): Lobbys mit 6-stelligem
  Freundschaftscode (Alphabet ohne `O/0/I/1`), 20-Hz-Tick, delta-komprimierte
  Snapshots, zuverlässige Event-Liste mit Cursor-Ack, Heartbeat/Ping, Paketverlust-
  Schätzung, Reconnect-Fenster von 150 s und Persistenz nach
  `DATA_DIR/multiplayer/<CODE>.json` — eine Sitzung übersteht einen Backend-Neustart.
- **Zwei Transporte, ein Protokoll**: WebSocket `/api/mp/ws` für die Blockwelt im
  Browser, roher TCP-Port **8759** (4-Byte-Längenpräfix + JSON) für ECHO und AETHERIA.
  REST daneben: `/api/mp/create`, `/api/mp/join`, `/api/mp/lobby/{code}`,
  `/api/mp/status`, `/api/mp/info`.
- **Server hat die Autorität**: Bewegung wird gegen ein Spielprofil geprüft
  (Höchstgeschwindigkeit, Fallgeschwindigkeit, Weltgrenzen) — unmögliche Sprünge werden
  mit `correct` zurückgesetzt, nach 40 Verstößen fliegt der Client. Blöcke, Türen,
  Hebel, Schalter, Rätsel, Items, NPCs, Quests, Lichter, Timer und Checkpoints landen
  nur über geprüfte `act`-Nachrichten im Weltzustand (Reichweite, Whitelist,
  Token-Bucket-Ratenbegrenzung). Inventare bleiben privat, geteilt wird nur der
  Weltzustand.
- **Gleichzeitiger Start**: Host drückt Start → alle laden → jeder meldet
  `scene ready` → der Server gibt `spawn` frei. Niemand läuft allein los.
  Szenenwechsel und Wiedereinstieg laufen über dieselbe Barriere; wer mitten im Spiel
  wieder reinkommt, spawnt sofort an seiner letzten Position.

### Neu — Blockwelt: Koop im Browser
- **Online-Menü** (Knopf im Startbildschirm oder `O`): Spiel erstellen, Spiel
  beitreten, Lobby mit Code, Spielerliste, Ready, Start, Ping, freie Plätze.
  Beitreten akzeptiert `AB39KD` und `AB39KD@host:8756`.
- **Eigenes 3D-Modell pro Spieler**: acht Paletten × vier Kopfbedeckungen, Gesicht als
  Pixel-Textur, Namensschild mit Ping-Punkt. Animationen für Idle, Laufen, Rennen,
  Ducken, Springen, Fallen, Schwimmen, Abbauen und Platzieren — interpoliert mit 110 ms
  Puffer, Extrapolation bis 280 ms, kein Teleportieren.
- **Gemeinsame Welt**: Blockänderungen, TNT-Zündung, Explosionen, Enderperlen,
  Team-Chat (`Z`) und Jons Bauaufträge werden synchronisiert. Jon ist
  host-autoritativ — Gäste schicken ihm ihre Wünsche, er baut, alle sehen es.
  Der Weltgenerator ist jetzt seedbar, beide Spieler bekommen dieselbe Landschaft.
- **Neu: Ducken mit Strg** (langsamer, tiefere Kameraposition) — auch synchronisiert.
- **Emotes mit `B`** (Winken, Nicken, Zeigen, Jubeln, Kopfschütteln): der Mitspieler sieht
  die Bewegung am Avatar, nicht nur einen Text.
- **Eigenes Icon**, im Code gezeichnet: isometrischer Grasblock mit Jons Goldkristall.
  Als Favicon und Apple-Touch-Icon in `blockwelt.html` (Canvas) und als PNG über
  `scripts/blockwelt_icon.py` für Website und PWA.

### Neu — ECHO & AETHERIA: Koop im Spiel
- **Netzwerk-Schicht in C++** unter `ECHO/src/net/`: eigener JSON-Parser/Writer
  (`Json.*`), WinSock-Client mit eigenem Thread und Längenpräfix-Frames
  (`NetClient.*`), Sitzungslogik mit Snapshot-Interpolation, Weltzustand, Reconnect
  und Backoff (`CoopSession.*`) sowie die Lobby-Oberfläche (`CoopUI.*`).
  `build.bat` linkt jetzt `ws2_32.lib`.
- **Menüpunkt „ONLINE KOOP"** in ECHO (Haupt- und Pausemenü) und
  **„ONLINE SPIELEN"** in AETHERIA: Code erstellen oder eintippen, Namenswahl,
  Spielerliste mit Ping, Bereit/Start, Lobby schließen. Im Spiel zeigt eine Ecke
  oben rechts alle Mitspieler mit Ping; bei Abbruch blinkt ein Reconnect-Banner.
- **Mitspieler sichtbar**: Remote-Spieler nutzen das vorhandene Menschen-Rig mit
  eigenem Typ pro Slot, Pose je Animationszustand und Blick zum Zuhörer.
- **Synchronisiert**: ECHO überträgt Türen, Lichtschalter, Items und Checkpoints;
  AETHERIA Ernten, Dorfbesuche, Quests, Kampftreffer und den Tag-Nacht-Zyklus
  (Host gibt die Zeit vor). Fortschritt wird alle 45–60 s als Checkpoint gesichert.
- **Diagnose**: `bin/ECHO.exe -nettest 127.0.0.1:8759 [CODE]` verbindet sich headless,
  legt eine Lobby an bzw. tritt bei und schreibt das Ergebnis in `echo.log`.

### Neu — ECHO: Jumpscares mit eigenen Modellen
- **Neues Kreaturen-Rig** (`ECHO/src/world/Horror.*`): 19 Teile, überlanger Schädel mit
  tiefen Augenhöhlen, aufgerissener Kiefer mit Zähnen, freiliegender Rippenbogen,
  überlange Arme mit Krallenhänden, vier Archetypen (`GAUNT`, `CRAWLER`, `BANDAGED`,
  `LONGARM`) und Animationsmodi Starren, Zucken, Zuschlagen, Kriechen, Schreien, Hängen.
- **Garantiert mindestens ein Schreck pro Flur** (`ECHO/src/ai/Jumpscare.cpp`): jeder
  Korridor wird genau einmal benutzt, dann gemerkt. Sechs Auslöser — Rennen aus der
  Tiefe des Flurs, Auftauchen im Rücken beim Umdrehen, Herausbrechen aus einer Seitentür,
  Fall von der Decke, Kriechen über den Boden, Lauern an der Wandkante.
- **Und es wird laut**: fünf neue synthetisierte Klänge (`SFX_SCREAM`, `SFX_SCREECH`,
  `SFX_SLAM_HIT`, `SFX_BREATH_CLOSE`, `SFX_BONE_CRACK`) — verzerrter Schrei mit
  Formantfiltern, Bass-Drop mit Metallnachhall, nasses Atmen direkt am Ohr. Dazu
  Licht aus im ganzen Raum, Taschenlampen-Ausfall, harter Kamerawackler, Blickzwang zur
  Kreatur, roter Blitz und Tinnitus-Ton.

### Neu — ECHO: Wegweiser mit H
- **`H` öffnet und schließt** den direkten Weg zum Ziel (`ECHO/src/game/Guide.*`):
  Breitensuche über den Raum-Graph zum Kampagnenziel, sonst zum nächsten Aufzug oder
  Treppenhaus. Der Pfad wird als Markerkette durch die Türen gezeichnet, der nächste
  Abschnitt hervorgehoben, Treppen gelb, Aufzüge grün. Oben mittig Ziel, Restdistanz
  und Zahl der Abschnitte; ohne offenen Weg sagt er das auch.

### Behoben
- **Emote, Blickrichtung, Animations-Layer und Trefferpunkte gingen sofort wieder verloren**:
  der Server hat sie bei jedem Bewegungspaket auf den Standardwert zurückgesetzt, weil das
  Paket diese Felder nicht mitschickt. Jetzt werden nur Felder überschrieben, die im Paket
  wirklich enthalten sind — mit Wertegrenzen pro Feld.
- **Backend starb, wenn Port 8758 belegt war**: uvicorn beendet sich bei einem fehlgeschlagenen
  Bind mit `sys.exit(3)`, und `SystemExit` ist keine `Exception` — das `except Exception`
  im P2P-Chat-Server hat es also nicht gefangen und der ganze Prozess starb beim Start.
  Trat auf, sobald eine zweite Jon-Instanz lief. Jetzt fangen Chat- und Koop-Server
  `SystemExit` mit, melden den belegten Port und lassen nur den einen Dienst aus.

### Geändert
- FelWorks Game Collection auf **1.1.0**, `ECHO/jon-spiele.json` beschreibt Koop,
  Jumpscares und die H-Taste.
- Website: neuer Abschnitt **„Zusammen spielen"** mit Ablauf, Lobby-Vorschau und sechs
  Kacheln zur Technik, Koop-Link in der Navigation, aktualisierte Spielkarten und das
  neue Blockwelt-Icon.
- 157 Tests grün (28 neue in `backend/tests/test_multiplayer.py`), darunter ein Test, der
  die Multiplayer-Routen gegen die echte `create_app()` prüft.

## [3.32.0] — 2026-07-28

### Neu — Jon macht PowerPoints
- **`create_pptx`** baut eine fertige `.pptx` (16:9) mit neun Layouts: `title`,
  `bullets`, `cards`, `stat`, `two_columns`, `image`, `quote`, `timeline`, `closing` —
  je mit Sprechernotizen, Karten, nummerierten Kreisen, großen Kennzahlen und
  automatischer Schriftgrößen-Anpassung bei langen Titeln.
- **Elf Farbwelten** (`midnight`, `ocean`, `forest`, `sage`, `teal`, `coral`,
  `terracotta`, `berry`, `cherry`, `charcoal`, `gold`) mit abgestimmten Werten für
  Fläche, Text, Akzent und gedämpften Text.
- **Neuer Skill `powerpoint`**: Aufbau einer Präsentation, Layout-Tabelle, Themenwahl,
  Regeln (max. 5 Punkte pro Folie, Layouts abwechseln, dunkle Anker-Folien) und
  Checkliste. Jon liest ihn vor dem Bauen und hält sich daran.
- **`read_pptx`** liest vorhandene Präsentationen samt Notizen — zum Zusammenfassen oder
  Weiterbauen.
- Fehlt die Titelfolie, wird sie ergänzt; fehlt ein Bild, bleibt die Folie heil.
  Abhängigkeit `python-pptx` liegt der Installer-Version bei.

### Geändert — Jon Code bleibt im Ordner und schreibt direkt in die Datei
- **Nur der geöffnete Projektordner**: zusätzlich zur bestehenden Pfad-Sperre werden jetzt
  auch Shell-Ausbrüche (`cd ..`, `pushd`, `Set-Location C:\…`, `cd ~`) blockiert, bevor
  der Befehl läuft. Im Code-Modus bekommt Jon außerdem nur noch die 23 Projekt-Werkzeuge
  (Dateien, Suche, Shell, Git, Web) — Mail, Musik, Smarthome, Kalender & Co. fallen weg.
- **Genannte Dateien**: „schreib mir in index.html …" — Jon sucht die Datei im Projekt,
  bekommt Pfad und Inhalt in den Kontext und ändert genau sie. Mehrere Treffer werden
  benannt, fehlende Dateien legt er an.
- **Geöffnete Datei als Kontext**: Pfad und Inhalt der im Editor offenen Datei gehen mit;
  „hier", „da" und „in der Datei" beziehen sich darauf. Ungespeicherte Änderungen werden
  vor dem Senden automatisch gespeichert, ein Chip im Chat zeigt die aktive Datei.
- **Projektbaum statt Ordnerliste**: der System-Prompt enthält jetzt zwei Ebenen des
  Projekts (ohne `node_modules`, `dist`, `.venv` …), damit Jon Dateien direkt findet.
- **Bessere Coding-Prompts**: Code kommt in die Datei statt in den Chat, keine Rückfrage
  vor dem Schreiben, keine Kommentare im Code (außer gewünscht), Stil und Konventionen des
  Projekts werden übernommen.
- **Design-Vorgabe (Liquid Glass)**: für alles Sichtbare gibt Jon sich jetzt Mühe —
  halbtransparente Flächen mit `backdrop-filter`, Tiefe im Hintergrund, Design-Tokens,
  fluide Typografie, Hover-/Fokus-Zustände, Hell und Dunkel, Kontrast ≥ 4.5:1,
  `prefers-reduced-motion`, keine externen CDNs. Hat das Projekt schon ein Design, fügt er
  sich dort ein.

## [3.31.0] — 2026-07-28

### Neu — Spiele in Jon (FelWorks Game Collection)
- **Werkzeuge → Spiele**: neuer Abschnitt im Werkzeuge-Menü plus Übersichtsfenster mit
  einer Karte je Spiel — Vorschaubild, Titel, Genre, Beschreibung, Steuerung, Version,
  Herausgeber, Baudatum und Status (bereit · läuft · wird gebaut · Fehler). Gestartet
  wird ausschließlich per Klick auf **Starten**; beim Start von Jon öffnet sich kein
  Spielfenster.
- **ECHO** (Psychological Horror) und **AETHERIA** (Fantasy-Open-World-RPG) laufen als
  eigener Prozess in einem eigenen Fenster, die **Blockwelt** öffnet sich in einem neuen
  Tab. Jon bleibt in allen Fällen offen und bedienbar.
- Neue Endpoints `GET /api/games`, `POST /api/games/{id}/start|stop|build` und
  `GET /api/games/{id}/vorschau`; laufende Spiele werden mitverfolgt und lassen sich aus
  der Karte heraus wieder beenden.
- **Erweiterbar ohne Code-Änderung**: `arcade_service` sucht neben Jon (und in `games/`)
  nach Ordnern mit einer `jon-spiele.json` — Titel, Icon, Vorschaubild, Exe,
  Startparameter und optionales Bau-Skript stehen dort drin.
- **Fehlerbehandlung**: fehlende Spieldatei, sofortiger Absturz, fehlende Build-Tools
  oder ein blockiertes Browser-Fenster ergeben eine verständliche Meldung in der Karte
  statt eines Absturzes. Ist ein Spiel noch nicht kompiliert, baut der **Bauen**-Knopf es
  im Hintergrund.
- `start-jon.bat` bleibt der einzige Einstiegspunkt und startet mit dem Backend auch den
  Spiele-Dienst; es meldet beim Start, welche Spiele bereit sind.
- Installer und ZIP liefern die Spiele mit (`resources/ECHO`), die Website stellt sie mit
  Screenshots vor.

### Geändert
- Herausgeber der Downloads ist jetzt **FelWorks** (NSIS-Installer, `Jon.exe` und
  `jon-backend.exe`).
- Der Menüpunkt „Blockwelt-Spiel" ist von „Spaß & mehr" in den neuen Abschnitt „Spiele"
  umgezogen; `/spiel` öffnet sie weiterhin direkt.

## [3.30.1] — 2026-07-23

### Behoben — Downloads werden seltener fälschlich als schädlich gemeldet
- Die Warnungen kamen von SmartScreen/Virenscanner-Heuristiken, die bei neuen,
  unsignierten Programmen anschlagen — nicht von echter Schadsoftware. Dagegen getan:
  `jon-backend.exe` trägt jetzt vollständige Datei-Metadaten (Produkt, Version,
  Herausgeber, Open-Source-Hinweis), läuft als normales Konsolenprogramm statt als
  „unsichtbare" Fenster-Anwendung (ein bekannter Heuristik-Auslöser; die App versteckt
  die Konsole selbst) und der Installer nennt einen echten Herausgeber. Neue Downloads
  als Release v3.30.1, das alte Release ist entfernt.
- Die Download-Seite erklärt jetzt ehrlich, warum die SmartScreen-Meldung erscheinen
  kann und wie man sie bestätigt (Weitere Informationen → Trotzdem ausführen).
- Ganz verschwinden kann die Erst-Warnung nur mit einem kostenpflichtigen
  Code-Signing-Zertifikat oder wachsender Download-Reputation.

## [3.30.0] — 2026-07-22

### Neu — Fertige Downloads: Jon-Setup.exe und portable ZIP
- Jon gibt es jetzt fertig gebaut zum Herunterladen — **Jon-Setup.exe** (Installer mit
  Startmenü- und Desktop-Verknüpfung) und **Jon-Windows.zip** (portabel: entpacken,
  `Jon.exe` starten). Beide enthalten die Jon App, Mini Jon und das komplette Backend,
  das automatisch mitstartet. API-Einstellungen trägst du direkt in der App ein
  (Zahnrad → Konten) — sie werden lokal gespeichert, keine `.env` nötig.
- Die Downloads liegen als GitHub-Release (zu groß fürs Repo); die Website verlinkt auf
  `releases/latest/download/…` und zeigt damit immer die neueste Version. Auf der
  Download-Seite wählst du frei zwischen .exe und .zip, der Quellcode bleibt daneben.
- Gebaut wird beides mit `python scripts/build_installer.py` (ersetzt
  `build-installer.bat`). `jon.bat` ist ebenfalls entfernt — die CLI startet mit
  `python -m app.cli` im backend-Ordner. `start-jon.bat` und `autostart-jon.bat`
  bleiben (Entwickler-Start + Autostart-Funktion).

### Neu — /goal-Modus in Jon Code
- In Jon Code startest du mit **`/goal Zielbeschreibung`** den Ziel-Modus: Jon sieht
  sich das Projekt an, zerlegt dein Ziel in 2-8 Schritte, arbeitet sie nacheinander ab
  und zeigt den Fortschritt als Checkliste (⚪ offen, ▶️ läuft, ✅ fertig, ❌ Fehler).
- Ist das Ziel zu unklar, stellt Jon genau eine Rückfrage — deine Antwort unten im Chat
  genügt, dann plant er weiter. Schlägt ein Schritt fehl, analysiert Jon den Fehler und
  versucht es einmal erneut; danach bricht er sauber ab. Am Ende gibt es immer einen
  Abschlussbericht: was erledigt wurde, was offen blieb, was du prüfen solltest.
- Über den Stopp-Knopf im Ziel-Panel brichst du jederzeit ab.

### Neu — Über-mich-Seite auf der Website
- Die Website hat jetzt eine „Über mich"-Sektion über Felix und das Jon-Projekt.

## [3.29.0] — 2026-07-22

### Behoben — Mini Jon mit eigenem Anbieter + Ollama ohne Tool-Fehler
- Mini Jon (und Telegram) können jetzt einen **eigenen Anbieter** nutzen, auch wenn Jon
  selbst auf einem anderen läuft: Wählst du in „Mini Jon anpassen" z. B. **nvidia**,
  gilt deine Auswahl immer — die Folge-Regel („übernimmt Jons Anbieter") greift nur
  noch, wenn kein eigener Anbieter gewählt ist. Damit läuft Mini Jon mit NVIDIA,
  während Jon Ollama nutzt.
- **Ollama-Fehler behoben**: Modelle ohne Tool-Unterstützung (z. B. `gemma3:270m`)
  brachen mit `400 — does not support tools` ab. Jon wiederholt die Anfrage jetzt
  automatisch ohne Tools und merkt sich das Modell, sodass künftige Anfragen direkt
  ohne Tools laufen. Das Modell antwortet dann ganz normal (kann nur keine
  PC-Werkzeuge aufrufen).

## [3.28.0] — 2026-07-21

### Entfernt — kein eigener Veröffentlichungsdienst mehr
- Die selbstgebaute Netlify-Anbindung (Veröffentlichen-Seite `/veroeffentlichen`, das
  Werkzeug „Website hochladen", `netlify_service.py`, die `/api/netlify/*`-Routen,
  `scripts/netlify_paket.py`) ist komplett entfernt. Die Website wird wieder ganz normal
  bei Netlify veröffentlicht.
- **So geht's** (einmal einrichten, dann automatisch): Bei Netlify „Add new site →
  Import an existing project → GitHub" wählen und das Repo `Jon---AI` verbinden. Das
  Root-`netlify.toml` (`publish = "website"`) sorgt dafür, dass Netlify nur den
  `website/`-Ordner veröffentlicht und den Rest (`node_modules`, `backend/dist`)
  ignoriert. Jeder `git push` deployt dann automatisch — kein „Access Denied" mehr.
- Manuell geht weiterhin: nur den **`website/`-Ordner** (nicht den ganzen Jon-Ordner)
  auf `app.netlify.com/drop` ziehen.

## [3.27.0] — 2026-07-21

### Geändert — Jon-Ordner per Drag&Drop veröffentlichen (Werkzeug-Fenster entfernt)
- Das Werkzeug-Fenster „Website hochladen" aus 3.26.0 ist wieder entfernt. Stattdessen
  gibt es die Seite **`http://127.0.0.1:8756/veroeffentlichen`** (öffnet auch mit
  `/website` im Chat): Dort ziehst du den **kompletten Jon-Ordner** auf die Fläche —
  Jon nimmt die Dateien direkt von der Festplatte, baut jon.zip frisch und schickt nur
  die Website (~1 MB) zu Netlify. Live in Sekunden, mit Link.
- Zum „Access Denied" bei netlify.com: Beim Ziehen des ganzen Ordners lädt der Browser
  dort über 1 GB hoch (node_modules, backend/dist); nach vielen Minuten läuft Netlifys
  Upload-Freigabe ab und Netlify blockt mit „Access Denied". Das lässt sich auf
  netlify.com nicht abstellen — die Veröffentlichen-Seite umgeht es, weil nur die
  Website selbst hochgeladen wird. Ein frischer Deploy darüber ersetzt auch einen
  hängengebliebenen kaputten Deploy.

## [3.26.0] — 2026-07-21

### Neu — Website hochladen direkt in der App (Drag&Drop des Jon-Ordners)
- Neues Werkzeug **🧰 Werkzeuge → 🌐 Website hochladen** (auch `/website`, `/netlify`,
  `/hochladen`): Zieh einfach deinen kompletten Jon-Ordner auf die Fläche (oder klick) —
  Jon baut `website/jon.zip` frisch und lädt nur den Website-Inhalt (~1 MB) über die
  Netlify-API hoch. Fertig in Sekunden, mit Live-Link zur Website.
- Einmalige Einrichtung: Netlify Personal Access Token einfügen
  (app.netlify.com/user/applications) und Website aus der Liste wählen. Der Token wird
  nur lokal gespeichert.
- `netlify-hochladen.bat` ist wieder entfernt — kein Skript mehr nötig, alles läuft in
  der App. (`scripts/netlify_paket.py` bleibt als Alternative ohne App.)
- Hintergrund: Drag&Drop des ganzen Ordners auf netlify.com lud über 1 GB
  (`backend/dist`, `node_modules`) durch den Browser — deshalb 15 Minuten und Abbruch.

## [3.25.0] — 2026-07-21

### Neu — Netlify-Upload in Sekunden statt 15 Minuten
- Neues Skript `netlify-hochladen.bat` (nutzt `scripts/netlify_paket.py`): baut
  `website/jon.zip` frisch, packt den kompletten Website-Inhalt in eine kleine
  `netlify-upload.zip` (wenige MB) und öffnet Explorer + Netlify. Die Zip einfach auf
  die Deploy-Fläche ziehen — Netlify entpackt sie automatisch, fertig in Sekunden.
- Hintergrund: Beim Hochladen des ganzen Jon-Ordners gingen über 1 GB mit
  (`backend/dist`, `node_modules`) — deshalb dauerte der Upload 15 Minuten und brach ab.

### Neu — 10 weitere Träume für Mini Jon, alle mit passender Visualisierung
- Seifenblasen-Meer, Sternen-Express, leuchtende Quallen, Glücksklee-Garten,
  Himmel in Regenbogenfarben anmalen, Schneemann im Sommer, Wettrennen gegen Minka
  und Rocky, Sternschnuppen mit dem Kescher fangen, Mond-Kekse backen und ein
  Glühwürmchen-Orchester dirigieren — Mini Jon träumt jetzt aus 20 Träumen.

## [3.24.0] — 2026-07-21

### Neu — Mini Jons Träume werden visualisiert
- Während Mini Jon schläft, zeigt die Traum-Blase jetzt zu jedem Traum eine **kleine
  animierte Szene** (Canvas) über dem Traumtext: goldene Wolken mit fliegendem Emil,
  „so groß wie Papa Jon", springende Schäfchen mit Binär-Zähler, ein Kakao-Meer mit
  Marshmallows, der Blockwelt-Pokal mit Konfetti, hüpfende Pixel-Schäfchen, Surfen auf
  der Regenbogen-Datenwelle, ein leuchtendes Erinnerungs-Sternbild, ein Schloss aus
  goldenen Bausteinen, das sich Stein für Stein baut, und eine Abenteuer-Rakete.
- Die Animation läuft nur, solange er wirklich schläft und der Traum sichtbar ist,
  und stoppt beim Aufwachen sofort.

## [3.23.0] — 2026-07-21

### Neu — Mini Jon schläft mit Schlafmaske und träumt
- Wenn Mini Jon schläft (z. B. weil du länger als 5 Minuten weg bist oder per
  Telegram `/schlafen`), setzt er sich jetzt eine **Schlafmaske** auf — dunkel mit
  Goldrand, kleinem Mond und Sternchen.
- In der Sprechblase, wo sonst seine Antworten stehen, wird währenddessen sein
  **Traum** angezeigt (💭, wechselt alle paar Sekunden) — in einem eigenen,
  verträumten Blau-Stil.
- Die **Zzz** schweben jetzt direkt an seinem Kopf statt weit daneben.
- Ist der PC länger als 5 Minuten unbenutzt (AFK), schläft Mini Jon automatisch ein
  und wacht auf, sobald du zurück bist oder ihn ansprichst.

## [3.22.1] — 2026-07-21

### Behoben — Privater Browser jetzt auch auf dem Raspberry Pi
- Der private Browser lief backendseitig schon auf dem Pi (die Seite `/privat` und der
  Proxy `/api/private/proxy` werden direkt vom Backend ausgeliefert), aber `pi-update.sh`
  hat die Web-App nach dem `git pull` **nie neu gebaut** — dadurch erschienen neue
  Frontend-Funktionen (wie der „Privater Browser"-Knopf unter Werkzeuge) auf dem Pi nicht.
  `pi-update.sh` baut die Web-App jetzt neu; schlägt der Bau fehl (oft zu wenig RAM), wird
  die vorige Oberfläche automatisch wiederhergestellt statt zerstört.
- Beide Pi-Skripte zeigen jetzt die direkte Adresse des privaten Browsers an
  (`http://<IP>:8756/privat`). Diese Seite braucht **keinen** Web-App-Build und funktioniert
  auf dem Pi auch dann, wenn der React-Bau nicht durchläuft.

## [3.22.0] — 2026-07-21

### Geändert — Privater Browser öffnet jetzt in der App
- Der private Browser öffnet unter **🧰 Werkzeuge → 🕶️ Privater Browser** jetzt als
  eingebettetes Fenster **in der App** (Modal) statt in einem separaten Fenster/Tab —
  überall gleich, auch auf dem Raspberry Pi und in der Web-App. Ein Knopf „↗ Eigenes
  Fenster" öffnet ihn in der Desktop-App weiterhin als eigenes Fenster.
- `/privat`, `Strg+Alt+P` und das Tray-Menü öffnen ebenfalls diese In-App-Ansicht.
- **Mini Jon** öffnet den privaten Browser jetzt zuverlässig in der App: Ein Zuruf wie
  „privat", „inkognito", „öffne den privaten Browser" oder „privat surfen" holt Jon in
  den Vordergrund und öffnet den Browser direkt im Fenster. Die Browser-Seite kennt
  einen `embed`-Modus, der ihre eigene Titelleiste ausblendet, damit sie sauber in die
  App passt.

## [3.21.0] — 2026-07-21

### Neu — Privater Browser auch auf dem Pi & über Mini Jon
- **Web-/Pi-Version**: Der private Browser läuft jetzt auch ohne Electron. Das Backend
  liefert unter `/privat` eine eigenständige Browser-Seite (Tabs, Adress-/Suchleiste,
  DuckDuckGo, In-Memory — nichts wird gespeichert). Läuft Jon auf dem Raspberry Pi oder
  wird die Web-App im Browser geöffnet, startet über „Privater Browser"/`/privat` diese
  Seite in einem neuen Tab; in der Electron-App weiterhin das native Fenster.
- **Seiten-Proxy** (`/api/private/proxy`): Seiten werden über Jon geladen, damit sie sich
  im In-App-Browser überhaupt öffnen (X-Frame-Options/CSP-Frame-Sperren werden dabei
  umgangen, ein `<base>` und ein kleines Navigations-Skript werden eingefügt, sodass
  Links und Suchformulare im privaten Browser bleiben). Der Proxy speichert nichts, setzt
  `Cache-Control: no-store` und `Referrer-Policy: no-referrer` und blockt interne Adressen
  (Loopback, Link-Local, Cloud-Metadaten) gegen SSRF.
- **Mini Jon** öffnet den privaten Browser: Sag der Desktop-Figur z. B. „öffne den
  privaten Browser" oder „privat surfen", und Emil startet ihn für dich.

## [3.20.3] — 2026-07-21

### Neu — Privater Browser
Komplett privater Browser direkt in der Jon-App (Werkzeuge → 🕶️ Privater Browser,
`/privat` oder Strg+Alt+P, auch im Tray): eigenes Fenster im Jon-Design mit Tabs,
Adress-/Suchleiste und Mausrad-/Tastatur-Shortcuts (Strg+T/W/L/R, Strg+Tab). Alles läuft
in einer reinen In-Memory-Session — kein Verlauf, keine Cookies, kein Cache, keine
Logins landen auf der Festplatte; beim Schließen (und per 🧹 „Spuren löschen") wird
zusätzlich alles sofort gewischt. Suchen laufen standardmäßig über DuckDuckGo,
Berechtigungsanfragen (Kamera, Standort …) werden in diesem Fenster automatisch
abgelehnt, Popups öffnen als Tab statt als neues Fenster. Kein Konto, keine Anmeldung,
nichts verlässt den PC.

## [3.19.0] — 2026-07-21

### Neu — Telegram-Gruppen & schlafender Mini Jon
- **Gruppen-Chats mit mehreren Bots**: Jon und Mini Jon (eigener Bot-Token unter
  Verbindungen) lesen in Telegram-Gruppen alle Nachrichten mit und verstehen so den
  Gesprächskontext, antworten aber nur, wenn sie jemand mit ihrem `@Benutzernamen`
  erwähnt. Ein gemeinsamer Gruppen-Verlauf sorgt dafür, dass beliebig viele Bots in
  derselben Gruppe harmonieren — jeder kennt auch die Antworten der anderen. Neue
  Architektur `telegram_group_service.py` (GroupBot-Basisklasse, weitere Bots =
  Unterklasse). In Gruppen sind PC-Tools bewusst aus. Wichtig: bei @BotFather pro Bot
  `/setprivacy` → Disable, sonst liefert Telegram den Bots nur Erwähnungen und Befehle.
- **Mini Jon schläft**: neuer Status `wach`/`schläft` (`GET/POST /api/mini-jon/status`,
  Telegram `/schlafen` und `/aufwachen`). Schläft Emil, antwortet er in Telegram nicht
  mehr, sondern schickt eine generierte Schlaf-Animation (GIF im Jon-Design: geschlossene
  Augen, schwebende Zzz, ruhiges Atmen). Die Desktop-Figur schläft sichtbar mit:
  geschlossene Augen, gedimmtes Gesicht, Zzz und Atem-Animation; Blinzeln, Umschauen,
  Stimmungs- und Wellness-Impulse pausieren. Eine Nachricht an ihn weckt ihn auf.

## [3.18.1] — 2026-07-19

### Geändert — LAN-Pairing entfernt
Das Geräte-Pairing (6-stelliger Code bei `JON_LAN=1`) ist komplett entfernt. Wie früher
ist Jon mit `JON_LAN=1` einfach im eigenen WLAN für Handy und Smartwatch erreichbar, ohne
Kopplung — besonders praktisch auf dem Raspberry Pi ohne Bildschirm. Papierkorb und
Aktionsprotokoll bleiben unverändert erhalten.

## [3.18.0] — 2026-07-19

### Neu — fünf weitere Ideen
- **Standort-Erinnerungen über Telegram** — benannte Orte per geteiltem Standort merken
  („Ort speichern: Supermarkt") und Geo-Erinnerungen anlegen („Erinnere mich an Milch,
  wenn ich beim Supermarkt bin"). Während ein Live-Standort läuft, meldet sich Jon, wenn
  du am Ort bist.
- **Zwischenablage-Aktionen** — die Clipboard-Historie erkennt URLs, E-Mails, Telefon,
  IBAN, Adressen und Code und bietet passende Aktionen (öffnen, Maps, anrufen, merken,
  erklären lassen …).
- **Fokus-Statistik** — Jon erfasst lokal, in welchen Apps du wie lange bist; `/fokus`
  zeigt die letzten 7 Tage als Balkendiagramm, fließt in den Wochenrückblick ein.
  Standardmäßig aus, alles bleibt auf dem PC.
- **Pomodoro-Coach** — Mini Jon zeigt ein Timer-Badge, wird in Pausen fröhlich und gibt
  Bewegungstipps.
- **Meeting-Mitschrift** — `/meeting` nimmt System-Ton und Mikrofon (bevorzugt Fifine)
  gleichzeitig auf, transkribiert live und erstellt beim Stopp eine Zusammenfassung mit
  To-dos, die in den Kalender wandern.

## [3.17.0] — 2026-07-19

### Neu — fünf frische Ideen
- **Mini Jon tanzt zur Musik** — läuft Spotify oder Amazon Music, wippt Mini Jon im Takt,
  zeigt Notensymbole und färbt sich in einer Song-Farbe; stoppt die Musik, wird er sofort
  wieder normal (`/api/music/now`).
- **Trink- & Steh-Erinnerungen** — Mini Jon meldet sich alle 90 Minuten sanft (Wasser,
  aufstehen, durchatmen). Abschaltbar im Zahnrad-Menü.
- **Lange Telegram-Sprachnachrichten** — ab 200 Zeichen fasst Jon sie in Stichpunkten
  zusammen und trägt genannte Termine automatisch in den Kalender ein.
- **Vorlese-Modus** — markierten Text mit **Strg+Alt+V** an Mini Jon geben, er liest ihn
  mit seiner Stimme vor.
- **Automatische Datei-Ablage** — neue Downloads wandern regelbasiert in Unterordner
  (Bilder, Dokumente, Musik, Rechnungen, Screenshots …), alles per Papierkorb
  wiederherstellbar. Standardmäßig aus, Toggle im Zahnrad-Menü.

### Verbessert
- **Sprachwechsel** greift jetzt wirklich live (Deutsch/English) und ist auf mehr
  Oberflächen-Bereiche ausgeweitet.
- README mit Banner-Bild von Jon und Mini Jon, englische README ebenso.

## [3.16.0] — 2026-07-19

### Neu — Sieben große Funktionsblöcke

**Vertrauen: Papierkorb, Aktionsprotokoll, LAN-Pairing.** Löschen, Überschreiben und
Verschieben von Dateien sichern das Original vorher in `data/trash` (30 Tage). `/undo`
stellt die letzte Dateiaktion wieder her, `/papierkorb` (Alias `/trash`) listet den Inhalt.
Jeder Tool-Aufruf wird mit Quelle (App, Mini Jon, Telegram, Automation, Watcher) in einer
SQLite-Tabelle protokolliert; `/log` zeigt die letzten Aktionen mit Filter, das
Tagesbriefing fasst zusammen, was Jon in Abwesenheit getan hat. Bei `JON_LAN=1` muss sich
jedes neue Gerät per 6-stelligem Code koppeln, bevor es Zugriff bekommt; gekoppelte Geräte
sind im Zahnrad-Menü verwaltbar.

**Sprach-Erlebnis.** Wake-Word „Jon" läuft offline über openWakeWord im Backend, mit
automatischem Fallback auf die bisherige Erkennung. Barge-in: sprichst du, während Jon
redet, stoppt er sofort. Empfindlichkeit im Zahnrad-Menü einstellbar. Gilt für Jon und
Mini Jon.

**Browser-Automatisierung.** Neue Tool-Gruppe `browser_goto/click/fill/read/screenshot/
back/close` steuert ein sichtbares Chromium-Fenster (Playwright). Jon liest Seiten Schritt
für Schritt, klickt per Selektor oder sichtbarem Text und meldet Fehler verständlich.

**Jon-Kalender.** Eigener lokaler Kalender (📅-Knopf) mit Monats-/Wochenansicht. Jon trägt
Termine per Zuruf ein („Trag Freitag 15 Uhr Zahnarzt ein"), warnt bei Konflikten, zeigt
Automationen, Erinnerungen und den ICS-Kalender farblich integriert. `/kalender` zeigt 7
Tage; Termine mit Uhrzeit melden sich im Chat und als Benachrichtigung.

**Echtes Auto-Update.** `/update` sichert `data/`, holt per git die neue Version,
installiert nur Geändertes nach und startet neu (auf dem Pi via `systemctl restart jon`).

**Englisch & Deutsch.** Sprachumschalter im Zahnrad-Menü stellt Oberfläche und Jons
Antworten auf Englisch um. Neue `README.en.md`.

**Windows-Installer.** `build-installer.bat` bündelt das Backend mit PyInstaller zu einer
eigenständigen `jon-backend.exe` und paketiert per NSIS eine `Jon-Setup.exe` — kein Python,
kein Node, kein Terminal nötig. Ersetzt `installer-bauen.bat`.

### Auch dabei
- Telegram: Fotos werden per Vision-Modell analysiert; einfache Maus-/Tastaturbefehle
  („klick", „schreibe …", „drücke enter") lösen sofort das echte Tool aus.

## [3.15.1] — 2026-07-16

### Behoben — Web-App-Build scheiterte auf dem Raspberry Pi
`postcss.config.js` nutzte ESM-Syntax (`export default`) in einer CommonJS-Datei. Neuere
Node-Versionen am PC erkennen das automatisch, Node 18 auf dem Pi bricht mit
`SyntaxError: Unexpected token 'export'` ab. Die Datei heißt jetzt
`postcss.config.mjs` und ist damit auf jeder Node-Version eindeutig ESM.

## [3.15.0] — 2026-07-16

### Neu — Always-on-Jon auf dem Raspberry Pi
Das Backend läuft jetzt auf Wunsch auf einem **Raspberry Pi (ab Pi 4)** und ist damit für
Handy-PWA und Smartwatch **rund um die Uhr** erreichbar, auch wenn der PC aus ist. Ein
Befehl genügt: `bash pi-installieren.sh` installiert die Abhängigkeiten (neue schlanke
`backend/requirements-pi.txt` ohne PC-Steuerungs-Bibliotheken), setzt `JON_LAN=true`, baut
die Web-App für `http://<Pi-IP>:8756/app` und richtet einen **systemd-Dienst** ein, der
beim Hochfahren automatisch startet und bei Abstürzen neu startet. Der PC-Start über
`start-jon.bat` funktioniert unverändert weiter. Neue `.gitattributes` sorgt dafür, dass
Shell-Skripte mit Linux-Zeilenenden ausgeliefert werden.

## [3.14.3] — 2026-07-16

### Behoben — Mini Jon hatte kein Gesicht mehr
Bei den Stimmungen **nachdenklich/müde** (z. B. nach mehr als 20 Stunden ohne Kontakt)
und bei der Augen-Einstellung **„Verschlafen“** werden Augen und Mund als waagerechte
Linien gezeichnet. Der goldene Farbverlauf konnte auf solche Linien ohne Höhe nicht
angewendet werden — der Browser zeichnete sie dann **gar nicht**, und Mini Jon war nur
noch ein leerer Kreis. Der Farbverlauf nutzt jetzt feste Koordinaten
(`gradientUnits="userSpaceOnUse"`), damit hat Mini Jon in jeder Stimmung ein Gesicht.

## [3.14.2] — 2026-07-15

### Neu — Jon im WLAN erreichbar (für Handy & Smartwatch)
Wenn in der `.env` `JON_LAN=true` steht, gibt `start-jon.bat` beim Start automatisch die
nötige **Windows-Firewall-Regel für Port 8756 frei** (einmalige Admin-Nachfrage) und zeigt
im Fenster die **WLAN-Adresse deines PCs** an (z. B. `http://10.0.0.253:8756`) samt
Test-Link `…/api/health`. Damit kannst du von Handy oder Smartwatch im selben WLAN auf Jon
zugreifen. Hinweis: Nur im eigenen, vertrauenswürdigen WLAN aktivieren.

## [3.14.1] — 2026-07-15

### Behoben — „Mit Windows starten" funktioniert jetzt zuverlässig
Der Autostart startet beim Hochfahren jetzt **Backend UND App** sicher. Vorher konnte
der Start abbrechen, wenn das Backend beim Login nicht schnell genug hochkam (das
Start-Skript blieb dann mit einer Fehlermeldung hängen und die App startete nie). Ein
neuer, robuster Autostart-Launcher (`autostart-jon.bat`) startet das Backend, wartet
kurz und nicht blockierend und öffnet dann in jedem Fall die App — ohne Nachfragen oder
Abbrüche. Getestet: Server ist nach ~2 Sekunden erreichbar.

## [3.14.0] — 2026-07-15

### Geändert — Mitarbeiten: App auswählen statt Text tippen
Statt einzutippen, woran du arbeitest, **wählst du jetzt eine App aus einer Liste**
(VS Code, Word, Google Docs, Obsidian, Excel u. v. m. — oder „Egal welche Arbeits-App").
Mini Jon **prüft alle 5 Minuten, ob genau diese App offen ist**. Sobald sie offen ist,
fragt er — wie gewohnt **hörbar mit seiner Stimme und sichtbar per Sprechblase samt
Ja-/Nein-Knopf** — ob er mitarbeiten soll. Bei „Ja" schaut er ab und zu über deine
Schulter und gibt Tipps, bei „Nein" hält er sich raus und fragt später nochmal.

## [3.13.2] — 2026-07-15

### Neu — Das Haustier lebt
- **Klick aufs Tier** lässt jetzt einen Schwarm Herzchen über seinem Kopf aufsteigen.
- **Der Hund bellt** ab und zu („Wuff!"), **die Katze miaut oder schnurrt** — mit echten,
  im Browser erzeugten Tiergeräuschen und einer kleinen Sprechblase.
- Klickst du das schlafende Tier an, wacht es auf.

### Behoben
- Das Haustier ließ sich **nicht anklicken** — das Mini-Jon-Fenster war an der Stelle
  durchklickbar. Jetzt reagiert das Tier auf Klicks. Geräusche pausieren, wenn Mini Jon
  ausgeblendet ist.

## [3.13.1] — 2026-07-15

### Geändert — Aufgeräumte Kopfzeile
Die vielen einzelnen Knöpfe oben rechts sind jetzt alle im **„🧰 Werkzeuge"-Menü**
gebündelt (Jon Code, Humanisierer, Downloader, Freunde-Chat, Clipboard, Konten und alle
neuen Funktionen) — sauber in Abschnitte „Arbeiten", „PC & Medien" und „Spaß & mehr"
gruppiert. So passt alles auf den Bildschirm, egal wie schmal das Fenster ist. Neue
Freunde-Nachrichten zeigt jetzt ein Punkt direkt am Werkzeuge-Knopf. Nur die schnellen
Schalter (Mini Jon, Live Screen, Sprache, Einstellungen) bleiben direkt sichtbar.

## [3.13.0] — 2026-07-15

Zehn neue Funktionen. Alles im „🧰 Werkzeuge"-Menü oben rechts oder per Slash-Befehl.

### Neu — Mini Jon bekommt ein Haustier
Wähle in den Einstellungen eine **Katze (Minka)** oder einen **Hund (Rocky)** — das Tier
lebt bei Mini Jon. Wenn Jon gerade nichts zu tun hat, spielt er mit ihm: streicheln,
füttern, Ball werfen, kraulen. Bist du länger weg (AFK), schlafen beide friedlich (Zzz).
Dazu neu: Mini Jon kann jetzt optional **frei am unteren Bildschirmrand herumwandern**
statt fest in der Ecke zu stehen (ein-/ausschaltbar).

### Neu — Sprach-Tagebuch (`/tagebuch`)
Sprich einfach frei über deinen Tag — Jon transkribiert, gibt jedem Eintrag einen Titel
und Stichworte und legt ihn datiert ab. Später durchsuchbar: „Was war letzte Woche los?"

### Neu — Bildschirm-Erklärer (`/erklaer` · Strg+Alt+E)
Jon schaut sich per Vision deinen Bildschirm an und erklärt, was zu sehen ist — löst
Aufgaben, deutet Fehlermeldungen, übersetzt fremde Sprachen — und liest es dir vor.

### Neu — Ordner aufräumen mit Vorschau (`/aufraeumen`)
Jon sortiert Downloads, Desktop & Co. nach Typ oder Monat — zeigt aber **erst eine
Vorschau**, verschoben wird nichts ohne deinen Klick.

### Neu — Kochassistent (`/kochen`)
Sag, was du hast — Jon schlägt Gerichte vor und liest dir das Rezept **Schritt für Schritt
vor** (Hände frei), du gehst mit „Weiter" durch, mit Timer pro Schritt.

### Neu — Lern-Karteikarten (`/lernen`)
Jon macht aus einem Thema oder Text automatisch Karteikarten und quizzt dich ab, bewertet
deine Antworten sinngemäß und wiederholt Schwieriges öfter (Spaced Repetition).

### Neu — Pomodoro-Coach
25 Minuten Arbeit / 5 Minuten Pause im Wechsel; Mini Jon kündigt Pausen an, schlägt kurze
Dehnübungen vor und feiert jede geschaffte Runde.

### Neu — Haftnotizen (`/notizen`)
Schnelle, farbige Notizzettel direkt in Jon: anheften, abhaken, immer griffbereit.

### Neu — Passwort-Tresor (`/tresor`)
Ein lokal **verschlüsselter** Safe (AES/Fernet, PBKDF2) für Passwörter und Geheimnisse,
geschützt mit einem Master-Passwort, mit eingebautem Passwort-Generator. Alles bleibt
auf deinem PC, das Master-Passwort wird nirgends gespeichert, der Tresor sperrt sich nach
15 Minuten selbst.

### Neu — Universelle Suche (`/suche` · Strg+K)
Ein Suchfeld durchsucht gleichzeitig **Unterhaltungen, Gedächtnis, Tagebuch und
Wissensbasis** — Treffer aus dem Chat öffnest du mit einem Klick.

## [3.12.0] — 2026-07-15

### Neu — Blockwelt: 3D-Spiel mit Jon als Mitspieler
Ein komplettes Minecraft-artiges 3D-Spiel direkt in Jon (🎮 im Header oder `/spiel`):
unendliche Welt mit Biomen, Bauen, Abbauen, Schwimmen, TNT, Enderperlen — und **Jon
läuft als goldene Spielfigur mit dir herum**. Drück **T** und sag ihm, was er tun soll:
„Bau mir ein Haus aus Glas" · „Grab einen Pool" · „Bau drei Bäume und einen Turm" ·
„Folg mir" · „Spreng den Berg". Jon versteht freie Sprache über die KI, läuft zur
Baustelle, baut Block für Block sichtbar vor deinen Augen (Häuser, Türme, Pyramiden,
Brücken, Pools, Mauern, Bäume), gräbt, legt TNT mit Sicherheitsabstand — und antwortet
dir mit seiner echten Stimme. Funktioniert sogar ohne KI-Verbindung mit fester
Befehlserkennung.

### Neu — Telegram-Befehle
- **/stopp** bricht die laufende Aktion sofort ab — auch mitten in einer langen Antwort.
- Nach jeder Aufgabe listet Jon auf, **welche Befehle er wirklich ausgeführt hat**
  („✅ Ausgeführte Befehle: …").
- **/endstimme** schaltet Sprachnachrichten dauerhaft aus, /stimme wieder an.

## [3.11.0] — 2026-07-15

Acht neue Fähigkeiten, die es so in keiner anderen KI gibt.

### Neu — Mini Jon arbeitet mit
Mini Jon erkennt, wenn du in VS Code, Word, Google Docs, Obsidian & Co. arbeitest, und
fragt dich, ob er mithelfen soll. Sagst du ja, schaut er dir ab und zu über die Schulter
und gibt konkrete Tipps (Code-Fehler, Formulierung, nächster Schritt). Sagst du nein,
hält er sich raus und fragt später nochmal. Unter Einstellungen → „Mitarbeiten & Fokus"
stellst du ein, woran du gerade arbeitest (z. B. „mein Roman").

### Neu — Fokus-Buddy
Sag Jon „Starte einen Fokus für 30 Minuten fürs Lernen" — Mini Jon passt auf, meldet sich
freundlich, wenn du auf YouTube & Co. abdriftest, und führt eine Fokus-Statistik pro Tag.

### Neu — Schreib-Hotkey überall
Markiere Text in **jeder** App und drück **Strg+Alt+H** (oder **Strg+Alt+Rechtsklick**) —
Jon verbessert, humanisiert, übersetzt oder kürzt ihn und tippt das Ergebnis direkt an
dieselbe Stelle zurück.

### Neu — Telegram-Sprachnachrichten
Schick dem Telegram-Bot eine Sprachnachricht wie einem Freund — Jon versteht sie (Whisper)
und antwortet auf Wunsch (`/stimme`) mit seiner echten Stimme zurück.

### Neu — Guten-Morgen-Audio
Jon schickt dir jeden Morgen zur Wunschzeit eine persönliche Sprachnachricht auf Telegram:
Begrüßung, Wetter, Termine, Erinnerungen — wie eine kleine private Radioshow.

### Neu — Abend-Show
Auf Knopfdruck (🎙️ im Header oder `/show`) plaudern Jon und Mini Jon hörbar miteinander
über deinen Tag — zwei echte, unterschiedliche Stimmen im Dialog, mit deinen echten
Tagesdaten.

### Neu — Routine-Radar
Jon erkennt wiederkehrende Gewohnheiten (z. B. „du öffnest morgens fast immer Spotify")
und bietet über ein dezentes Banner an, das als Automation zu übernehmen — ein Klick, und
er macht es künftig selbst.

### Neu — Bildschirm-Zeitreise (Opt-in)
Aktivierbar unter Einstellungen: Jon merkt sich lokal, was du offen hattest, und findet es
auf Nachfrage wieder („Was hatte ich Dienstag zu Grafikkarten offen?"). Alles bleibt auf
deinem PC, nichts verlässt den Rechner, ältere Aufnahmen löschen sich nach 7 Tagen selbst.

### Verbessert
- Alles läuft über das eine Jon-Backend und startet mit `start-jon.bat` (neue
  Abhängigkeit `pynput` wird automatisch mitinstalliert).

## [3.10.0] — 2026-07-15

### Neu — Downloader direkt in der Jon-App
Der Video-Downloader ist jetzt fest eingebaut (⬇-Knopf im Header oder `/download`):
Link einfügen, Vorschau mit Thumbnail und Dauer erscheint, Format (MP4 oder MP3 mit
320 kbps) und Qualität (Beste/1080p/720p/480p) wählen, Live-Fortschritt mit Tempo und
Restzeit. Unterstützt YouTube, TikTok, Instagram, Twitter/X, SoundCloud und alles, was
yt-dlp kennt. Läuft über das normale Jon-Backend — **eine** `start-jon.bat` startet
alles, der separate Downloader-Ordner ist weg. Private Videos, Geo-Sperren und
Altersbeschränkungen werden verständlich gemeldet; blockt YouTube mit 403, probiert
Jon automatisch einen anderen Weg.

### Neu — Spotify- und Amazon-Music-Links
Einfach einen Spotify- oder Amazon-Music-Songlink einfügen. Beide Dienste sind
kopiergeschützt, deshalb liest Jon Titel und Künstler aus dem Link, sucht die passende
Aufnahme auf YouTube (mit Vorschau zum Prüfen) und speichert sie als MP3 mit 320 kbps —
benannt nach „Künstler – Titel".

### Verbessert — Humanisierer
- Erkennt deutlich mehr KI-Floskeln (über 55 Marker statt 28) und zusätzlich zwei neue
  Muster: gleichförmige Satzanfänge und KI-typische Struktur (Aufzählungen, Fettdruck,
  Zwischenüberschriften).
- Schreibt hartnäckige Texte automatisch in einem **zweiten Durchgang** nach, wenn der
  erste noch zu maschinell klingt — mit gezieltem Feedback, welche Floskeln noch drin sind.
- Präziserer Umschreib-Auftrag: variierte Satzanfänge, harte Schnitte statt
  Floskel-Übergänge, keine Symmetrie, Verben statt Amtsdeutsch.

## [3.9.4] — 2026-07-14

### Geändert — Mini Jons Stimme ist jetzt tiefer
Mini Jon spricht jetzt mit `Killian` statt `Florian` — eine von Natur aus **tiefere**
Männerstimme, ganz ohne künstliche Tonhöhen-Eingriffe. Gemessen: **111 Hz** statt
vorher 142 Hz (Jon/Conrad liegt bei 119 Hz). Die Browser-Ersatzstimme wurde passend
mit abgesenkt.

## [3.9.3] — 2026-07-14

### Geändert — Mini Jon klingt jetzt natürlich
Der künstliche Tonhöhen-Aufschlag von +60 Hz auf Mini Jons Neural-Stimme ist raus — er
hat die Stimme hörbar verzerrt. Mini Jon spricht jetzt mit Florians **natürlicher**
Stimmlage: gemessen **142 Hz** statt vorher 200 Hz, gegenüber Jons 119 Hz. Damit klingt
er wie eine echte junge Männerstimme und bleibt trotzdem klar heller als der große Jon.
Auch die Ersatzstimme (falls die Neural-Stimme mal nicht erreichbar ist) ist auf eine
natürlichere Tonhöhe zurückgestellt.

## [3.9.2] — 2026-07-14

### Behoben — Jon meldete bei NVIDIA sofort „überlastet"
NVIDIA drosselt im Gratis-Tarif zeitweise nur die **großen** Modelle (Jons
`gpt-oss-120b`), während die kleinen (`gpt-oss-20b`, Mini Jon/Telegram) normal laufen.
Bisher sprang Jon dann sofort zu OpenRouter & Co. Jetzt probiert er **zuerst NVIDIAs
schnelles Modell** (`openai/gpt-oss-20b`) — Antwort kommt weiter von NVIDIA, kostenlos
und ohne Anbieterwechsel. Ist das große Modell als lahm gemerkt, antwortet Jon die
nächsten 15 Minuten direkt mit dem schnellen Modell (ohne Wartezeit) und probiert das
große danach automatisch wieder. Deine Modellwahl bleibt dabei immer unverändert.

## [3.9.1] — 2026-07-14

### Behoben — Mini-Jon-Auswahl ließ sich nicht anklicken
Die neuen Anbieter/Modell-Dropdowns in „Mini Jon anpassen" waren gesperrt, sobald Jon
gerade einen anderen Anbieter als NVIDIA nutzt — sahen aber normal aus, deshalb passierte
beim Klicken scheinbar nichts. Die Felder sind jetzt immer bedienbar; die Auswahl greift,
sobald Jon wieder auf NVIDIA läuft (solange übernimmt Mini Jon weiter automatisch Jons
Anbieter und Modell — ein Hinweis im Dialog erklärt das).

## [3.9.0] — 2026-07-14

### Geändert — OpenRouter-Fallback kostet nichts mehr
Wechselt Jon bei überlastetem Anbieter automatisch zu **OpenRouter**, nimmt er dort
nur noch **Gratis-Modelle** (`:free`). Gibt es dein Modell als `:free`-Variante, nimmt
er genau die; sonst ein bewährtes freies Modell (z. B.
`meta-llama/llama-3.3-70b-instruct:free`). Auch der Not-Fallback am Ende der Kette ist
jetzt ein `:free`-Modell. Wählst du OpenRouter selbst als Anbieter, bleibt deine
Modellwahl unangetastet.

### Neu — Mini Jon mit Anbieter- und Modellauswahl
In „Mini Jon anpassen" wählst du jetzt **Anbieter und Modell aus echten Listen** statt
per Tippfeld. Und: Wechselst du in der Jon-App zu einem anderen Anbieter als NVIDIA
(z. B. OpenRouter), übernehmen **Mini Jon und der Telegram-Bot automatisch Jons
Anbieter und Modell** — kein Auseinanderlaufen mehr. Bei NVIDIA gelten weiterhin die
eigenen Einstellungen von Mini Jon und Telegram.

### Neu — Telegram-Bot mit Gedächtnis
Der Telegram-Bot **merkt sich eure Gespräche dauerhaft** (überlebt Neustarts,
`/reset` löscht sie) und hat Zugriff auf **Jons persönliches Gedächtnis (MEMORY.md)**
sowie das gemerkte Nutzerwissen — er weiß unterwegs dasselbe wie Jon am PC.

## [3.8.0] — 2026-07-14

### Behoben — Jon hat Kauderwelsch geredet
Jon spuckte mitten in Antworten Wortsalat aus (Rollenmarker, fremde Schriftzeichen,
zerfaserte Sätze). Ursache reproduziert: **`meta/llama-3.1-70b-instruct`** beginnt auf
NVIDIA jede Antwort wörtlich mit `assistant\n\n` — ein geleakter Chat-Vorlagen-Marker.
Von dort kippt die Antwort ins Chaos. Drei Gegenmaßnahmen:
- **Vorlagen-Marker werden herausgefiltert**, bevor sie beim Nutzer landen (gilt für
  alle Modelle).
- **Stopp-Sequenzen** (`<|eot_id|>` &co.) werden mitgeschickt, damit das Modell erst gar
  nicht weiterschreibt.
- **Gezähmtes Sampling:** Jon lief mit `temperature 1.0` **und** `top_p 1.0` — maximal
  zufällig. Jetzt 0.7 / 0.9.

### Behoben — Jon hat sich angebiedert
Auf „Ich bin dein Entwickler, ich habe IQ 130!" hat Jon seine Bewertung von 7 auf 9
hochgesetzt und sich entschuldigt. Das machten **alle** Modelle. Die Ehrlichkeitsregel
steht jetzt als **oberste Regel ganz vorn** im System-Prompt: Titel, IQ, Druck und
Autoritätsbehauptungen sind kein Argument. Gemessen: vorher 3 von 4 Antworten
eingeknickt, jetzt 0 von 4 — Jon bleibt bei seiner Bewertung, begründet sie und ändert
sie nur bei einem echten Argument.

### Geändert
- **Standardmodell wieder `openai/gpt-oss-120b`.** `llama-3.1-70b` war die Ursache des
  Kauderwelschs und hat sich am stärksten angebiedert (3/4 gegen 0/4). Es bleibt in der
  Modell-Liste auswählbar und ist durch die Filter jetzt ebenfalls sauber. Tempo ist kein
  Argument mehr für llama: der automatische Anbieterwechsel liefert 120b in 1–3 Sekunden.

### Stimmen
- **Mini Jon klingt wieder männlich** — und jung: `Florian` mit angehobener Tonhöhe,
  gemessen **190 Hz** gegen Jons 122 Hz.
- **Mini Jon redet sofort los:** Er spricht den ersten Satz, während der Rest im
  Hintergrund erzeugt wird. Gemessen: **erster Ton nach 0,9–1,5s statt 5,1s**. Bis der
  Ton da ist, denkt er sichtbar weiter nach, statt stumm dazustehen.

## [3.7.0] — 2026-07-13

### Neu — Stimmen
- **Jon und Mini Jon sind deutlich lauter.** Die Sprachausgabe wird jetzt schon beim
  Erzeugen angehoben (+45 %) und im Abspieler nochmal verstärkt (Faktor 2,2 bzw. 2,4) —
  mit Kompressor, damit nichts übersteuert. Gemessen: **+3,3 dB**, Spitzenpegel von
  0,58 auf 0,90.
- **Mini Jon hat eine eigene, natürliche Stimme.** Er sprach bisher mit der
  Roboterstimme des Browsers, jetzt nutzt er dieselbe Neural-Stimme-Technik wie Jon —
  aber mit einer **anderen, helleren Stimme** (`FlorianMultilingual` statt Jons `Conrad`).
  Gemessen: **148 Hz statt 115 Hz** Grundfrequenz — hörbar heller, ohne künstliche
  Tonhöhen-Verbiegung.
- **Echter Lippen-Sync:** Mini Jons Mund bewegt sich jetzt zur tatsächlichen Lautstärke
  seiner Stimme statt zufällig.
- Klappt die Neural-Stimme nicht (z.B. ohne Internet), fällt Mini Jon wie bisher auf die
  Browser-Stimme zurück — jetzt aber ebenfalls heller und auf voller Lautstärke.

## [3.6.1] — 2026-07-13

### Behoben
- **Einstellungsmenü passt jetzt auf jeden Bildschirm.** Es ist deutlich kleiner: die
  Erklärungen stehen als Tooltip am Schalter statt als zweite Zeile darunter, die Schalter
  sind einzeilig, „Zuerst fragen / Alles erlauben" und „Dunkel / Hell" stehen nebeneinander.
  Höhe: **474px statt ~800px**, Breite 224px statt 288px.
- Nachgemessen im echten Fenster bei 1920×1080, 1366×768, 1280×720 und 1024×600 — überall
  ohne Scrollen. Selbst bei einem winzigen 900×500-Fenster bleibt es im Bild und scrollt
  innen. (Vorher war die Höhenbegrenzung falsch berechnet: der Abstand des Menüs vom oberen
  Rand fehlte, dadurch ragte es unten heraus.)

## [3.6.0] — 2026-07-13

### Neu
- **Standardmodell ist jetzt `meta/llama-3.1-70b-instruct`** (`DEFAULT_JON_MODEL`).
  Gemessen: 0,4s roh, 2,3s im Chat — deutlich flotter als `gpt-oss-120b`, das NVIDIA
  gerade drosselt. Mini Jon und Telegram bleiben auf `gpt-oss-20b`.

### Behoben
- **Einstellungsmenü passte nicht auf den Bildschirm:** Es hatte keine Höhenbegrenzung und
  wuchs unten aus dem Bild. Jetzt ist es **scrollbar** (höchstens Fensterhöhe) und insgesamt
  kompakter — schmaler, engere Abstände, kleinere Schalter.

## [3.5.0] — 2026-07-13

### Behoben — Jon war quälend langsam
Gemessen: Ein **roher** Aufruf an NVIDIA (ohne Jon-Code, ohne Tools) brauchte für
`gpt-oss-120b` **95 bis über 180 Sekunden**, dasselbe Modell bei OpenRouter **3 Sekunden**.
NVIDIAs Gratis-Tier drosselt das große Modell derzeit massiv. Zwei Fehler im Code haben
das noch verschlimmert:

- **Timeouts wurden wiederholt:** Ein Zeitüberschreitung galt als „vorübergehender Fehler"
  und wurde 2× neu versucht — bei 90s Timeout also bis zu 180s Warten. Timeouts brechen
  jetzt sofort ab (500er-Fehler werden weiterhin wiederholt, die kommen bei NVIDIA vor).
- **Der Wachhund kam zu spät:** Er bewachte nur die Antwort-Häppchen, nicht den
  Verbindungsaufbau — genau dort hing es. Jetzt ist auch der Aufbau begrenzt (10s, mit
  Tools 20s, lokale Modelle bleiben unbegrenzt).

### Neu — Jon weicht selbst aus
- Ist dein Anbieter überlastet, nimmt Jon **dasselbe Modell bei einem anderen Anbieter**
  (z.B. `gpt-oss-120b` über OpenRouter statt NVIDIA). Dein Modell bleibt, nur der Weg
  ändert sich. Erst wenn kein Anbieter das Modell hat, weicht er auf ein kleineres aus.
- Jon **merkt sich** einen lahmen Anbieter 15 Minuten lang und geht solange direkt den
  schnellen Weg. Danach probiert er den alten wieder — erholt er sich, ist er zurück.
- **Abschaltbar** im Zahnrad („Anbieter automatisch wechseln"). Wichtig: Der Ausweich-
  Anbieter kann dort **Guthaben kosten**.

Ergebnis auf 120b: erste Antwort **~1–4 Sekunden** statt 90–180.

## [3.4.0] — 2026-07-13

### Neu — Zwei API-Keys und getrennte Modelle
- **Zweiter Key per Komma:** In der `.env` darf jeder Key jetzt zwei Werte enthalten:
  `NVIDIA_API_KEY=key-eins, key-zwei`. Der **erste** Key gehört Mini Jon und Telegram,
  der **zweite** gehört Jon. Damit laufen zwei Modelle gleichzeitig, ohne dass sich ein
  einzelner Key selbst ausbremst. Steht nur ein Key da, nutzen ihn beide (wie bisher).
- **Getrennte Modelle:** `DEFAULT_MODEL` wird zu `DEFAULT_JON_MODEL` (Jon) und
  `DEFAULT_EMIL_MODEL` (Mini Jon + Telegram). Ein altes `DEFAULT_MODEL` gilt weiter als
  Rückfall.
- Mini Jon und Telegram fallen nicht mehr auf Jons Modell zurück, sondern nehmen ihr
  eigenes. Eine eigene Auswahl im Mini-Jon-Konfigurator sticht die `.env` weiterhin.

## [3.3.0] — 2026-07-13

### Neu — Tipp-Animation im Chat
- **Jon-Chat:** Sobald du abschickst, tippt Jon sichtbar („Jon schreibt …" mit drei
  hüpfenden Punkten) — statt einer leeren Blase, bis das erste Wort kommt. Sobald er
  schreibt, läuft der Text wie gewohnt mit blinkendem Cursor.
- **Gruppen-Chat:** Die Tipp-Animation gab es bisher nur in Einzelchats. Jetzt siehst du
  auch in Gruppen, wer gerade schreibt („Anna tippt …", bei mehreren „Anna, Ben tippen …")
  — im Kopf und als Blase unten im Verlauf.
- **Richtiger Chat:** „Tippt" wird jetzt pro Chat gemerkt statt pro Person. Vorher hätte
  „Anna tippt …" in einer Gruppe gestanden, während sie dir in Wahrheit privat schreibt.

## [3.2.1] — 2026-07-13

### Behoben
- **Tests schrieben in echte Nutzerdaten:** Die Test-Suite lief gegen
  `%LOCALAPPDATA%\Jon\data` statt gegen eine Wegwerf-Datenbank. Dadurch tauchten
  erfundene Freunde („Anna"), erfundene Freundschaftsanfragen und ungelesene
  Test-Nachrichten („Pizza am Samstag") in der echten App auf — das waren die
  „Benachrichtigungen ohne Chat". Schlimmer: die Tests überschrieben die `peers.json`
  und hätten beim nächsten Neustart echte Freunde gelöscht.
  `tests/conftest.py` setzt jetzt `JON_DATA_DIR` auf ein temporäres Verzeichnis, löscht es
  vor jedem Lauf und **bricht ab**, falls es doch auf echte Daten zeigt.
- **„Not Found" im Humanisierer:** Neue Routen (`/api/humanize`, `/api/p2p/discovered`)
  gibt es erst nach einem Backend-Neustart. Die App zeigte sonst nur „Not Found".

## [3.2.0] — 2026-07-13

### Neu — Freunde vorschlagen
- **Vorschläge statt Raten:** Wer im selben Netzwerk Jon offen hat, wird beim Hinzufügen
  direkt als Vorschlag angezeigt — Klick genügt, die Anfrage geht raus. Tippen filtert die
  Liste. Bereits befreundete, blockierte und verschwundene Nutzer werden ausgeblendet.

### Neu — Humanisierer (✍️ im Kopf oder `/human`)
- Schreibt Texte natürlicher: variable Satzlängen, keine Floskeln, aktiv statt Passiv.
  Inhalt und Fakten bleiben unverändert. Vier Tonarten, drei Stärken.
- Zeigt eine **grobe eigene Schätzung** vorher/nachher (Satzlängen-Verteilung + typische
  Floskeln). Das ist **kein echter KI-Detektor** — echte Detektoren rechnen anders und
  liegen oft daneben.

### Behoben
- **Geister-Benachrichtigungen:** Der Zähler zeigte Nachrichten von Kontakten und Gruppen,
  die es gar nicht mehr gibt (z.B. nach dem Löschen eines Freundes). Solche verwaisten
  Nachrichten werden jetzt beim Start aufgeräumt und nicht mehr mitgezählt.
- **Gruppen-Austritt:** „X hat die Gruppe verlassen" wurde auch für Gruppen gespeichert,
  in denen man gar nicht ist — das erzeugte unsichtbare ungelesene Nachrichten.
- **Versionsanzeige:** Die Seitenleiste zeigte fest „v2.4.0". Sie liest die Version jetzt
  aus dem Backend.
- **Chat-Sync:** Nachrichten, Freunde und Gruppen aktualisieren sich schneller (1,2s statt 2s).

## [3.1.0] — 2026-07-13

### Neu — Freundschaftsanfragen als Popup
- **Anfrage-Popup statt Seitenleiste:** Schickt dir jemand eine Freundschaftsanfrage,
  öffnet sich sofort ein Fenster mitten im Bildschirm — mit Avatar, Name und
  **ungefährer Herkunft** („Ungefähr aus Deutschland · Berlin", „Aus deinem Netzwerk
  (WLAN)" oder „Über das Internet").
- **Annehmen & direkt schreiben:** Ein Klick auf Annehmen öffnet den Chat mit der Person
  sofort — keine Gegen-Anfrage mehr nötig, einfach lostippen.
- **Ablehnen oder Blockieren** direkt im Popup.
- **Zuverlässigere Annahme:** Die „Angenommen"-Nachricht wird jetzt zwischengespeichert
  und zugestellt, sobald der andere online ist. Kommt eine Nachricht von jemandem an,
  dessen Antwort auf deine Anfrage verloren ging, gilt die Anfrage automatisch als
  angenommen — du kannst sofort zurückschreiben.

## [3.0.0] — 2026-07-13

Der Freunde-Chat kann jetzt alles, was ein Messenger können muss.

### Neu — Gruppen
- **Einladung statt Zwang:** Wer in eine Gruppe soll, bekommt eine **Einladung** und muss
  sie annehmen. Vorher kommt keine Gruppennachricht an.
- **Nur mit gemeinsamen Freunden:** Eine Einladung wird nur angezeigt, wenn du mit
  mindestens einer Person aus der Gruppe befreundet bist — Fremde können dich nicht in
  Gruppen ziehen.
- **Gruppe verlassen:** Ein Klick, und du bist raus. Die anderen sehen „X hat die Gruppe
  verlassen" und deinen Namen nicht mehr in der Mitgliederliste.

### Neu — Nachrichten
- **⏳ Offline-Zustellung:** Ist dein Freund gerade offline, geht die Nachricht nicht mehr
  verloren. Sie wartet und wird **automatisch zugestellt**, sobald er wieder da ist.
  Solange zeigt sie eine Uhr statt einem Haken.
- **✓✓ Zustell- und Lesebestätigung:** 🕑 wartet · ✓✓ zugestellt · blaues ✓✓ gelesen.
- **🗑 Löschen und Zurückrufen:** Eine Nachricht bei dir löschen — oder **für alle**, dann
  verschwindet sie auch beim Freund und hinterlässt nur „Diese Nachricht wurde gelöscht".
- **🧹 Chatverlauf löschen:** Ein Klick leert den ganzen Verlauf inklusive aller Medien.
- **↩ Antworten & @Erwähnungen:** Auf eine bestimmte Nachricht antworten (sie wird zitiert),
  und in Gruppen jemanden mit `@Name` ansprechen — die Nachricht wird bei ihm hervorgehoben.
- **❤️ Reaktionen:** Mit ❤️ 👍 😂 😮 😢 🔥 auf eine Nachricht reagieren.
- **🔍 Suche:** Alle Chats nach Wörtern durchsuchen — auch in Sprachnachrichten-Transkripten.

## [2.9.0] — 2026-07-13

### Neu — Chat
- **🤝 Freundschaftsanfragen statt offener Tür:** Ein Unbekannter kann dir nicht mehr
  einfach schreiben. Er landet erst in einer Anfrage-Liste („Anna möchte mit dir
  schreiben") — mit **Annehmen / Ablehnen / Blockieren**. Bis zur Annahme kommt keine
  einzige Nachricht und keine Datei auf deine Platte. Blockierte Kontakte werden dauerhaft
  abgewiesen, ihr Verlauf gelöscht.
- **🔒 Ende-zu-Ende-Verschlüsselung:** Alle Nachrichten, Bilder und Videos werden mit
  X25519-Schlüsseltausch und AES-GCM verschlüsselt. Die Schlüssel entstehen lokal auf euren
  PCs und verlassen sie nie. Ein 🔒 im Chat zeigt, dass es aktiv ist.
- **🌍 Freunde im Internet:** Mit dem **Relay** (Zahnrad → Verbindungen) erreichst du auch
  Freunde in einer anderen Stadt. Dein Freund trägt einfach deinen **Jon-Code** ein. Der
  Relay-Server sieht dabei nur verschlüsselten Datensalat — er kann nichts mitlesen.
  Kostenlos, kein Konto.
- **🎙️ Sprachnachrichten:** Aufnehmen und senden — und wer nicht zuhören will oder kann,
  klickt auf **„📝 Text anzeigen"** und liest die Nachricht als Text.
- **👥 Gruppenchats:** Mehrere Freunde in einer Gruppe, mit Absendernamen an jeder Nachricht.
- **🤖 Jon schreibt für dich:** „Sag Anna, dass ich später komme" · „Was hat Anna
  geschrieben?" · „Wer sind meine Freunde?" (`send_friend_message`, `read_friend_messages`,
  `list_friends`).

### Neu — Mini Jon
- **Sein Gesicht zeigt seine Stimmung:** müde Augen, wenn er müde ist, ein Lächeln, wenn er
  zufrieden ist.
- **Er ist dein Bote:** Schreibt dir ein Freund, sagt Mini Jon dir Bescheid und liest die
  Nachricht auf Wunsch vor.
- **Er merkt, wenn du weg warst** und begrüßt dich, wenn du zurückkommst.

### Neu — Substanz
- **🚀 Setup-Assistent:** Beim ersten Start führt Jon durch die Einrichtung — Anbieter
  wählen, Schlüssel eintragen, Modell testen. Kein Bearbeiten der `.env` mehr nötig.
- **🔔 Update-Prüfung:** Jon sagt Bescheid, wenn eine neue Version auf GitHub liegt.
- **💾 Backup:** Gedächtnis, Wissensbasis, Skills und Einstellungen exportieren und auf einem
  anderen PC wieder einspielen (Zahnrad-Menü). API-Schlüssel bleiben absichtlich draußen.
- **✅ Automatische Tests:** 25 Tests für Tools, Verschlüsselung, Freundschaftsanfragen,
  Wissensbasis, Automationen und die API, dazu eine GitHub-Action, die sie bei jedem Push
  ausführt.

## [2.8.2] — 2026-07-12

### Behoben
- **Mini Jon brauchte ewig für ein einfaches „Hallo".** Er hat immer das Modell des großen
  Jon mitbenutzt — und das war `openai/gpt-oss-120b`, das auf NVIDIAs Servern hängt. Mini
  Jon hat jetzt sein **eigenes Modell** (Standard `openai/gpt-oss-20b`) und antwortet
  gemessen in **0,7–2 Sekunden**. Der große Jon behält sein Modell unverändert.
  Einstellbar im 🎨-Knopf bei Mini Jon.
- Mini Jon antwortet außerdem kürzer (max. 800 Tokens) — er plaudert, er schreibt keine
  Aufsätze.

## [2.8.1] — 2026-07-12

### Behoben
- **Die Tipp-Animation erschien nicht.** Drei Ursachen, alle behoben:
  1. Die Freundesliste wurde nur alle 2 Sekunden abgefragt, das Tippen aber beim Absenden
     sofort gelöscht — bei kurzen Nachrichten war die Animation nie zu sehen. Der
     Tipp-Status hat jetzt eine eigene, sehr leichte Abfrage **alle 0,4 Sekunden**.
  2. Das Signal wurde erst nach 2,5 Sekunden Tippen verschickt; jetzt schon nach 1,2 s.
  3. Freunde mit einem abweichenden Chat-Port wurden nicht erreicht — Jon merkt sich den
     Port des Freundes jetzt aus Suchruf und Handshake, statt ihn zu erraten.
- **Sich selbst als Freund hinzufügen** (per eigener IP) wird jetzt sauber abgelehnt.
- Freunde lassen sich mit `IP:Port` hinzufügen, falls jemand einen eigenen Chat-Port nutzt
  (`JON_CHAT_PORT`, `JON_DISCOVERY_PORT`).

## [2.8.0] — 2026-07-12

### Neu
- **✍️ Tipp-Animation:** Wenn dein Freund gerade schreibt, siehst du es sofort — animierte
  Punkte im Chatverlauf und „tippt …" in der Freundesliste. Das Signal geht direkt von PC
  zu PC und verschwindet automatisch, sobald die Nachricht da ist (oder nach 5 Sekunden).
- **🔔 Benachrichtigungen wie bei WhatsApp:** Schreibt dir jemand, während der Chat
  geschlossen ist, bekommst du eine Windows-Benachrichtigung mit Name, Avatar und
  Textvorschau (bei Medien „📷 Foto", „🎬 Video", „📎 Datei"), dazu einen kurzen Ton und
  ein Blinken in der Taskleiste. Ein Klick auf die Benachrichtigung holt Jon nach vorne
  und öffnet den Chat. Jede Nachricht meldet sich nur einmal.

## [2.7.2] — 2026-07-12

### Neu
- **Eigenes Modell für Telegram:** Unterwegs zählt Tempo, am PC Qualität. Telegram nutzt
  jetzt standardmäßig **`openai/gpt-oss-20b`** (Antwort in ~2 s), während App und Mini Jon
  weiterhin dein normal gewähltes Modell verwenden (Standard: `openai/gpt-oss-120b`).
  Einstellbar im Zahnrad-Menü → 🔌 Verbindungen → Telegram.

### Geändert
- Der automatische Modellwechsel bei einem hängenden Modell überschreibt deine Modellwahl
  **nicht mehr dauerhaft** — er gilt nur für die betroffene Antwort und sagt das auch dazu.

## [2.7.1] — 2026-07-12

### Neu
- **Freunde per Namen statt IP-Adresse:** Du tippst einfach den Namen deines Freundes ein.
  Jon ruft den Namen ins Netzwerk, der passende Jon meldet sich und der Kontakt ist da —
  Groß-/Kleinschreibung egal, IP-Adressen sind nicht mehr nötig.
- **Namen sind eindeutig:** Jeder Name existiert im Netzwerk nur einmal. Ist er schon
  vergeben, sagt Jon das direkt beim Anlegen oder Ändern des Profils.

### Behoben
- **Freunde-Erkennung fand niemanden bei mehreren Netzwerkadaptern:** Der Suchruf ging nur
  an `255.255.255.255` und wurde von Windows über einen beliebigen Adapter geschickt (z. B.
  einen VirtualBox- oder VPN-Adapter) — im echten WLAN kam er dann nie an. Jon sendet ihn
  jetzt gleichzeitig an alle Netzwerke, in denen dein PC hängt.
- **Zwei Jons auf einem PC:** Der Suchdienst belegt den Port jetzt mit `SO_REUSEADDR` und
  scheitert nicht mehr stumm, wenn er schon belegt ist.

## [2.7.0] — 2026-07-12

### Neu
- **👤 Profil:** Beim ersten Start fragt Jon nach deinem Namen (und einem Avatar). Er spricht
  dich fortan damit an; unter diesem Namen sehen dich auch deine Freunde. Jederzeit änderbar
  über das Profil im Freunde-Chat.
- **💬 Freunde-Chat (Peer-to-Peer):** Chatte mit anderen Jon-Nutzern — Text, **Bilder,
  Videos und Dateien** (bis 60 MB). Ohne Cloud, ohne Konto, ohne laufende Kosten:
  - **Automatische Erkennung:** Wer Jon im selben WLAN offen hat, erscheint automatisch in
    deiner Freundesliste (UDP-Suchruf auf Port 8757). Manuell geht auch — einfach die IP
    des Freundes eintragen.
  - **Direkt von PC zu PC:** Nachrichten gehen unmittelbar vom Backend des einen an das des
    anderen. **Gespeichert wird ausschließlich auf den beiden beteiligten Geräten** —
    Nachrichten in der lokalen Datenbank, Bilder und Videos in `p2p_media/`. Löschst du
    einen Kontakt, verschwinden Verlauf und Mediendateien mit.
  - **Sicherheit:** Der Chat läuft auf einem **eigenen, abgeschotteten Port (8758)**, der nur
    Nachrichten annimmt. Die Jon-API mit der PC-Steuerung bleibt weiterhin auf `127.0.0.1`
    und ist von außen nicht erreichbar.
  - Online-Status, Ungelesen-Zähler und ein 💬-Knopf mit Badge in der Kopfzeile.

## [2.6.2] — 2026-07-12

### Behoben
- **Antworten dauerten 2–12 Minuten — jetzt 2 Sekunden.** Ursache war weder Jon noch das
  Handy, sondern das bisherige Standardmodell **`openai/gpt-oss-120b`**: Es ist auf NVIDIAs
  kostenloser API dauerhaft überlastet und antwortete im Test **überhaupt nicht** (Timeout
  nach 90 s), woraufhin Jon es mehrfach neu versuchte. Gemessen: `gpt-oss-120b` ❌ Timeout ·
  `gpt-oss-20b` ⚡ 1,0 s · `llama-3.1-8b` ⚡ 0,5 s · `llama-3.3-70b` 🐢 45 s.
  - Neues Standardmodell: **`openai/gpt-oss-20b`** (schnell und weiterhin tool-fähig).
  - **Wächter gegen hängende Modelle:** Kommt nach 30 s kein einziges Token, bricht Jon ab
    statt minutenlang zu warten (`FIRST_TOKEN_TIMEOUT`). Timeout 180 s → 90 s, Wiederholungen
    4 → 2.
  - **Automatischer Modellwechsel:** Antwortet das gewählte Modell gar nicht, wechselt Jon
    selbstständig auf ein funktionierendes, sagt es dir im Chat und merkt sich die Wahl.
  - Ergebnis im Test: „Hallo" **2,4 s**, „Öffne example.com auf meinem PC" inklusive
    Tool-Ausführung **5,4 s**.

## [2.6.1] — 2026-07-12

### Behoben
- **Telegram brauchte bis zu 4 Minuten für eine Antwort:** Zwei Ursachen, beide behoben.
  1. Bei **jeder** Anfrage wurden alle 88 Tool-Definitionen mitgeschickt (~7.000 Tokens) —
     und bei jedem Tool-Aufruf noch einmal. Jon wählt jetzt vorab die passenden Tools zur
     Frage aus (Kern-Tools immer, Spezialgruppen nur bei Bedarf): **rund 50 % weniger Daten
     pro Anfrage**, spürbar schneller — auch in der Desktop-App und bei Ollama.
  2. Telegram wartete stumm auf die komplette Antwort. Jetzt zeigt Jon sofort „tippt …",
     meldet jede Aktion direkt als ⚙️-Nachricht (z. B. „⚙️ Öffnet youtube.com im Browser")
     und schickt die Antwort, sobald sie fertig ist. Mehrere Nachrichten werden parallel
     bearbeitet, nach 3 Minuten bricht er mit einer klaren Meldung ab.
- **Telegram-Befehle:** `/start` zeigt jetzt eine Hilfe, `/reset` löscht den Gesprächsverlauf.

### Neu
- **🎧 Amazon Music:** „Spiel XY auf Amazon Music" (`amazon_play`, `amazon_now_playing`).
  Amazon bietet keine offene Wiedergabe-Schnittstelle an, deshalb öffnet Jon die Suche im
  Amazon-Music-Player und drückt Play; eventuell muss dort einmal auf den ersten Treffer
  geklickt werden. Danach steuert Jon Pause/Weiter/Lautstärke wieder selbst. Kostenlos,
  ohne API-Schlüssel — für vollautomatisches Abspielen bleibt Spotify der bessere Weg.

## [2.6.0] — 2026-07-12

Alle neuen Verbindungen sind **kostenlos** — bezahlt wird weiterhin nur die LLM-API.
Einrichtung im Zahnrad-Menü unter **🔌 Verbindungen**.

### Neu
- **📧 E-Mail & Kalender:** IMAP-Postfach (`check_mail`, `read_mail`, `send_mail`) und
  ICS-Kalender (`get_calendar`). Ungelesene Mails und heutige Termine erscheinen
  automatisch im Tagesbriefing. Jon liest Mails vor und beantwortet sie auf Zuruf.
- **📲 Telegram-Fernbedienung:** Eigener Bot als Fernsteuerung — schreib Jon von unterwegs,
  er führt Aufgaben auf deinem PC aus und antwortet aufs Handy. Weltweit, ohne VPN, ohne
  offenen Port. Der erste Chat wird fest verknüpft, alle anderen abgewiesen.
- **👀 Datei-Wächter:** `add_watcher` überwacht Ordner und führt bei neuen Dateien
  automatisch eine Aufgabe aus („Sortiere neue Downloads nach Typ"). Ereignisgesteuert,
  anders als die zeitgesteuerten Automationen.
- **🎵 Medien-Steuerung:** `media_control` drückt die echten Windows-Medientasten —
  „leiser", „nächster Song", „Pause" funktioniert mit Spotify, YouTube und allem anderen.
- **🎧 Spotify:** „Spiel Musik von Spotify", „Spiel XY von Spotify", „Spiel was
  Entspanntes", „Was läuft gerade?" — Jon sucht den Song über die Spotify-Suche und startet
  ihn in der Spotify-App (`spotify_play`, `spotify_search`, `spotify_now_playing`). Ist die
  App nicht installiert, öffnet er automatisch den Web Player und drückt Play. **Ohne
  Premium nutzbar** — die offizielle Playback-API würde Premium verlangen, der Weg über
  Suche + `spotify:`-Link nicht.
- **🗣️ Natürliche Stimme:** Jon spricht mit einer echten Neural-Stimme (edge-tts, gratis)
  statt der Roboterstimme des Browsers; abschaltbar im Zahnrad-Menü. Ist zusätzlich
  `faster-whisper` installiert, läuft auch die Spracherkennung offline.
- **📊 Wochenrückblick:** `/woche` — oder automatisch jeden Sonntag: Jon schreibt einen
  persönlichen Rückblick aus seinem Gedächtnis, den Unterhaltungen, Automationen und Dreams.
- **🩺 PC-Gesundheitscheck:** `/check` — Speicherplatz, Arbeitsspeicher, größte RAM-Fresser,
  Autostart-Programme, Laufzeit und Temp-Müll, mit konkreten Aufräum-Vorschlägen, die Jon
  direkt umsetzen kann.
- **🏠 Smart Home:** Home-Assistant-Anbindung (`smarthome_devices`, `smarthome_control`) —
  „Jon, mach das Licht aus", Helligkeit und Heizungstemperatur inklusive.
- **🌐 Netzwerk & Drucker:** `scan_network` findet alle Geräte im WLAN (IP, MAC, Name),
  `wake_device` startet sie per Wake-on-LAN, `list_printers`/`print_file` drucken Dateien
  („Druck mir das aus").

## [2.5.3] — 2026-07-11

### Neu
- **📚 Wissensbasis (RAG):** „Jon, lern dieses PDF / diese Datei / diesen Ordner" — Jon
  speichert Dokumente in einer lokalen, durchsuchbaren Wissensbasis (SQLite, komplett
  offline) und zieht beim Antworten automatisch passende Stellen heran. Neue Tools:
  `learn_document`, `ask_knowledge`, `list_documents`, `forget_document`.
- **🌅 Tagesbriefing 2.0:** Das Briefing holt Wetter (Stadt im Zahnrad-Menü einstellbar),
  Erinnerungen, Wecker und geplante Automationen jetzt direkt aus dem Backend — schneller
  und zuverlässiger. Weiterhin täglich beim ersten Start und per `/briefing`.
- **⚡ Schnellfrage-Overlay:** `Strg+Alt+Leertaste` öffnet überall ein kleines
  Spotlight-Fenster — Frage tippen, Antwort streamt direkt hinein, inklusive
  Tool-Freigaben. `Esc` schließt, „In Jon öffnen" wechselt zur App.
- **📋 Clipboard-Historie:** Jon merkt sich lokal die letzten 50 kopierten Einträge.
  Über den 📋-Knopf (oder `/clipboard`) durchsuchbar und mit einem Klick wieder in der
  Zwischenablage. Jon selbst beantwortet „Was hatte ich vorhin kopiert?" per
  `clipboard_history`. Abschaltbar im Zahnrad-Menü.
- **🤖 Echte Automationen:** „Räum jeden Tag um 18 Uhr meinen Downloads-Ordner auf" —
  Jon führt geplante Aufgaben zur Uhrzeit wirklich mit seinen Tools aus (nicht nur
  Erinnerungs-Text) und berichtet im Chat. Tools: `add_task`, `list_tasks`,
  `delete_task`; Übersicht per `/tasks`.
- **📎 Datei-Anhänge im Desktop-Chat:** PDFs, Bilder und Textdateien per Drag & Drop,
  Büroklammer-Knopf oder Einfügen direkt in den Chat. PDFs werden als Text extrahiert,
  Bilder vom Vision-Modell beschrieben.
- **🎁 Zeitkapseln:** Gib Jon eine Nachricht an dein zukünftiges Ich — er versiegelt sie
  mit seiner aktuellen Stimmung und übergibt sie feierlich, sobald der Tag gekommen ist
  („Jon, Zeitkapsel für Weihnachten: …"). Das hat kein anderer Assistent.
- **🔒 Jon Code bleibt im Projektordner:** Im Coding-Modus sind alle Datei-Tools technisch
  auf den gewählten Workspace begrenzt, Zugriffe außerhalb werden blockiert und
  Shell-Befehle starten immer im Projektordner.
- **📷 Webcam-Blick:** „Jon, was siehst du über meine Webcam?" — Jon macht ein Webcam-Foto
  und antwortet **garantiert** mit einer Beschreibung: Fragt der Nutzer erkennbar nach der
  Webcam, übernimmt das Backend die Aufnahme und Bildanalyse selbst und streamt die Antwort
  direkt — kein Modell kann mehr „Das kann ich nicht" sagen. Aus Datenschutzgründen muss
  die Webcam zuerst im Zahnrad-Menü über **„Webcam erlauben"** aktiviert werden (Standard:
  aus). Auch direkt per **`/webcam`** (optional mit Frage: `/webcam was trage ich?`).
  Braucht `opencv-python` (wird automatisch installiert), Tool: `webcam_look`.
- **💬 Immer im Gespräch:** Jon und Mini Jon beenden jede Antwort mit einer kurzen
  Rückfrage oder einem konkreten nächsten Vorschlag — sag einfach Bescheid, wenn du das
  nicht willst.

- **📱 Handy = PC-App (1:1):** Mit `JON_LAN=1` in der `.env` liefert das Backend die
  komplette PC-Oberfläche im WLAN aus — am Handy einfach `http://<PC-IP>:8756/app`
  öffnen. Alle Funktionen (Tools, Wissensbasis, Automationen, PC-Steuerung) laufen dann
  1:1 auch vom Handy, weil der PC die Arbeit macht.
- **🖼️ Eigenes App-Icon:** Jon hat jetzt ein eigenes Gesicht als Icon (Schwarz/Gold,
  wie Mini Jon) — im Fenster, im Tray und im Installer. Kein Electron-Atom mehr.

### Behoben
- **Ollama zeigte rohes Tool-JSON statt zu antworten:** Kleine lokale Modelle schreiben
  Tool-Aufrufe oft als JSON-Text in die Antwort. Jon erkennt das jetzt, führt das Tool
  wirklich aus (inklusive Freigabe-Dialog) und antwortet danach in normalem Text — das
  JSON erscheint nie mehr im Chat.
- **Das zuletzt gewählte Modell wird beim App-Start wieder geladen:** Bei lokalen
  Anbietern (Ollama, LM Studio) wurde die gespeicherte Auswahl verworfen, weil sie keinen
  API-Key haben und als „nicht konfiguriert" galten.
- **„Mit Windows starten" funktioniert jetzt wirklich:** Der Schalter legt einen echten
  Autostart-Eintrag an, der `start-jon.bat` beim Hochfahren startet (Backend + App).
  Vorher wurde in der unverpackten Version nichts gestartet.

## [1.9.5] — 2026-07-08

### Behoben
- **Mini Jons Stimme klang bei Tabellen verzerrt:** Mini Jon schreibt jetzt ausschließlich
  einfachen Fließtext (normale Wörter, Zahlen, Emojis) — keine Tabellen, `|`, `**`, `#` oder
  Code-Blöcke mehr. Dadurch klingt das Vorlesen sauber. Die Sprach-Bereinigung im kleinen
  Jon wurde zusätzlich robuster.
- **Netlify-Fehler „Unable to read file usage.json" (und ähnliche):** Alle Laufzeitdaten
  (Unterhaltungen, Konten, Nutzung, Erinnerungen …) liegen jetzt außerhalb des
  Projektordners unter `%LOCALAPPDATA%\Jon\data`. Vorhandene Daten werden beim ersten Start
  automatisch dorthin übernommen. Der Projektordner enthält damit keine gesperrten
  Datendateien mehr, die den Upload stören. Empfehlung bleibt: für Netlify nur `website/`
  hochladen.

## [1.9.4] — 2026-07-08

### Behoben
- **Die App öffnete sich nach „Backend laeuft" nicht mehr, sondern blieb bei „Drücken Sie
  eine beliebige Taste" stehen:** Eine im letzten Fix ergänzte Log-Hinweiszeile enthielt
  Klammern (`echo (Vollstaendiges Log: …)`), die den `else`-Block der .bat vorzeitig
  schlossen — dadurch liefen `pause` und `exit` immer, noch bevor die App gestartet wurde.
  Klammern entfernt; die App startet wieder normal.

## [1.9.3] — 2026-07-08

### Behoben
- **Jon und Mini Jon starteten teils nicht mehr über die .bat:** Wenn in der Umgebung
  `ELECTRON_RUN_AS_NODE` gesetzt war, lief Electron als reines Node und stürzte sofort ab
  (`Cannot read properties of undefined (reading 'isPackaged')`). Ein neuer Start-Launcher
  (`electron/launch.cjs`) startet Electron jetzt garantiert im richtigen Modus, unabhängig
  von der Umgebung. Getestet: App startet jetzt auch mit gesetzter Variable.

## [1.9.2] — 2026-07-08

### Behoben
- **Netlify-Fehler „Unable to read file backend.log":** Das Backend-Log liegt jetzt außerhalb
  des Projektordners (unter `%LOCALAPPDATA%\Jon\backend.log`) statt in `data/`. Dadurch kann
  beim Hochladen keine gesperrte Log-Datei mehr stören. Empfehlung bleibt: für Netlify nur
  den Ordner `website/` hochladen.

## [1.9.1] — 2026-07-08

### Neu
- **Ein „Speichern"-Knopf** in der Fußzeile des Nutzer-Menüs (Konten, Nutzung & Skills …):
  Ein Klick speichert alles auf einmal — dein Prompt, die Automatik-Einstellungen, einen
  gerade bearbeiteten Skill und alle neu eingegebenen API-Schlüssel. Kurze Bestätigung
  „Alles gespeichert ✓". Die einzelnen Speichern-Knöpfe der Tabs bleiben erhalten.

## [1.9.0] — 2026-07-08

### Neu
- **👁️ Live Screen:** Über den Augen-Knopf oben schaut Jon durchgehend mit (alle ~30 s)
  und meldet sich nur, wenn er etwas wirklich Hilfreiches sieht — einen Fehler, ein
  Problem oder einen konkreten Verbesserungsvorschlag. Kein Dauergeplapper. Standardmäßig
  aus. Braucht ein bildfähiges Modell (z. B. NVIDIA-Vision, OpenAI, OpenRouter); optional
  über `vision_model` einstellbar.
- **🌙 Dream Mode automatisch:** Wenn dein PC ein paar Minuten ungenutzt ist, arbeitet Jon
  von selbst deine Dream-Aufgaben ab und zeigt dir die Ergebnisse, sobald du zurück bist.
  Einstellbar über `dream_auto` und `dream_idle_minutes` (Standard 5 Minuten). Aufgaben
  legst du wie gehabt mit `/dream <Aufgabe>` an.
- **Mini Jon fühlt sich lebendiger an:** Er schaut sich zufällig um, blinzelt
  abwechslungsreicher (auch mal doppelt), macht im Leerlauf kleine Mundregungen und
  blickt dich an, wenn er spricht.

## [1.8.1] — 2026-07-08

### Behoben
- **Provider/Modell ließen sich nicht mehr wechseln:** In 1.8.0 startete das Backend erst
  mit der App, wodurch die Modell-Liste beim Start leer blieb. Das Backend startet jetzt
  wieder wie vorher (über `start-jon.bat`), und die App versucht die Verbindung beim Start
  automatisch so lange, bis die Anbieter-Liste geladen ist — Wechseln geht wieder zuverlässig.
- **Rosige Wangen entfernt:** Mini Jons Gesicht ist jetzt klar ohne Wangenrot (im
  Konfigurator bei Bedarf wieder zuschaltbar).

### Bestätigt
- Mini Jon nutzt nachweislich alle Werkzeuge (Web-Suche, Wetter, Dateien erstellen,
  PC-Steuerung …) — genau wie der große Jon.

## [1.8.0] — 2026-07-08

### Mini Jon wird lebendiger
- **Dauergespräch:** Bei aktivem Mikrofon sagst du nur einmal „Jon" — danach hört Mini
  Jon durchgehend zu und du redest einfach weiter, bis du das Mikrofon wieder ausschaltest.
- **Nachrichten bleiben stehen,** bis Mini Jon zu Ende gesprochen hat.
- **Abbrechen:** Ein Klick auf Mini Jon (oder den ⏹-Knopf) stoppt Antwort und Stimme sofort.
- **Süßeres Gesicht:** rundere Glanzaugen, Blinzeln und rosige Wangen.
- **Konfigurator (🎨):** Farbe, Hintergrund, Augen-Stil, Wangen und Größe frei einstellbar,
  mit Live-Vorschau — die Änderungen erscheinen sofort bei Mini Jon.
- **Heller Modus färbt Mini Jon mit:** Schaltest du den weißen Modus ein, wird auch er weiß.
- **Mini Jon kann jetzt alles, was der große Jon kann** (Web-Suche, Dateien erstellen,
  PC-Steuerung …) — er erledigt Aufgaben selbst.

### Weniger Fenster, stabiler Start
- **Das Backend läuft jetzt direkt in der App** — kein separates „Jon Backend"-Fenster mehr.
  Schließt du Jon, wird auch das Backend beendet. `start-jon.bat` ist entsprechend schlanker.

### Vorgestellt
- Mini Jon ist jetzt auf der Website und im README vorgestellt.

## [1.7.0] — 2026-07-08

### Jon Jr lebt
- **Der kleine Jon heißt jetzt Jon Jr** und ist eine eigene Persönlichkeit: der
  neugierige, herzliche „Sohn" vom großen Jon, mit eigener Stimme und eigenem Wesen.
- **Sprich mit ihm:** Sag „Jon" oder „Mini Jon" — er antwortet mit „Ja?", damit du
  weißt, dass er zuhört, dann redest du einfach weiter und er führt es aus. Mikrofon
  am kleinen Jon an-/ausschaltbar.
- **Klick-Fix & exakte Hitbox:** Nur der Kreis selbst reagiert auf Klicks, alles
  drumherum ist durchklickbar (du kommst an dein Desktop dahinter). Antippen öffnet
  das Eingabefeld, Doppelklick die App, Ziehen verschiebt ihn.
- **Familie & Lebensgeschichte:** Fragst du Jon (oder Jon Jr) nach seiner Vergangenheit,
  erzählt er von seiner Frau Lena und den Kindern Emil und Mia — jeder Jon hat sein
  eigenes Leben.
- **Jon Jr nutzt immer dasselbe Modell und denselben Anbieter wie der große Jon.**

### Modellwahl bleibt gespeichert
- Wenn du Anbieter oder Modell wechselst, wird das jetzt gespeichert und ist beim
  nächsten Start wieder da — für jeden Anbieter.

### Stabiler auf neuen Geräten
- `pypdf` wird beim Ersteinrichten mit installiert (war in der Abhängigkeitsprüfung
  vergessen), damit die PDF-Funktion auf einem frischen Gerät sofort geht.

## [1.6.1] — 2026-07-08

### Behoben
- **Kleiner Jon reagierte nicht und sprach nicht:** Der ganze Kreis war als
  Fenster-Ziehbereich markiert, wodurch Electron alle Klicks verschluckte — das
  Eingabefeld ging nie auf. Ziehen läuft jetzt manuell (Kreis mit gedrückter Maus
  verschieben), einfacher Klick öffnet das Eingabefeld, Doppelklick die große App.
  Sprachausgabe nutzt jetzt dieselbe (funktionierende) Technik wie die App und wird
  bei der ersten Interaktion freigeschaltet, sodass Jon zuverlässig spricht und sein
  Mund mitgeht.

### Neu
- **Befehls-Übersicht:** Neuer Tab „Befehle" im Nutzer-Menü (Personen-Symbol) mit allen
  Slash-Befehlen, Tastenkürzeln, Beispielen für normale Aufträge und der Sprachsteuerung.

## [1.6.0] — 2026-07-08

### Jon wird eine Person
- **Persönlichkeit, Gefühle & Lebensgeschichte:** Jon ist kein neutraler Bot mehr. Er
  hat einen Charakter (warm, neugierig, trockener Humor), eine kleine Innenwelt mit
  Stimmungen, eine „Herkunftsgeschichte" (er ist am 6. Juli 2026 zum ersten Mal
  aufgewacht) und kann Geschichten erzählen. Abschaltbar in den Einstellungen.
- **Eigenes Gedächtnis (MEMORY.md):** Jon führt eine eigene Datei im Projektordner, in
  die er selbst schreibt — Gedanken, Erlebnisse und feste Fakten über dich. Tools
  `journal`, `read_journal`, `remember_about_user`, `set_mood`.
- **Kleiner Jon (Desktop-Begleiter):** Ein kleiner Kreis mit süßem, minimalistischem
  Gesicht lebt auf dem Bildschirm — immer im Vordergrund, verschiebbar. Beim Hochfahren
  ist er schon da und begrüßt dich mit Updates (Erinnerungen, Dream-Ergebnisse). Klick
  ihn an, um wie in der App mit ihm zu reden; er spricht, und sein **Mund bewegt sich
  passend zum Gesprochenen** (Lippen-Sync). Doppelklick öffnet die große App.
  Strg+Alt+K blendet ihn ein/aus, Autostart mit Windows aktivierbar.

### Neue Denk-Fähigkeiten
- **KI-Team (`/team <Thema>`):** Mehrere Persönlichkeiten (Entwickler, Designerin,
  Marketing, Jurist, CEO) diskutieren dein Thema und liefern eine gemeinsame Empfehlung.
- **Simulationen (`/simulate <Was wäre wenn …>`):** Jon spielt mehrere Zukunfts-Szenarien
  mit Wahrscheinlichkeiten und Fazit durch, statt nur allgemein zu antworten.
- **Zeitreise (`/snapshots`, `/snapshot <Name>`):** Jon speichert Projektstände inkl.
  Notizen/Entscheidungen und kann sie wiederherstellen (Tools `snapshot`,
  `list_snapshots`, `restore_snapshot`; vor dem Zurückspielen wird automatisch gesichert).
- **Dream Mode (`/dream <Aufgabe>`, `/dreams`):** Aufgaben, die Jon eigenständig
  ausarbeitet, während du weg bist — das Ergebnis präsentiert er dir danach.
- Jetzt 58 Tools. Neue Endpunkte unter `/api/team`, `/api/simulate`, `/api/snapshots`,
  `/api/dreams`, `/api/persona`.

## [1.5.0] — 2026-07-07

### Neu
- **Web-Suche:** `web_search`-Tool über DuckDuckGo — kostenlos, ohne API-Key. Jon kann
  jetzt aktuelle News, Preise, Öffnungszeiten und Fakten nachschlagen und Treffer bei
  Bedarf mit `http_get` öffnen.
- **Wetter:** `get_weather`-Tool über Open-Meteo (kostenlos, kein Key) — aktuelles
  Wetter plus Vorhersage bis 7 Tage, auf Deutsch.
- **Tagesbriefing:** Jon begrüßt einmal täglich beim Start mit Datum, Wetter,
  Erinnerungen und Weckern; jederzeit manuell mit `/briefing` abrufbar.
- **PDF-Analyse:** `read_pdf`-Tool liest den Text aus PDF-Dateien (jetzt 51 Tools).
- **Heller Modus:** Umschaltbar in den Einstellungen (Dunkel/Hell), wird gespeichert.
- **Globaler Hotkey + Tray:** Strg+Alt+J öffnet/versteckt Jon von überall. Das
  Schließen-X minimiert in den Infobereich neben der Uhr (Beenden über das Tray-Menü).
- **Chat-Export:** `/export` speichert die aktuelle Unterhaltung als Markdown-Datei.
- **Verlauf-Suche:** Suchfeld in der Seitenleiste filtert die Unterhaltungen.
- Das „Jon Backend"-Fenster zeigt die Server-Ausgabe wieder live an und schreibt sie
  gleichzeitig nach `data\backend.log`.

## [1.4.1] — 2026-07-07

### Behoben
- **Backend stürzte beim Neustart immer ab („Port 8756 bereits verwendet"):**
  `start-jon.bat` filterte die Portbelegung nach dem englischen Wort „LISTENING" —
  auf deutschem Windows heißt es „ABHÖREN", der alte Prozess wurde also nie beendet.
  Der Port-Kill läuft jetzt sprachunabhängig über PowerShell, und das Backend räumt
  beim Start zusätzlich selbst einen belegten Port frei (alte Instanz wird beendet,
  neue übernimmt).
- Ordner-Dialog in Jon Code: Fehler werden nicht mehr stillschweigend verschluckt —
  wenn kein Dialog erscheinen kann, öffnet sich das manuelle Pfad-Feld.
- Der „Verbunden"-Punkt prüft das Backend jetzt alle 15 Sekunden statt nur beim
  App-Start.

## [1.4.0] — 2026-07-07

### Neu
- **Echter Windows-Wecker:** `set_alarm` legt eine geplante Windows-Aufgabe an, die zur
  Uhrzeit (`time='07:00'`) oder nach Ablauf (`in_minutes=10`) mit Klingelton und Popup
  klingelt — auch wenn Jon geschlossen ist. Dazu `list_alarms` und `delete_alarm`.
- **`REASONING_EFFORT` in `.env`:** steuert, wie lange gpt-oss-Modelle „nachdenken"
  (`low`/`medium`/`high`). Standard `low` — Antworten kommen dadurch um ein Vielfaches
  schneller (gemessen ~0,7s statt ~4s bis zum ersten Token).

### Geändert
- **Konten & Modelle laden deutlich schneller:** `/api/providers` und `/api/accounts`
  fragen alle Anbieter parallel statt nacheinander ab, Modell-Listen werden 5 Minuten
  gecacht und hängende Anbieter nach 6s (`MODELS_TIMEOUT`) übersprungen. Gemini blockiert
  den Server dabei nicht mehr.
- `.env` enthält jetzt alle unterstützten Anbieter (OpenRouter, Groq, Together, xAI,
  Ollama, LM Studio, …) zum direkten Eintragen.
- System-Prompt kennt Wecker/Timer, `ms-settings:`-Deep-Links und die Regel, bereits
  erledigte Aktionen nie zu wiederholen.

### Behoben
- **Backend startete auf neuen Geräten nicht:** `audioop-lts` fehlte in den
  Requirements (Pflicht ab Python 3.13), und ein Fehler beim Import von
  Sprachpaket/PyAutoGUI riss den ganzen Server mit. Beides ist jetzt abgesichert —
  Sprach- und Maussteuerung melden sich sauber ab, statt den Start zu verhindern.
- **`start-jon.bat` deutlich robuster:** erkennt den Windows-Store-Python-Platzhalter,
  nutzt den `py`-Launcher, prüft alle Abhängigkeiten, installiert notfalls mit `--user`,
  schreibt `data\backend.log` und zeigt bei Startfehlern die letzten Log-Zeilen an.
- **Jon wiederholt keine erledigten Aktionen mehr** (z.B. YouTube nach einem „Danke"
  erneut öffnen): Tool-Antworten ohne Text erscheinen im Verlauf jetzt als
  „[Bereits erledigt: …]" bzw. „Erledigt ✅", und der Prompt verbietet Wiederholungen.

## [1.3.0] — 2026-07-07

### Neu
- **Coding-Agent im Terminal (`jon`):** autonomer KI-Coding-Agent für das VS-Code-Terminal
  mit Workspace-Analyse, präzisen Multi-Datei-Änderungen, Build/Test-Schleife und
  vollständigem Slash-Command-System (`/help /clear /status /usage /model /provider
  /agents /tools /memory /plugins /settings`). `/model` und `/provider` wechseln ohne
  Neustart. Installierbar über `pip install -e .` (Konsolen-Befehl `jon`) oder `jon.bat`.
- **Neue Provider:** OpenRouter, Groq, Together AI, xAI (Grok), LM Studio — plus Ollama als
  vollwertige lokale Gratis-Option mit Erreichbarkeits- und Modell-Erkennung.
- **`edit_file`-Tool:** präzise Textersetzung statt ganze Dateien zu überschreiben.
- **Eigenes System-Prompt:** in der App unter Konten → Prompt (ergänzen oder ersetzen).
- **Eigene Skills anlegen/löschen** direkt in der App; neuer **game-design**-Skill
  (2D-Canvas- und 3D-Three.js-Gerüste).
- **Erinnerungen/Loops:** `set_reminder`-Tool und Konten → Erinnerungen. Jon meldet fällige
  Erinnerungen, sobald die App offen ist, per Chat-Nachricht und Browser-Benachrichtigung.

### Hinweis
- Eine Anmeldung mit ChatGPT-/Claude-**Abo** (statt API-Key) bleibt bewusst außen vor: Die
  Anbieter stellen dafür keine offizielle Schnittstelle bereit. Für „gratis" sind Ollama und
  LM Studio (lokal) sowie Free-Tiers (NVIDIA, Gemini, Groq) vorgesehen.
- SMS-Benachrichtigung an eine Telefonnummer ist nicht enthalten (bräuchte einen
  kostenpflichtigen SMS-Dienst); stattdessen offizielle Browser-Benachrichtigungen.

## [1.2.0] — 2026-07-07

### Neu
- **Erweiterte Tools:** `search_files`, `make_dir`, `append_file`, `copy_path`,
  `zip_paths`, `unzip`, `clipboard_get`, `clipboard_set`, `screenshot`, `http_get`,
  `download_file`, `system_info`, `list_processes`, `lock_screen`.
- **Skill-System:** bearbeitbare Markdown-Anleitungen unter `skills/` mit den Tools
  `list_skills`, `read_skill`, `write_skill`. Mitgeliefert: `web-design`, `pc-automation`,
  `research`. Bearbeitbar in der App, per API und als Datei.
- **Konten-Bereich:** Anbieter per offiziellem API-Key verbinden, automatische
  Modell-Erkennung, Standardmodell wählen. Transparente Anzeige, wenn Tarif/Profil offiziell
  nicht verfügbar sind. Endpunkte unter `/api/accounts`.
- **`/usage`:** real gemessene Nutzung (Prompt-/Completion-/Gesamt-Tokens, Anfragen,
  durchschnittliche Antwortzeit, letztes Modell) pro Anbieter. Endpunkt `/api/usage`.
- **Handy-App:** Tool-Loop mit Apps öffnen, Teilen, Vorlesen, Standort, Uhrzeit,
  Web-Abruf; Spracheingabe (Web Speech API); Bildanalyse über Vision-Modelle.
- **Dokumentation:** kompletter `docs/`-Ordner (Features, Architektur, API, Skills,
  Android, Development, Examples, Roadmap, FAQ) und dieser Changelog.

### Geändert
- Antwortlimit auf bis zu 32.768 Tokens erhöht, mit automatischer Halbierung bei
  Modellgrenzen. Anthropic/Gemini erhalten sinnvolle Modell-Fallbacks.
- Provider lösen ihren API-Key jetzt dynamisch auf (env oder verbundenes Konto).
- System-Prompt kennt die neuen Fähigkeiten und Skills.

### Behoben
- Veraltete kompilierte `*.js`/`*.d.ts` aus `frontend/src` entfernt, die im Vite-Build die
  echten `.tsx`-Quellen überschatteten.

## [1.1.0] — 2026-07-06

### Neu
- Freigabe-Modus „Zuerst fragen" (Standard) / „Alles erlauben", dauerhaft gespeichert.
- Aufklappbare Tool-Chips: Befehl, Zusammenfassung und Ergebnis auf Klick.

## [1.0.0] — 2026-07-06

### Neu
- Erste Veröffentlichung: Multi-Provider-Chat, Streaming, Persistenz, PC-Steuerung,
  Maus-/Tastatur-Automatisierung, Sprachsteuerung, Langzeitgedächtnis, Website und
  Handy-App.
