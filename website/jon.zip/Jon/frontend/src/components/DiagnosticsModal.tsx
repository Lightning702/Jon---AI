import { useEffect, useState } from "react";
import {
  Diagnose,
  Kopplung,
  TelegramStand,
  getDiagnose,
  getKopplung,
  getTelegramStand,
  neuesToken,
  protokollUrl,
} from "../lib/api";
import { setToken } from "../lib/token";
import { inZwischenablage } from "../lib/umgebung";

function zeit(sekunden: number): string {
  if (sekunden < 90) return Math.round(sekunden) + " s";
  const minuten = Math.floor(sekunden / 60);
  if (minuten < 90) return minuten + " min";
  const stunden = Math.floor(minuten / 60);
  return stunden + " h " + (minuten % 60) + " min";
}

function Feld({
  name,
  wert,
  breit,
  warnung,
}: {
  name: string;
  wert: string;
  breit?: boolean;
  warnung?: boolean;
}) {
  return (
    <div className={breit ? "col-span-2" : ""}>
      <div className="text-[10px] uppercase tracking-wider text-white/35">
        {name}
      </div>
      <div
        className={
          "text-[12px] break-all " + (warnung ? "text-red-300" : "text-white/75")
        }
      >
        {wert}
      </div>
    </div>
  );
}

export default function DiagnosticsModal({ onClose }: { onClose: () => void }) {
  const [daten, setDaten] = useState<Diagnose | null>(null);
  const [kopplung, setKopplung] = useState<Kopplung | null>(null);
  const [fehler, setFehler] = useState("");
  const [hinweis, setHinweis] = useState("");
  const [telegram, setTelegram] = useState<TelegramStand | null>(null);
  const [telegramLaedt, setTelegramLaedt] = useState(false);
  const [zeigeToken, setZeigeToken] = useState(false);
  const [laedt, setLaedt] = useState(true);

  const laden = async () => {
    setLaedt(true);
    try {
      const [d, k] = await Promise.all([getDiagnose(), getKopplung()]);
      setDaten(d);
      setKopplung(k);
      setFehler("");
    } catch (e) {
      setFehler(e instanceof Error ? e.message : "Diagnose fehlgeschlagen");
    } finally {
      setLaedt(false);
    }
  };

  useEffect(() => {
    void laden();
  }, []);

  const kopieren = async (text: string, was: string) => {
    try {
      await inZwischenablage(text);
      setHinweis(was + " kopiert");
      setTimeout(() => setHinweis(""), 2200);
    } catch {
      setHinweis("Kopieren nicht möglich");
    }
  };

  const erneuern = async () => {
    const sicher = window.confirm(
      "Neues Token erzeugen? Alle gekoppelten Handys und Browser müssen danach neu verbunden werden."
    );
    if (!sicher) return;
    try {
      const frisch = await neuesToken();
      setToken(frisch.token);
      setKopplung(frisch);
      setHinweis("Neues Token aktiv");
    } catch (e) {
      setFehler(e instanceof Error ? e.message : "Token nicht erneuert");
    }
  };

  const kaputt = new Set(daten?.fehlerhaft ?? []);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl max-h-[86vh] overflow-y-auto rounded-2xl border border-gold/25 bg-[#0b0b0f] shadow-2xl">
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 sticky top-0 bg-[#0b0b0f]">
          <div className="text-sm text-gold">Diagnose</div>
          <button
            onClick={onClose}
            className="text-white/50 hover:text-white text-lg leading-none px-2"
          >
            X
          </button>
        </div>

        <div className="p-4 space-y-4 text-[12px] text-white/80">
          {fehler && (
            <div className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-red-200">
              {fehler}
            </div>
          )}
          {hinweis && (
            <div className="rounded-lg border border-gold/30 bg-gold/10 px-3 py-2 text-gold">
              {hinweis}
            </div>
          )}

          {daten && (
            <div className="grid grid-cols-2 gap-2">
              <Feld name="Version" wert={daten.version} />
              <Feld name="Läuft seit" wert={zeit(daten.laufzeit)} />
              <Feld
                name="Erreichbar unter"
                wert={
                  daten.adresse +
                  ":" +
                  daten.port +
                  (daten.lan ? " (WLAN)" : " (nur dieser PC)")
                }
              />
              <Feld
                name="Dienste mit Fehlern"
                wert={
                  daten.fehlerhaft.length === 0
                    ? "keine"
                    : daten.fehlerhaft.join(", ")
                }
                warnung={daten.fehlerhaft.length > 0}
              />
              <Feld
                name="Datenverzeichnis"
                wert={daten.datenverzeichnis}
                breit
              />
            </div>
          )}

          <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="text-[11px] uppercase tracking-wider text-white/40">
                Telegram
              </div>
              <button
                onClick={() => {
                  setTelegramLaedt(true);
                  void getTelegramStand()
                    .then(setTelegram)
                    .catch(() => setTelegram(null))
                    .finally(() => setTelegramLaedt(false));
                }}
                className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[10.5px] text-white/60 hover:bg-white/10"
              >
                {telegramLaedt ? "Prüfe…" : "Bot prüfen"}
              </button>
            </div>
            {!telegram && (
              <p className="text-[11px] text-white/45 leading-relaxed">
                Antwortet dein Bot nicht — vor allem in einer Gruppe? Hier siehst du,
                ob er erreichbar ist, ob ein Webhook dazwischenfunkt und ob
                Nachrichten überhaupt ankommen.
              </p>
            )}
            {telegram && (
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <Feld
                    name="Bot"
                    wert={
                      telegram.token_gesetzt
                        ? telegram.bot
                          ? "@" + telegram.bot
                          : "Token passt nicht"
                        : "kein Token auf diesem Gerät"
                    }
                    warnung={!telegram.bot}
                  />
                  <Feld
                    name="Privatsphäre-Modus"
                    wert={
                      telegram.liest_alles === null
                        ? "unbekannt"
                        : telegram.liest_alles
                          ? "aus (sieht alles)"
                          : "an (nur Erwähnungen)"
                    }
                  />
                  <Feld
                    name="Webhook"
                    wert={telegram.webhook ? telegram.webhook : "keiner"}
                    warnung={!!telegram.webhook}
                  />
                  <Feld
                    name="Nachrichten geholt"
                    wert={String(telegram.updates)}
                  />
                </div>
                {telegram.letzter_fehler && (
                  <div className="rounded-lg border border-red-400/25 bg-red-400/10 px-2.5 py-1.5 text-[11px] text-red-200/90">
                    Letzter Fehler: {telegram.letzter_fehler}
                  </div>
                )}
                {telegram.gruppen.length > 0 && (
                  <div className="space-y-1">
                    {telegram.gruppen.map((g) => (
                      <div key={g.chat_id} className="text-[11px] text-white/55">
                        {g.titel || g.chat_id}: {g.gesehen} gesehen ·{" "}
                        {g.erwaehnt} mit @-Anrede · {g.geantwortet} beantwortet
                      </div>
                    ))}
                  </div>
                )}
                {telegram.hinweise.map((h, i) => (
                  <div
                    key={i}
                    className="rounded-lg border border-gold/25 bg-gold/10 px-2.5 py-1.5 text-[11px] leading-relaxed text-gold/90"
                  >
                    {h}
                  </div>
                ))}
              </div>
            )}
          </div>

          {kopplung && (
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3 space-y-2">
              <div className="text-[11px] uppercase tracking-wider text-white/40">
                Handy koppeln
              </div>
              <p className="text-white/60 leading-relaxed">
                {kopplung.lan
                  ? "Öffne diese Adresse im Browser deines Handys. Sie enthält deinen Zugangsschlüssel — gib sie an niemanden weiter."
                  : "Jon ist gerade nur auf diesem PC erreichbar. Für das Handy JON_LAN=1 eintragen und Jon neu starten:"}
              </p>
              {!kopplung.lan && (
                <div className="font-mono text-[10px] text-white/45 break-all bg-black/40 rounded-lg px-2 py-1.5">
                  {kopplung.env_datei}
                </div>
              )}
              {!kopplung.oberflaeche && (
                <div className="text-[11px] text-red-300/90 leading-relaxed">
                  Die Web-Oberfläche wurde nicht gefunden — am Handy lässt sich Jon
                  gerade nicht öffnen. Im Quellcode hilft „npm run build" im Ordner
                  frontend.
                </div>
              )}
              <div className="flex gap-2">
                <input
                  readOnly
                  value={kopplung.url}
                  onFocus={(e) => e.currentTarget.select()}
                  className="flex-1 bg-black/40 border border-white/10 rounded-lg px-2 py-1.5 text-[11px] font-mono text-white/70"
                />
                <button
                  onClick={() => void kopieren(kopplung.url, "Adresse")}
                  className="px-3 py-1.5 rounded-lg border border-gold/30 text-gold text-[11px] hover:bg-gold/10"
                >
                  Kopieren
                </button>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setZeigeToken((v) => !v)}
                  className="text-[11px] text-white/50 hover:text-white/80 underline"
                >
                  {zeigeToken ? "Token verbergen" : "Token anzeigen"}
                </button>
                <button
                  onClick={() => void erneuern()}
                  className="text-[11px] text-red-300/80 hover:text-red-200 underline"
                >
                  Neues Token
                </button>
              </div>
              {zeigeToken && (
                <div className="font-mono text-[11px] text-white/60 break-all bg-black/40 rounded-lg px-2 py-1.5">
                  {kopplung.token}
                </div>
              )}
            </div>
          )}

          {daten && (
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <div className="text-[11px] uppercase tracking-wider text-white/40 mb-2">
                Hintergrunddienste ({daten.dienste.length})
              </div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                {daten.dienste.map((d) => (
                  <div
                    key={d.dienst}
                    className="flex items-center justify-between gap-2"
                    title={d.meldung ?? ""}
                  >
                    <span className="truncate text-white/60">{d.dienst}</span>
                    <span
                      className={
                        kaputt.has(d.dienst)
                          ? "text-red-300 shrink-0"
                          : "text-emerald-300/70 shrink-0"
                      }
                    >
                      {kaputt.has(d.dienst) ? d.fehler + " Fehler" : "läuft"}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {daten && (
            <div className="rounded-xl border border-white/10 bg-black/40 p-3">
              <div className="text-[11px] uppercase tracking-wider text-white/40 mb-2">
                Letzte Meldungen
              </div>
              <pre className="text-[10px] leading-relaxed text-white/50 whitespace-pre-wrap max-h-56 overflow-y-auto">
                {daten.meldungen.slice(-60).join("\n") || "nichts protokolliert"}
              </pre>
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <button
              onClick={() => void laden()}
              disabled={laedt}
              className="px-3 py-1.5 rounded-lg border border-white/15 text-white/70 text-[11px] hover:bg-white/5 disabled:opacity-40"
            >
              {laedt ? "Lade …" : "Aktualisieren"}
            </button>
            <a
              href={protokollUrl()}
              className="px-3 py-1.5 rounded-lg border border-gold/30 text-gold text-[11px] hover:bg-gold/10"
            >
              Protokoll speichern
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
